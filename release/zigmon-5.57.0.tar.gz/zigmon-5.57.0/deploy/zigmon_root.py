#!/usr/bin/python3 -I
"""zigmon_root.py - what the dashboard may ask for that only root can do (5.18).

The daemon runs as `zigmon`, under ProtectSystem=strict, and may not change
nginx, the certificates, the firewall or any file under /etc. What it may do
is lay a request down in /var/lib/zigmon/root/request.json; systemd
(zigmon-root.path) sees it and starts zigmon-root.service, which runs this as
root. Four kinds of thing can be asked for, and nothing else:

  * apply        - the TLS of the dashboard (the certificate with its chain,
                   the root it is checked against, the protocols, the
                   ciphers, the DH parameters, HSTS), who may reach which
                   pages (the allow lists of the dashboard, the one-tap
                   links and the SMS gateway in nginx), and the machine's
                   firewall (iptables / ip6tables, or firewalld);
  * full_*       - a backup of the whole installation: the database, the
                   configuration, nginx, the certificates and their keys,
                   the broker, the firewall and the units - made, handed
                   over for a download, taken in from an upload, looked into,
                   put back, deleted;
  * look.ask     - what is in place now (the certificate, the firewall as
                   iptables-save or firewall-cmd shows it, the allow lists,
                   the kept backups), written for the dashboard;
  * osup.ask     - a look for the system's updates, or the update itself
                   (dnf), started as a job of its own that outlives this
                   service and writes how it goes into osup.json and osup.log;
                   the proxy of Control - Proxy, when one is handed over, kept
                   for dnf in a file only root reads, never on a command line.
  * osroots.ask  - the system's trusted roots: certificate authorities of
                   one's own put beside the distribution's list, in its folder
                   of local additions (zigmon-<sha256>.pem|.crt only), and the
                   system's own tool run when anything changed.
  * selinux.ask  - how SELinux is here, the way to enforcing a step at a time
                   (made ready, what zigmon needs put in, enforcing,
                   permissive again) and a report for whoever writes
                   zigmon's module - booleans and port types only from
                   an allow-list, a port never taken from another service.

Nothing in a request is trusted: every value is checked against the one shape
it may have before it goes into a file, certificates and keys are read by
openssl and the key must be the certificate's own, nginx is asked (nginx -t)
before it is reloaded and every file is put back as it was when it says no,
and the folder the zigmon account owns is used through one descriptor, never
a path it could swap for a link.

  zigmon_root.py                          serve request.json (root, from systemd)
  zigmon_root.py --look                   what is in place here (JSON)
  zigmon_root.py --backup [--why WORDS]   a backup of the whole installation, now
  zigmon_root.py --restore FILE [--parts a,b] [--passphrase-file F] [--yes]
                                          put a backup back - any part, from any
                                          machine: root on the command line is
                                          trusted with what the dashboard is not
  zigmon_root.py --inspect FILE [--passphrase-file F]
                                          what a backup holds
  zigmon_root.py --os-job ID check|upgrade [security]
                                          the system's updates (started by itself)
  zigmon_root.py --selinux-check [--json] | --selinux-do STEP [--json] | --selinux-report FILE
                                          SELinux (from zigmon --selinux-check, --selinux,
                                          --selinux-report; what is needed on stdin)
  zigmon_root.py --selinux-fix ID... [--json] | --selinux-rule-drop ID [--json]
                                          what SELinux refused put right by finding id, a
                                          local rule taken away (zigmon --selinux-fix, --selinux-rules)
"""
import base64
import calendar
import errno
import fcntl
import grp
import hashlib
import hmac
import io
import ipaddress
import json
import os
import pwd
import re
import shlex
import shutil
import socket
import stat
import subprocess
import sys
import tarfile
import tempfile
import time

STATE_DIR = os.environ.get('ZIGMON_STATE', '/var/lib/zigmon')
ROOT_SUB = 'root'
ROOT_DIR = os.path.join(STATE_DIR, ROOT_SUB)
# root's own: where the kept backups of the whole installation live, and what
# this helper remembers between runs (the firewalld rules it added, the key
# its backups are sealed with). Never in the zigmon account's folder.
OWN_DIR = os.environ.get('ZIGMON_ROOT_OWN', '/var/lib/zigmon-root')
FULL_DIR = os.environ.get('ZIGMON_FULL_DIR', '/var/backups/zigmon')
CONFIG_FILE = os.environ.get('ZIGMON_CONFIG', '/etc/zigmon/config.json')
NGINX_CANDIDATES = [p for p in (os.environ.get('ZIGMON_NGINX_CONF'),
                                '/etc/nginx/conf.d/zigmon.conf',
                                '/etc/nginx/conf.d/nginx-zigmon.conf') if p]
CERT_DIR = os.environ.get('ZIGMON_CERT_DIR', '/etc/nginx/certs')
MOSQ_DIR = os.environ.get('ZIGMON_MOSQ_DIR', '/etc/mosquitto')
NO_SERVICES = bool(os.environ.get('ZIGMON_NO_SERVICES'))     # tests: no systemctl
NGINX_TEST = shlex.split(os.environ.get('ZIGMON_NGINX_TEST', 'nginx -t'))
FIREWALL_CMD = os.environ.get('ZIGMON_FIREWALL_CMD', 'firewall-cmd')
IPT_PREFIX = os.environ.get('ZIGMON_IPTABLES_PREFIX', '')      # tests: a folder of fakes
MARK = '# written by zigmon (zigmon_root.py) - change it on the dashboard'
SERVICE_USER = os.environ.get('ZIGMON_USER', 'zigmon')
# tests: where /etc is (the places a backup may put a file back are written
# as they are on a real machine, and looked at under this)
FS_ROOT = os.environ.get('ZIGMON_FS_ROOT', '').rstrip('/')
SERVICE_LOG = os.environ.get('ZIGMON_SERVICE_LOG', '')


class Refused(Exception):
    pass


# ---- the folder the zigmon account owns: one descriptor, never a path ------
FD = {}


def sub_fd(name):
    """A descriptor for /var/lib/zigmon/<name>, opened without following a
    link at either step: the zigmon account owns /var/lib/zigmon and could
    otherwise put a link to anywhere in its place between two steps."""
    if name not in FD:
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        top = os.open(STATE_DIR, flags)
        try:
            FD[name] = os.open(name, flags, dir_fd=top)
        finally:
            os.close(top)
    return FD[name]


def root_fd():
    return sub_fd(ROOT_SUB)


def child_fd(parent_fd, name, make=False):
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    try:
        return os.open(name, flags, dir_fd=parent_fd)
    except FileNotFoundError:
        if not make:
            raise
        # the zigmon account takes what is handed over out of it again
        os.mkdir(name, 0o770, dir_fd=parent_fd)
        fd = os.open(name, flags, dir_fd=parent_fd)
        try:
            os.fchown(fd, 0, service_gid())
        except (OSError, KeyError):
            pass
        return fd


def service_gid():
    return grp.getgrnam(SERVICE_USER).gr_gid


def service_uid():
    return pwd.getpwnam(SERVICE_USER).pw_uid


def open_plain(dir_fd, name, most=None):
    """A plain file in a folder of the zigmon account's, opened without
    following a link and without waiting on a FIFO put in its place."""
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=dir_fd)
    st = os.fstat(fd)
    if not stat.S_ISREG(st.st_mode):
        os.close(fd)
        raise Refused('%s is not a plain file' % name)
    if most is not None and st.st_size > most:
        os.close(fd)
        raise Refused('%s is far bigger than it can be' % name)
    return os.fdopen(fd, 'rb')


def read_req(name, most=4 * 1024 * 1024):
    with open_plain(root_fd(), name, most) as f:
        data = f.read(most + 1)
    if len(data) > most:
        raise Refused('the request is far bigger than any request needs')
    return data


def write_here(name, text, dir_fd=None, mode=0o640, owner=None):
    """A file the dashboard reads, written into the zigmon account's folder:
    a new file beside it, renamed over it - a link put there is replaced,
    never followed. `owner` (5.44.1): (uid, gid) in place of root:zigmon."""
    d = root_fd() if dir_fd is None else dir_fd
    data = text if isinstance(text, bytes) else text.encode('utf-8')
    for n in range(50):
        tmp = '.%s.%d.%d' % (name, os.getpid(), n)
        try:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode,
                         dir_fd=d)
        except FileExistsError:
            continue
        with os.fdopen(fd, 'wb') as f:
            f.write(data)
            try:
                os.fchown(f.fileno(), *(owner or (0, service_gid())))
            except (OSError, KeyError):
                pass
            os.fchmod(f.fileno(), mode)
        os.replace(tmp, name, src_dir_fd=d, dst_dir_fd=d)
        return
    raise OSError('could not write %s' % name)


def write_root(path, data, mode, owner=None):
    """A file of root's, replaced whole - with the owner and the mode the
    one before it had, unless told otherwise: the key nginx and mosquitto
    share may belong to the mosquitto group, and a key written back as
    root:root 0600 would stop the broker at its next start."""
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    keep = None
    try:
        st = os.lstat(path)
        if stat.S_ISREG(st.st_mode):
            keep = (st.st_uid, st.st_gid, st.st_mode & 0o777)
    except FileNotFoundError:
        pass
    if owner is not None:
        uid, gid, m = owner[0], owner[1], mode
    elif keep:
        uid, gid, m = keep
    else:
        uid, gid, m = 0, 0, mode
    fd, tmp = tempfile.mkstemp(prefix='.zigmon-', dir=folder)
    try:
        # owner and mode set on the open file, never by its name: the folder
        # may be zigmon's own (the backups, the Zigbee2MQTT data), and a name
        # swapped for a link to /etc/shadow while the data was written gave
        # that file zigmon's owner and the mode the backup asked for
        with os.fdopen(fd, 'wb') as f:
            f.write(data if isinstance(data, bytes) else data.encode('utf-8'))
            f.flush()
            os.fchown(f.fileno(), uid, gid)
            os.fchmod(f.fileno(), m)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    relabel(path)


def relabel(path):
    if not NO_SERVICES and shutil.which('restorecon'):
        subprocess.run(['restorecon', path], capture_output=True)


def snapshot(paths):
    got = {}
    for p in paths:
        try:
            st = os.lstat(p)
            if not stat.S_ISREG(st.st_mode):
                got[p] = None
                continue
            with open(p, 'rb') as f:
                got[p] = (f.read(), st.st_mode & 0o777, st.st_uid, st.st_gid)
        except FileNotFoundError:
            got[p] = None
    return got


def put_back(snap):
    for p, was in snap.items():
        if was is None:
            try:
                os.unlink(p)
            except OSError:
                pass
            continue
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(p) or '.')
        with os.fdopen(fd, 'wb') as f:          # by the open file, as write_root does
            f.write(was[0])
            f.flush()
            os.fchown(f.fileno(), was[2], was[3])
            os.fchmod(f.fileno(), was[1])
        os.replace(tmp, p)
        relabel(p)


def run(cmd, what, ok=(0,), data=None, env=None):
    got = subprocess.run(cmd, capture_output=True, text=True, input=data, env=env)
    if got.returncode not in ok:
        raise Refused('%s: %s' % (what, (got.stderr or got.stdout).strip()[-300:] or
                                  'ended with %d' % got.returncode))
    return got.stdout


def service(*args):
    """systemctl, or nothing at all under the tests."""
    if NO_SERVICES:
        if SERVICE_LOG:
            with open(SERVICE_LOG, 'a') as f:
                f.write(' '.join(args) + '\n')
        return subprocess.CompletedProcess(args, 0, '', '')
    return subprocess.run(['systemctl'] + list(args), capture_output=True, text=True)


# ---- what a request may hold ------------------------------------------------
ADDR_RE = re.compile(r'^[0-9A-Fa-f:.]+(/[0-9]{1,3})?$')
CERT_RE = re.compile(r'^(\s*-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----)+\s*$')
KEY_RE = re.compile(r'^\s*-----BEGIN (RSA |EC )?PRIVATE KEY-----[A-Za-z0-9+/=\s:,-]+'
                    r'-----END (RSA |EC )?PRIVATE KEY-----\s*$')
PROTOCOLS = ('TLSv1.2', 'TLSv1.3')
DH_CHOICES = ('none', 'ffdhe2048', 'ffdhe3072', 'ffdhe4096', 'gen2048', 'gen3072', 'gen4096')
NAME_FILE = re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,120}$')
FULL_FILE = re.compile(r'^zigmon-full-[A-Za-z0-9._-]{1,100}\.tar\.gz$')


def plain(text, how):
    """An address or a network, and nothing else: ipaddress keeps an IPv6
    scope id (fe80::1%eth0) with any character in it, newlines and braces
    included, and so into nginx and iptables files root writes."""
    text = str(text or '').strip()
    if not ADDR_RE.match(text):
        raise ValueError('not a plain address')
    got = {'address': ipaddress.ip_address,
           'network': lambda t: ipaddress.ip_network(t, strict=False),
           'interface': ipaddress.ip_interface}[how](text)
    if '%' in str(got):
        raise ValueError('a scope id is not taken')
    return got


def openssl(args, what, data=None):
    got = subprocess.run(['openssl'] + args, capture_output=True, text=True, input=data)
    if got.returncode != 0:
        raise Refused('%s: %s' % (what, ((got.stderr or got.stdout).strip().splitlines()
                                         or ['openssl said no'])[-1][:300]))
    return got.stdout


def pem_set(cert, key, chain='', root=''):
    """A certificate, its key, the certificates between it and the root, and
    the root - each read by openssl, the key the certificate's own."""
    cert, key = str(cert or '').strip(), str(key or '').strip()
    chain, root = str(chain or '').strip(), str(root or '').strip()
    if not cert and not key:
        return None
    if not cert or not key:
        raise Refused('a certificate needs its key, and a key its certificate')
    for what, text in (('the certificate', cert), ('the chain', chain), ('the root', root)):
        if text and not CERT_RE.match(text):
            raise Refused('%s is not PEM (-----BEGIN CERTIFICATE-----)' % what)
    if not KEY_RE.match(key):
        raise Refused('the key is not a PEM private key without a passphrase')
    with tempfile.TemporaryDirectory(prefix='zigmon-root-') as t:
        cf, kf = os.path.join(t, 'c.pem'), os.path.join(t, 'k.pem')
        with open(cf, 'w') as f:
            f.write(cert + '\n')
        fd = os.open(kf, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w') as f:
            f.write(key + '\n')
        a = openssl(['x509', '-in', cf, '-noout', '-pubkey'], 'the certificate')
        b = openssl(['pkey', '-in', kf, '-pubout'], 'the key')
        if a.strip() != b.strip():
            raise Refused('the key is not the one of this certificate')
        if subprocess.run(['openssl', 'x509', '-in', cf, '-noout', '-checkend', '0'],
                          capture_output=True).returncode != 0:
            raise Refused('the certificate has run out')
    return {'cert': cert + '\n', 'key': key + '\n', 'chain': (chain + '\n') if chain else '',
            'root': (root + '\n') if root else ''}


def trust_of(pem, alt=None):
    """The chain nginx trusts (OCSP stapling): the root and the chain of the
    certificate - and (5.42) those of the EC one uploaded beside it, whose CA
    may sign with intermediates of their own, each certificate once."""
    trust = pem['root'] + pem['chain']
    if alt and alt.get('own_trust'):
        have = re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', trust, re.S)
        for c in re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',
                            alt['chain'] + alt['root'], re.S):
            if c not in have:
                have.append(c)
                trust += c + '\n'
    return trust


def tls_checked(t):
    if t is None:
        return None
    if not isinstance(t, dict):
        raise Refused('the TLS is not an object')
    out = {'pem': pem_set(t.get('cert'), t.get('key'), t.get('chain'), t.get('root'))}
    # Automatic certificates (5.30): the certificate in place kept in root's
    # own folder when the first one from the ACME CA replaces it - its key
    # with it, never handed to the daemon - and put back from there when asked
    # a second certificate beside it (5.33.2): RSA and ECDSA at once
    alt = t.get('alt') if isinstance(t.get('alt'), dict) else None
    out['alt'] = pem_set(alt.get('cert'), alt.get('key'), alt.get('chain'), alt.get('root')) \
        if alt and out['pem'] else None
    if out['alt']:
        # uploaded side by side (5.42): it comes with its chain and root, which
        # join the chain nginx trusts; ACME's comes without
        out['alt']['own_trust'] = 'root' in alt
    out['keep_before'] = bool(t.get('keep_before')) and bool(out['pem'])
    out['put_back'] = bool(t.get('put_back'))
    if out['put_back']:
        out['pem'] = None
    prot = t.get('protocols') or list(PROTOCOLS)
    if not isinstance(prot, list) or not prot or any(p not in PROTOCOLS for p in prot):
        raise Refused('the protocols are TLSv1.2 and/or TLSv1.3')
    out['protocols'] = [p for p in PROTOCOLS if p in prot]
    ciphers = str(t.get('ciphers') or '').strip()
    if ciphers:
        if not re.match(r'^[A-Za-z0-9_+!@=:.-]{1,2000}$', ciphers):
            raise Refused('the ciphers are an OpenSSL cipher list: letters, digits, : + ! - =')
        openssl(['ciphers', ciphers], 'OpenSSL does not know that cipher list')
    out['ciphers'] = ciphers
    out['prefer'] = bool(t.get('prefer'))
    dh = str(t.get('dh') or 'none')
    if dh not in DH_CHOICES:
        raise Refused('the DH parameters are one of %s' % ', '.join(DH_CHOICES))
    out['dh'] = dh
    try:
        out['hsts'] = int(t.get('hsts') or 0)
    except (TypeError, ValueError):
        raise Refused('HSTS is a number of seconds')
    if not 0 <= out['hsts'] <= 63072000:
        raise Refused('HSTS is 0 to 63072000 seconds')
    return out


def checked(r):
    """An apply request, every value in the one shape it may have."""
    if not isinstance(r, dict):
        raise Refused('the request is not an object')
    out = {'id': re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:32],
           'hash': re.sub(r'[^0-9a-f]', '', str(r.get('hash') or ''))[:64]}
    out['tls'] = tls_checked(r.get('tls'))
    fw = r.get('fw')
    if isinstance(fw, dict):
        rules = fw.get('rules') or []
        if not isinstance(rules, list) or len(rules) > 2000:
            raise Refused('the firewall rules are a list, 2000 at most')
        out['fw'] = {'on': bool(fw.get('on')), 'rules': [fw_rule_checked(x) for x in rules]}
    else:
        out['fw'] = None
    out['access'] = access_checked(r.get('access'))
    out['acme'] = acme_checked(r.get('acme'))
    return out


def acme_checked(a):
    """Automatic certificates (5.30): whether port 80 answers the ACME CA's
    HTTP-01 question - {'http': true|false}, or nothing to do."""
    if a is None:
        return None
    if not isinstance(a, dict):
        raise Refused('the ACME part is not an object')
    return {'http': bool(a.get('http'))}


# ---- nginx: the dashboard's HTTPS server ------------------------------------
def nginx_conf():
    for p in NGINX_CANDIDATES:
        if os.path.isfile(p):
            return p
    return NGINX_CANDIDATES[0] if NGINX_CANDIDATES else '/etc/nginx/conf.d/zigmon.conf'


def block_end(text, brace):
    """Where the { at `brace` is closed."""
    depth = 0
    for j in range(brace, len(text)):
        if text[j] == '{':
            depth += 1
        elif text[j] == '}':
            depth -= 1
            if depth == 0:
                return j + 1
    return None


def server_block(text):
    """(start, end) of the HTTPS server { } of an nginx file."""
    i = 0
    while True:
        m = re.search(r'(?m)^[ \t]*server[ \t]*\{', text[i:])
        if not m:
            return None
        start = i + m.start()
        end = block_end(text, i + m.end() - 1)
        if end is None:
            return None
        block = text[start:end]
        if re.search(r'(?m)^\s*listen\s+[^;]*443[^;]*ssl', block) or \
                re.search(r'(?m)^\s*ssl_certificate\s', block):
            return start, end
        i = end


def directive(block, name):
    """The value of `name` at the server's own level, or None."""
    depth = 0
    for line in block.split('\n'):
        if depth == 1:
            m = re.match(r'^\s*%s\s+([^;]+);' % re.escape(name), line)
            if m:
                return m.group(1).strip().strip('"')
        depth += line.count('{') - line.count('}')
    return None


def directives(block, name):
    """Every value of `name` at the server's own level, in order - a server
    may name two certificates (RSA and ECDSA, 5.33.2)."""
    depth, out = 0, []
    for line in block.split('\n'):
        if depth == 1:
            m = re.match(r'^\s*%s\s+([^;]+);' % re.escape(name), line)
            if m:
                out.append(m.group(1).strip().strip('"'))
        depth += line.count('{') - line.count('}')
    return out


def set_directives(block, name, values):
    """`name` once for each of `values`, in order, where the first one was."""
    block = set_directive(block, name, values[0])
    lines = block.split('\n')
    depth = 0
    for n, line in enumerate(lines):
        if depth == 1 and re.match(r'^\s*%s(\s|;)' % re.escape(name), line):
            for k, v in enumerate(values[1:]):
                lines.insert(n + 1 + k, '    %-25s %s;' % (name, v))
            break
        depth += line.count('{') - line.count('}')
    return '\n'.join(lines)


def alt_paths(cert, key):
    """Where the second certificate of a dual pair goes: beside the first."""
    def beside(p, ext):
        base, _ = os.path.splitext(p)
        return base + '-ecdsa' + ext
    return beside(cert, '.pem'), beside(key, '.key')


def set_directive(block, name, value):
    """`name value;` in a server { } - replaced where it is, put in after
    server_name where it is not, taken out for None. Only the server's own
    lines: a location { } inside is left alone."""
    lines = block.split('\n')
    depth, at, insert_at = 0, [], None
    for n, line in enumerate(lines):
        if depth == 1 and re.match(r'^\s*%s(\s|;)' % re.escape(name), line):
            at.append(n)
        if depth == 1 and insert_at is None and re.match(r'^\s*server_name\s', line):
            insert_at = n + 1
        depth += line.count('{') - line.count('}')
    if value is None:
        for n in reversed(at):
            del lines[n]
        return '\n'.join(lines)
    text = '    %-25s %s;' % (name, value)
    if at:
        lines[at[0]] = text
        for n in reversed(at[1:]):
            del lines[n]
    else:
        lines.insert(insert_at if insert_at is not None else 1, text)
    return '\n'.join(lines)


CIPHERS_DEFAULT = ('ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:'
                   'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:'
                   'ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305')


def tls_files(block):
    """The files the dashboard's server reads its certificate from - the
    same files mosquitto may read for its TLS listener, which is why they are
    written where they are rather than under names of zigmon's own."""
    cert = directive(block, 'ssl_certificate') or os.path.join(CERT_DIR, 'server.pem')
    key = directive(block, 'ssl_certificate_key') or os.path.join(CERT_DIR, 'server.key')
    certs, keys = directives(block, 'ssl_certificate'), directives(block, 'ssl_certificate_key')
    alt_cert, alt_key = (certs[1], keys[1]) if len(certs) > 1 and len(keys) > 1 else alt_paths(cert, key)
    ca = directive(block, 'ssl_trusted_certificate') or os.path.join(CERT_DIR, 'server.ca')
    dh = directive(block, 'ssl_dhparam') or os.path.join(CERT_DIR, 'zigmon-dh.pem')
    for p in (cert, key, ca, dh, alt_cert, alt_key):
        if not p.startswith('/') or '..' in p.split('/'):
            raise Refused('nginx names a certificate file that is not a plain path: %s' % p[:120])
    return {'cert': cert, 'key': key, 'root': ca, 'dh': dh, 'alt_cert': alt_cert, 'alt_key': alt_key}


PROGRESS = {'step': 0, 'total': 5, 'id': ''}
DH_EXPECT_S = {'gen2048': 15, 'gen3072': 120, 'gen4096': 600}


def progress(words, step=None, expect=None):
    if step is not None:
        PROGRESS['step'] = step
    try:
        write_here('progress.json', json.dumps({
            'id': PROGRESS['id'], 'step': PROGRESS['step'], 'total': PROGRESS['total'],
            'words': words, 'at': time.time(), 'expect_s': expect}))
    except OSError:
        pass


def dh_file(choice, path, had):
    """The DH parameters for `choice` in `path`: a group of RFC 7919, or made
    here (which takes a while - 4096 bits minutes). Made ones are made once."""
    if choice == 'none':
        return None
    if choice == had and os.path.exists(path):
        return path
    if choice.startswith('ffdhe'):
        pem = openssl(['genpkey', '-genparam', '-algorithm', 'DH', '-pkeyopt',
                       'group:%s' % choice], 'the DH group %s' % choice)
    else:
        progress('making DH parameters of %s bits' % choice[3:], 2, DH_EXPECT_S.get(choice))
        pem = openssl(['dhparam', choice[3:]], 'making DH parameters of %s bits' % choice[3:])
    write_root(path, pem, 0o644)
    return path


def tls_into(block, t, files, had_dh):
    """The server { } with the TLS of `t`: its files written, its lines set.
    Returns (block, words, mosquitto to be told)."""
    said = []
    wrote_cert = False
    progress('writing the certificate and the TLS settings', 3)
    if t.get('raw'):
        raw = t['raw']
        write_root(files['cert'], raw['cert'], 0o644)
        write_root(files['key'], raw['key'], 0o600)
        wrote_cert = True
        block = set_directive(block, 'ssl_certificate', files['cert'])
        block = set_directive(block, 'ssl_certificate_key', files['key'])
        if raw.get('trust'):
            write_root(files['root'], raw['trust'], 0o644)
            block = set_directive(block, 'ssl_trusted_certificate', files['root'])
        else:
            block = set_directive(block, 'ssl_trusted_certificate', None)
        said.append('the certificate from before ACME put back')
    if t['pem']:
        write_root(files['cert'], t['pem']['cert'] + t['pem']['chain'], 0o644)
        write_root(files['key'], t['pem']['key'], 0o600)
        wrote_cert = True
        if t.get('alt'):
            # both (5.33.2): the first is what a client is sent by default, the
            # second what one that says it takes ECDSA is sent
            write_root(files['alt_cert'], t['alt']['cert'] + t['alt']['chain'], 0o644)
            write_root(files['alt_key'], t['alt']['key'], 0o600)
            block = set_directives(block, 'ssl_certificate', [files['cert'], files['alt_cert']])
            block = set_directives(block, 'ssl_certificate_key', [files['key'], files['alt_key']])
            said.append('a second certificate beside it: %s' % openssl(
                ['x509', '-noout', '-subject'], 'the certificate', t['alt']['cert']).strip())
        else:
            block = set_directive(block, 'ssl_certificate', files['cert'])
            block = set_directive(block, 'ssl_certificate_key', files['key'])
        trust = trust_of(t['pem'], t.get('alt'))
        if trust:
            write_root(files['root'], trust, 0o644)
            block = set_directive(block, 'ssl_trusted_certificate', files['root'])
        else:
            block = set_directive(block, 'ssl_trusted_certificate', None)
        subj = openssl(['x509', '-noout', '-subject', '-enddate'], 'the certificate',
                       t['pem']['cert']).strip().replace('\n', ', ')
        said.append('certificate: %s' % subj)
    block = set_directive(block, 'ssl_protocols', ' '.join(t['protocols']))
    block = set_directive(block, 'ssl_ciphers', t['ciphers'] or CIPHERS_DEFAULT)
    block = set_directive(block, 'ssl_prefer_server_ciphers', 'on' if t['prefer'] else 'off')
    dh = dh_file(t['dh'], files['dh'], had_dh)
    block = set_directive(block, 'ssl_dhparam', dh)
    if t['hsts']:
        block = set_directive(block, 'add_header Strict-Transport-Security',
                              '"max-age=%d" always' % t['hsts'])
    else:
        block = set_directive(block, 'add_header Strict-Transport-Security', None)
    said.append('%s; %s; DH %s%s' % (' '.join(t['protocols']),
                                     'ciphers as set' if t['ciphers'] else 'the usual ciphers',
                                     t['dh'], '; HSTS %d s' % t['hsts'] if t['hsts'] else ''))
    return block, said, wrote_cert


# ---- the broker: does it read the same certificate? ------------------------
def mosquitto_confs():
    out = []
    main = os.path.join(MOSQ_DIR, 'mosquitto.conf')
    if os.path.isfile(main):
        out.append(main)
    d = os.path.join(MOSQ_DIR, 'conf.d')
    if os.path.isdir(d):
        out += sorted(os.path.join(d, n) for n in os.listdir(d) if n.endswith('.conf'))
    return out


def mosquitto_files():
    """Every file the broker's configuration names: its password file, its
    ACL, its certificates."""
    named = {}
    for conf in mosquitto_confs():
        try:
            with open(conf) as f:
                for line in f:
                    m = re.match(r'^\s*(password_file|acl_file|certfile|keyfile|cafile|'
                                 r'dhparamfile|crlfile)\s+(\S+)\s*$', line)
                    if m:
                        named.setdefault(m.group(2), m.group(1))
        except OSError:
            continue
    return named


def mosquitto_reads(paths):
    return sorted(p for p in mosquitto_files() if p in set(paths))


def mosquitto_hup():
    """mosquitto 2.0 and later read their certificates again on SIGHUP: the
    broker stays up, and the house's devices stay connected."""
    got = service('kill', '-s', 'HUP', 'mosquitto')
    return 'mosquitto told to read its certificate again' if got.returncode == 0 else \
        'mosquitto could not be told (%s) - restart it to use the new certificate' % (
            (got.stderr or '').strip()[-120:] or got.returncode)


# ---- who may reach which pages ------------------------------------------------
# Three lists, as nginx-zigmon.conf has them: the dashboard (the server's own
# allow lines), the one-tap links (both of their locations) and the road the
# SMS gateway pushes a message down. Between marks once the dashboard has set
# them; before that, the allow lines that are there are read as they are and
# the first save puts the marks round them.
ACCESS_PAGES = (('dashboard', 'DASHBOARD', None),
                ('links', 'LINKS', ('location = /tap {', 'location ~ "^/tap/')),
                ('sms', 'SMS', ('location = /api/sms/incoming {',)))
ALWAYS = ('127.0.0.1', '::1')


def access_checked(a):
    if not isinstance(a, dict):
        return None
    out = {}
    for k, _mark, _locs in ACCESS_PAGES:
        one = a.get(k)
        if one is None:
            continue
        if not isinstance(one, dict):
            raise Refused('who may reach the %s is not given' % k)
        nets = []
        for x in (one.get('from') or [])[:400]:
            try:
                net = plain(x, 'network')
            except ValueError:
                raise Refused('%r is not an address or a network' % str(x)[:60])
            # one address is written as one address, as people write it
            nets.append(str(net.network_address) if net.prefixlen == net.max_prefixlen else str(net))
        if not one.get('any') and not nets:
            raise Refused('the %s would be for nobody: give a network or everybody' % k)
        out[k] = {'any': bool(one.get('any')),
                  'from': [n for n in dict.fromkeys(nets) if n not in ALWAYS]}
    return out or None


def access_lines(one, pad):
    lines = ['%sallow %s;' % (pad, a) for a in ALWAYS]
    if one['any']:
        lines.append(pad + 'allow all;                    # everybody (set on the dashboard)')
    else:
        lines += ['%sallow %s;' % (pad, n) for n in one['from']]
    return '\n'.join(lines)


def scopes(text, page):
    """(start, end) of every block a list of `page` lives in: the HTTPS
    server itself for the dashboard, its locations for the others."""
    where = server_block(text)
    if not where:
        return []
    if page[2] is None:
        return [where]
    out = []
    for head in page[2]:
        i = where[0]
        while True:
            i = text.find(head, i, where[1])
            if i < 0:
                break
            # the brace that opens the block ends its line: the one-tap
            # link's own expression has {8,64} in it before that
            m = re.compile(r'\{[ \t]*(#[^\n]*)?\n').search(text, i)
            end = block_end(text, m.start()) if m else None
            if end is None:
                break
            out.append((i, end))
            i = end
    return out


def own_lines(text, start, end):
    """The lines of the block at its own depth: (offset, line) pairs."""
    out, depth, pos = [], 0, start
    for line in text[start:end].split('\n'):
        if depth == 1:
            out.append((pos, line))
        depth += line.count('{') - line.count('}')
        pos += len(line) + 1
    return out


def access_into(text, access):
    """The nginx file with the lists as asked. A list between its marks is
    replaced; one without marks yet has its run of allow lines replaced by a
    marked one, and a block with no allow lines at all gets one - with its
    deny all after it. The blocks are found again after every change, since
    each change moves everything after it."""
    for page in ACCESS_PAGES:
        if page[0] not in access:
            continue
        i = 0
        while True:
            found = scopes(text, page)
            if i >= len(found):
                break
            start, end = found[i]
            text = text[:start] + one_list(text[start:end], page, access[page[0]]) + text[end:]
            i += 1
    return text


def one_list(block, page, one):
    """One block (the server, or a location) with its list as asked."""
    mark = page[1]
    if re.search(r'#\s*%s-ALLOW-BEGIN' % mark, block):
        rx = re.compile(r'([ \t]*)# %s-ALLOW-BEGIN[^\n]*\n.*?\n([ \t]*)# %s-ALLOW-END[^\n]*'
                        % (mark, mark), re.S)
        return rx.sub(lambda m: '%s# %s-ALLOW-BEGIN (set on the dashboard)\n%s\n%s# %s-ALLOW-END'
                      % (m.group(1), mark, access_lines(one, m.group(1)), m.group(2), mark),
                      block, count=1)
    lines = own_lines(block, 0, len(block))
    allow = [(p, l) for p, l in lines if re.match(r'^\s*allow\s', l)]
    deny = [(p, l) for p, l in lines if re.match(r'^\s*deny\s+all\s*;', l)]
    if allow:
        first, last = allow[0][0], allow[-1][0] + len(allow[-1][1])
        pad = re.match(r'[ \t]*', allow[0][1]).group(0)
        body = '%s# %s-ALLOW-BEGIN (set on the dashboard)\n%s\n%s# %s-ALLOW-END' % (
            pad, mark, access_lines(one, pad), pad, mark)
        if not deny or deny[0][0] < first:
            body += '\n%sdeny  all;' % pad
        return block[:first] + body + block[last:]
    pad = '    ' if page[2] is None else '        '
    at = re.compile(r'\{[ \t]*(#[^\n]*)?\n').search(block).end()
    body = '%s# %s-ALLOW-BEGIN (set on the dashboard)\n%s\n%s# %s-ALLOW-END\n%sdeny  all;\n' % (
        pad, mark, access_lines(one, pad), pad, mark, pad)
    return block[:at] + body + block[at:]


def access_now(text=None):
    """What the nginx file says now, for the dashboard."""
    if text is None:
        try:
            with open(nginx_conf()) as f:
                text = f.read()
        except OSError:
            return {}
    out = {}
    for page in ACCESS_PAGES:
        k, mark = page[0], page[1]
        found = scopes(text, page)
        if not found:
            out[k] = {'any': True, 'from': [], 'marked': False, 'present': False}
            continue
        start, end = found[0]
        block = text[start:end]
        m = re.search(r'# %s-ALLOW-BEGIN[^\n]*\n(.*?)\n[ \t]*# %s-ALLOW-END' % (mark, mark), block, re.S)
        if m:
            nets = re.findall(r'(?m)^\s*allow\s+([^;\s]+);', m.group(1))
            marked = True
        else:
            nets = [re.match(r'^\s*allow\s+([^;\s]+);', l).group(1)
                    for _p, l in own_lines(text, start, end) if re.match(r'^\s*allow\s+[^;\s]+;', l)]
            marked = False
        out[k] = {'any': 'all' in nets or not nets,
                  'from': [n for n in nets if n not in ('all',) + ALWAYS],
                  'marked': marked, 'present': True}
    return out


def nginx_part(r, last):
    """The dashboard's server: its TLS, and who may reach which page."""
    said = []
    conf = nginx_conf()
    if not r['tls'] and not r['access'] and not r.get('acme'):
        return said, False
    try:
        with open(conf) as f:
            main = f.read()
    except OSError as e:
        raise Refused('the dashboard\'s nginx file cannot be read (%s): %s' % (conf, e))
    where = server_block(main)
    if not where:
        raise Refused('no HTTPS server { } was found in %s' % conf)
    files = tls_files(main[where[0]:where[1]])
    snap = snapshot([conf] + list(files.values()))
    changed, hup = False, False
    kept_before = None
    try:
        if r['tls'] and r['tls'].get('put_back'):
            r['tls']['raw'] = acme_before_read()
        if r['tls'] and r['tls'].get('keep_before'):
            kept_before = acme_before_now(main[where[0]:where[1]], files)
        if r['tls']:
            # DH parameters first: making them can take minutes, and nginx's
            # file is read after it, so nothing changed in it meanwhile is
            # written over with an older copy
            dh_file(r['tls']['dh'], files['dh'], last.get('dh'))
            with open(conf) as f:
                main = f.read()
            where = server_block(main)
            block = main[where[0]:where[1]]
            new, words, wrote = tls_into(block, r['tls'], files, r['tls']['dh'])
            if new != block:
                main = main[:where[0]] + new + main[where[1]:]
                write_root(conf, main, 0o644)
            changed = True
            said += words
            if wrote and mosquitto_reads([files['cert'], files['key']]):
                hup = True
        if r['access']:
            new_main = access_into(main, r['access'])
            if new_main != main:
                write_root(conf, new_main, 0o644)
                main, changed = new_main, True
                said.append('nginx: who may reach the dashboard, the one-tap links and the SMS '
                            'road set')
        if r.get('acme') is not None:
            with open(conf) as f:
                main = f.read()
            new_main, words = acme_http_into(main, r['acme']['http'])
            if new_main != main:
                write_root(conf, new_main, 0o644)
                main, changed = new_main, True
            said += words
        if changed:
            progress('asking nginx, and reloading it', 4)
            t = subprocess.run(NGINX_TEST, capture_output=True, text=True)
            if t.returncode != 0:
                raise Refused('nginx does not take it, so it is as it was: %s'
                              % ((t.stderr or '').strip().splitlines() or ['?'])[-1][:300])
            service('reload', 'nginx')
            said.append('nginx reloaded')
    except BaseException:
        put_back(snap)
        raise
    if kept_before:
        own_write(ACME_BEFORE, kept_before)
        said.append('the certificate it had is kept, to be put back (Automatic certificates)')
    if r['tls'] and r['tls'].get('put_back'):
        try:
            os.unlink(os.path.join(own_fd(), ACME_BEFORE))
        except OSError:
            pass
    if hup:
        said.append(mosquitto_hup())
    return said, changed


# ---- Automatic certificates (5.30) ------------------------------------------------
# The ACME CA's HTTP-01 question comes to port 80 of the name: the plain-HTTP
# server, which otherwise only sends everybody to HTTPS, gets a location of
# its own for /.well-known/acme-challenge/, handed to index.php (and so to the
# daemon, which answers only the tokens of an order it has going). Between
# marks; the server's own `return 301 ...` line is set aside while they stand
# (a return at the server's level is done before any location is looked at),
# moved into a `location /` of the block, and comes back as it was when ACME
# is switched off or goes to DNS-01.
ACME_BEGIN = '#zigmon# ACME-BEGIN'
ACME_END = '#zigmon# ACME-END'
ACME_ASIDE = '#zigmon# '
ACME_BEFORE = 'acme-before.json'
ACME_LOC = '/.well-known/acme-challenge/'


def acme_marked(block):
    """zigmon's marks for the CA in a block, as a line of their own."""
    return bool(re.search(r'(?m)^[ \t]*%s' % re.escape(ACME_BEGIN), block))


def http_block(text):
    """(start, end) of the plain-HTTP server { }: not the HTTPS one, and the
    one that sends to HTTPS (or already carries zigmon's ACME marks)."""
    https = server_block(text)
    i = 0
    while True:
        m = re.search(r'(?m)^[ \t]*server[ \t]*\{', text[i:])
        if not m:
            return None
        start = i + m.start()
        end = block_end(text, i + m.end() - 1)
        if end is None:
            return None
        block = text[start:end]
        if (not https or start != https[0]) and not re.search(r'(?m)^\s*listen\s+[^;]*ssl', block) \
                and (acme_marked(block) or re.search(r'return\s+30[1278]\s+https://', block)):
            return start, end
        i = end


def acme_http_now(text=None):
    """Whether port 80 answers the CA now: (marked, a port-80 server is there)."""
    if text is None:
        try:
            with open(nginx_conf()) as f:
                text = f.read()
        except OSError:
            return False, False
    where = http_block(text)
    if not where:
        return False, False
    return acme_marked(text[where[0]:where[1]]), True


def acme_http_lines(text, aside):
    """zigmon's lines for the CA - PHP reached the way the HTTPS server
    reaches it."""
    where = server_block(text)
    block = text[where[0]:where[1]] if where else ''
    fpm = re.search(r'(?m)^\s*fastcgi_pass\s+([^;\s]+)\s*;', block)
    fpm = fpm.group(1) if fpm else 'unix:/run/php-fpm/www.sock'
    if not re.match(r'^(unix:/[A-Za-z0-9_./-]+|[A-Za-z0-9.\[\]:-]+:\d+)$', fpm) or '..' in fpm:
        raise Refused('nginx reaches PHP by something that is not a plain socket: %s' % fpm[:80])
    docroot = directive(block, 'root') or '/var/www/zigmon'
    if not docroot.startswith('/') or '..' in docroot.split('/') or \
            not re.match(r'^[A-Za-z0-9_./-]+$', docroot):
        raise Refused('the dashboard\'s root is not a plain path: %s' % docroot[:80])
    inc = re.search(r'(?m)^\s*include\s+(\S*fastcgi_params)\s*;', block)
    inc = inc.group(1) if inc else 'fastcgi_params'
    pad = '    '
    lines = [pad + ACME_BEGIN + ' (Automatic certificates, set on the dashboard)',
             pad + 'location ^~ %s {' % ACME_LOC,
             pad + '    # the ACME CA\'s HTTP-01 question: answered by the daemon, through',
             pad + '    # index.php, for the tokens of an order it has going - nothing else']
    if re.search(r'limit_req_zone\s[^;]*zone=zigmon_tap:', text):
        lines.append(pad + '    limit_req zone=zigmon_tap burst=20 nodelay;')
    lines += [pad + '    client_max_body_size 1k;',
              pad + '    include        %s;' % inc,
              pad + '    fastcgi_pass   %s;' % fpm,
              pad + '    fastcgi_param  SCRIPT_FILENAME %s/index.php;' % docroot.rstrip('/'),
              pad + '    fastcgi_param  QUERY_STRING    api=acme-challenge;',
              pad + '    fastcgi_read_timeout 15s;',
              pad + '}']
    if aside:
        lines += [pad + 'location / {'] + [pad + '    ' + a.strip() for a in aside] + [pad + '}']
    lines.append(pad + ACME_END)
    return '\n'.join(lines)


def acme_http_into(text, on):
    """The nginx file with port 80 answering the CA, or not: (text, words).
    The same file twice gives the same file: the marks are taken out and put
    in again, never added to."""
    where = http_block(text)
    if not where:
        return text, (['no plain-HTTP server on port 80 in %s: the CA\'s HTTP-01 question cannot '
                       'be answered here (DNS-01 needs none)' % nginx_conf()] if on else [])
    block = text[where[0]:where[1]]
    if acme_marked(block):
        block = re.sub(r'\n*^[ \t]*%s[^\n]*\n.*?\n[ \t]*%s[^\n]*' % (re.escape(ACME_BEGIN),
                                                                      re.escape(ACME_END)),
                       '', block, count=1, flags=re.S | re.M)
        block = re.sub(r'(?m)^([ \t]*)%s(return\s[^\n]*)$' % re.escape(ACME_ASIDE), r'\1\2', block)
    if on:
        lines = block.split('\n')
        depth, aside = 0, []
        for n, line in enumerate(lines):
            if depth == 1 and re.match(r'^\s*return\s', line):
                aside.append(line)
                lines[n] = re.sub(r'^(\s*)', lambda m: m.group(1) + ACME_ASIDE, line, count=1)
            depth += line.count('{') - line.count('}')
        block = '\n'.join(lines)
        close = block.rfind('}')
        block = block[:close].rstrip('\n') + '\n\n' + acme_http_lines(text, aside) + '\n' + block[close:]
    new = text[:where[0]] + block + text[where[1]:]
    if new == text:
        return text, []
    if on:
        return new, ['nginx: port 80 answers the ACME CA at %s' % ACME_LOC]
    return new, ['nginx: port 80 no longer answers the ACME CA; it only sends to HTTPS again']


def acme_before_now(block, files):
    """The certificate in place now, its key and what it is checked against,
    as the files have them - kept by root alone (root's own folder, 0600)."""
    try:
        with open(files['cert']) as f:
            cert = f.read(300000)
        with open(files['key']) as f:
            key = f.read(100000)
    except OSError:
        return None
    trust = ''
    if directive(block, 'ssl_trusted_certificate') and os.path.isfile(files['root']):
        with open(files['root']) as f:
            trust = f.read(300000)
    return {'cert': cert, 'key': key, 'trust': trust, 'at': time.time(),
            'info': cert_info(files['cert'])}


def acme_before_read():
    got = own_read(ACME_BEFORE)
    if not isinstance(got, dict) or not got.get('cert') or not got.get('key'):
        raise Refused('there is no certificate from before ACME here to put back')
    first = re.search(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', got['cert'], re.S)
    if not first:
        raise Refused('the certificate from before ACME does not read')
    pem_set(first.group(0), got['key'])          # its own key, and not run out
    return {'cert': got['cert'], 'key': got['key'], 'trust': got.get('trust') or ''}


def acme_look():
    """For the dashboard: whether port 80 answers the CA, and the certificate
    kept from before ACME (what it is - never its key)."""
    marked, port80 = acme_http_now()
    got = own_read(ACME_BEFORE)
    before = None
    if isinstance(got, dict) and got.get('cert'):
        before = dict(got.get('info') or {}, at=got.get('at'))
    return {'http': marked, 'port80': port80, 'before': before}


def cert_info(path):
    """What a certificate file says about itself, for the dashboard."""
    try:
        with open(path) as f:
            text = f.read()
    except OSError:
        return None
    blocks = re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', text, re.S)
    if not blocks:
        return None
    try:
        out = openssl(['x509', '-noout', '-subject', '-issuer', '-startdate', '-enddate',
                       '-nameopt', 'RFC2253', '-ext', 'subjectAltName', '-text'],
                      'the certificate', blocks[0] + '\n')
    except Refused:
        return None
    info = {'chain': len(blocks) - 1}

    def field(name):
        m = re.search(r'(?m)^%s=\s*(.*)$' % name, out)
        return m.group(1).strip() if m else ''
    info['subject'] = field('subject')
    info['issuer'] = field('issuer')
    m = re.search(r'(?:^|,)CN=([^,]+)', info['subject'])
    info['cn'] = m.group(1) if m else info['subject']
    for k, name in (('not_before', 'notBefore'), ('not_after', 'notAfter')):
        try:
            info[k] = int(calendar.timegm(time.strptime(field(name), '%b %d %H:%M:%S %Y %Z')))
        except ValueError:
            info[k] = None
    san = re.search(r'Subject Alternative Name:[^\n]*\n\s*([^\n]+)', out)
    info['san'] = [x.strip().split(':', 1)[-1] for x in san.group(1).split(',')] if san else []
    alg = re.search(r'Public Key Algorithm:\s*(\S+)', out)
    bits = re.search(r'Public-Key:\s*\((\d+) bit\)', out)
    kind = (alg.group(1) if alg else '?').replace('rsaEncryption', 'RSA').replace('id-ecPublicKey', 'EC')
    info['key'] = '%s %s' % (kind, bits.group(1)) if bits else kind
    info['self_signed'] = info['subject'] == info['issuer']
    return info


def tls_now():
    conf = nginx_conf()
    try:
        with open(conf) as f:
            text = f.read()
    except OSError:
        return {'conf': conf, 'readable': False}
    where = server_block(text)
    if not where:
        return {'conf': conf, 'readable': True, 'server': False}
    block = text[where[0]:where[1]]
    files = tls_files(block)
    out = {'conf': conf, 'readable': True, 'server': True, 'files': files,
           'info': cert_info(files['cert']),
           'dual': len(directives(block, 'ssl_certificate')) > 1,
           'alt_info': cert_info(files['alt_cert']) if len(directives(block, 'ssl_certificate')) > 1 else None,
           'root_info': cert_info(files['root']) if os.path.exists(files['root']) else None,
           'protocols': (directive(block, 'ssl_protocols') or '').split(),
           'ciphers': directive(block, 'ssl_ciphers') or '',
           'prefer': (directive(block, 'ssl_prefer_server_ciphers') or 'off') == 'on',
           'dhparam': directive(block, 'ssl_dhparam') or '',
           'hsts': 0, 'broker': mosquitto_reads([files['cert'], files['key']])}
    m = re.search(r'(?m)^\s*add_header\s+Strict-Transport-Security\s+"?max-age=(\d+)', block)
    if m:
        out['hsts'] = int(m.group(1))
    names = directive(block, 'server_name')
    out['server_name'] = (names or '').split()[0] if names else ''
    if out['info'] and os.path.exists(files['root']):
        # kept as it was: the first certificate of the file against the
        # trusted file - which holds the chain too, so it says nothing of
        # what nginx sends; chain_check does
        got = subprocess.run(['openssl', 'verify', '-CAfile', files['root'], files['cert']],
                             capture_output=True, text=True)
        out['verify'] = 'ok' if got.returncode == 0 else (
            (got.stdout + got.stderr).strip().splitlines() or ['does not verify'])[-1][:200]
    if out['info']:
        out['chain_check'] = chain_check(files['cert'], files['root'])
    if out['alt_info']:
        out['alt_chain_check'] = chain_check(files['alt_cert'], files['root'])
    # the port nginx answers TLS on for this server (the daemon's check of
    # what it sends), and what the files hold that anybody may have: the
    # certificates as sent and the company roots kept to check with - never
    # the key. The daemon completes the chain from them (tls_chain).
    out['port'] = listen_port(block)
    pems = {'cert': '', 'chain': [], 'roots': [], 'alt_cert': '', 'alt_chain': []}
    for k, path in (('cert', files['cert']), ('alt_cert', files['alt_cert'] if out['alt_info'] else '')):
        got = pem_blocks(path)
        if got:
            pems[k] = got[0]
            pems[k.replace('cert', 'chain')] = got[1:]
    pems['roots'] = [c for c in pem_blocks(files['root']) if cert_names(c)[0] and len(set(cert_names(c))) == 1]
    out['pems'] = pems
    out['fp'] = fingerprint(pems['cert']) if pems['cert'] else ''
    out['roots_given'] = [dn_cn(cert_names(c)[0]) for c in pems['roots']]
    return out


def listen_port(block):
    """The port of the server's `listen ... ssl` (443 when none says)."""
    for v in directives(block, 'listen'):
        if 'ssl' in v.split():
            m = re.search(r'(?:^|[:\]])(\d{1,5})$', v.split()[0])
            if m:
                return int(m.group(1))
    return 443


def pem_blocks(path):
    """The certificates of a file, in order; [] unread."""
    if not path:
        return []
    try:
        with open(path) as f:
            return PEM_CERT_RE.findall(f.read(1 << 20))
    except OSError:
        return []


CA_BUNDLES = ('/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem', '/etc/ssl/certs/ca-certificates.crt',
              '/etc/pki/tls/certs/ca-bundle.crt', '/etc/ssl/cert.pem')
PEM_CERT_RE = re.compile(r'-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----')


def ca_bundle():
    """The file of the roots this system trusts - what clients here check
    against. ZIGMON_TEST_CA_BUNDLE stands in for it in the checks."""
    f = os.environ.get('ZIGMON_TEST_CA_BUNDLE')
    if f:
        return f
    for f in CA_BUNDLES:
        if os.path.isfile(f):
            return f
    return ''


def cert_names(pem):
    """(subject, issuer) of one certificate, RFC 2253; ('', '') unread."""
    try:
        out = openssl(['x509', '-noout', '-subject', '-issuer', '-nameopt', 'RFC2253'], 'a certificate',
                      pem.strip() + '\n')
    except Refused:
        return '', ''
    s = re.search(r'(?m)^subject=\s*(.*)$', out)
    i = re.search(r'(?m)^issuer=\s*(.*)$', out)
    return (s.group(1).strip() if s else ''), (i.group(1).strip() if i else '')


def dn_cn(dn):
    m = re.search(r'(?:^|,)CN=([^,]+)', dn or '')
    return (m.group(1) if m else dn or '').strip()[:120]


def chain_check(cert_file, root_file):
    """What nginx sends, checked as a client checks it: the first certificate
    of the file, the rest as the chain sent (untrusted), against the
    system's roots and - from the trusted file - only the self-signed ones (a
    company root). The trusted file holds the chain too: checked against it
    a certificate sent without its intermediate looked whole. {ok, sent,
    up_to, missing, self_signed}; None when it cannot be read."""
    try:
        with open(cert_file) as f:
            blocks = PEM_CERT_RE.findall(f.read())
    except OSError:
        return None
    if not blocks:
        return None
    leaf, rest = blocks[0], blocks[1:]
    subj, iss = cert_names(leaf)
    out = {'ok': True, 'sent': len(rest), 'up_to': '', 'missing': '', 'self_signed': bool(subj) and subj == iss}
    if out['self_signed']:
        out['up_to'] = dn_cn(subj)
        return out
    trust = ''
    bundle = ca_bundle()
    if bundle:
        try:
            with open(bundle) as f:
                trust = f.read()
        except OSError:
            trust = ''
    private = False
    try:
        with open(root_file) as f:
            for c in PEM_CERT_RE.findall(f.read()):
                s, i = cert_names(c)
                if s and s == i:
                    trust += '\n' + c + '\n'
                    private = True
    except OSError:
        pass
    with tempfile.TemporaryDirectory(prefix='zigmon-chain-') as t:
        for n, v in (('trust.pem', trust), ('leaf.pem', leaf + '\n'), ('rest.pem', '\n'.join(rest) + '\n')):
            with open(os.path.join(t, n), 'w') as fh:
                fh.write(v)
        args = ['openssl', 'verify', '-show_chain']
        if 'BEGIN CERTIFICATE' in trust:
            args += ['-CAfile', os.path.join(t, 'trust.pem')]
        if os.environ.get('ZIGMON_TEST_CA_BUNDLE'):
            args.append('-no-CApath')
        if rest:
            args += ['-untrusted', os.path.join(t, 'rest.pem')]
        got = subprocess.run(args + [os.path.join(t, 'leaf.pem')], capture_output=True, text=True,
                             stdin=subprocess.DEVNULL, timeout=60)
    if got.returncode == 0:
        deep = re.findall(r'(?m)^depth=\d+:\s*(.*?)(?:\s*\(untrusted\))?\s*$', got.stdout)
        top = deep[-1] if deep else ''
        m = re.search(r'(?:^|[,/]\s*)CN\s*=\s*([^,/]+)', top)
        out['up_to'] = (m.group(1).strip() if m else top)[:120]
        if private and not chain_verifies(leaf, rest, bundle):
            # whole only with the company root kept here: clients that do not
            # trust it refuse it all the same
            out['private_root'] = out['up_to']
        return out
    # where the chain sent stops: the issuer of the last link found
    out['ok'] = False
    names = [cert_names(c) for c in rest]
    at, seen = iss, set()
    while at and at not in seen:
        seen.add(at)
        nxt = next((n for n in names if n[0] == at), None)
        if nxt and nxt[0] == nxt[1]:
            # all there, up to a root sent with it that is not trusted here
            out['untrusted'] = dn_cn(at)
            at = ''
            break
        if not nxt:
            break
        at = nxt[1]
    out['missing'] = dn_cn(at)
    out['said'] = unpath(((got.stdout + got.stderr).strip().splitlines() or ['does not verify'])[-1])[:200]
    return out


def unpath(text):
    """openssl's words without the temporary files it was handed."""
    return re.sub(r'(?:error\s+)?/\S*zigmon-(?:chain|root)-\S*?\.pem:?\s*', '', str(text or '')).strip() or \
        'does not verify'


def chain_verifies(leaf, chain, bundle):
    """Whether a certificate with this chain sent leads to a root of the
    file `bundle` (the system's) - nothing else trusted."""
    if not bundle:
        return False
    with tempfile.TemporaryDirectory(prefix='zigmon-chain-') as t:
        for n, v in (('leaf.pem', leaf.strip() + '\n'), ('rest.pem', ''.join(c.strip() + '\n' for c in chain))):
            with open(os.path.join(t, n), 'w') as fh:
                fh.write(v)
        args = ['openssl', 'verify', '-CAfile', bundle]
        if os.environ.get('ZIGMON_TEST_CA_BUNDLE'):
            args.append('-no-CApath')
        if chain:
            args += ['-untrusted', os.path.join(t, 'rest.pem')]
        got = subprocess.run(args + [os.path.join(t, 'leaf.pem')], capture_output=True, text=True,
                             stdin=subprocess.DEVNULL, timeout=60)
    return got.returncode == 0


def issued_by(c, issuer):
    """Whether `issuer` signed `c`: its name, and the signature (no root
    needed - openssl's partial chain)."""
    if cert_names(issuer)[0] != cert_names(c)[1]:
        return False
    with tempfile.TemporaryDirectory(prefix='zigmon-chain-') as t:
        for n, v in (('ca.pem', issuer), ('c.pem', c)):
            with open(os.path.join(t, n), 'w') as fh:
                fh.write(v.strip() + '\n')
        got = subprocess.run(['openssl', 'verify', '-no-CApath', '-partial_chain', '-CAfile',
                              os.path.join(t, 'ca.pem'), os.path.join(t, 'c.pem')],
                             capture_output=True, stdin=subprocess.DEVNULL, timeout=60)
    return got.returncode == 0


def fingerprint(pem):
    der = subprocess.run(['openssl', 'x509', '-outform', 'DER'], input=pem.strip().encode() + b'\n',
                         capture_output=True, timeout=60).stdout
    return hashlib.sha256(der).hexdigest() if der else ''


def chain_checked(leaf, fp, chain, what):
    """The chain asked for one certificate in place: `fp` must be the one
    nginx sends now, the chain certificates only (no key, no root), each the
    issuer of the one before it."""
    fp = re.sub(r'[^0-9a-f]', '', str(fp or '').lower())
    if len(fp) != 64 or not leaf or fingerprint(leaf) != fp:
        raise Refused('%s in place is not the one the chain was made for - look again' % what)
    if not isinstance(chain, list) or len(chain) > 8:
        raise Refused('the chain of %s is a list of a few certificates' % what)
    out, at = [], leaf
    for c in chain:
        c = str(c or '')
        if 'PRIVATE KEY' in c or not CERT_RE.match(c) or len(PEM_CERT_RE.findall(c)) != 1:
            raise Refused('the chain of %s is certificates, one by one - nothing else' % what)
        s, i = cert_names(c)
        if not s or s == i:
            raise Refused('a root is never sent with %s - only the authorities between it and the root' % what)
        if not issued_by(at, c):
            raise Refused('the chain of %s does not go up from it: %s did not sign %s' % (
                what, dn_cn(s), dn_cn(cert_names(at)[0])))
        out.append(c.strip())
        at = c
    return out


def chain_roots(raw, chain, alt_chain):
    """(roots, trusted file) of a chain asked for: the company roots given
    to check with, self-signed only, and the file nginx trusts - the roots
    and the chains, as trust_of() makes it for an upload."""
    root = str(raw.get('root') or '')
    if 'PRIVATE KEY' in root or (root.strip() and not CERT_RE.match(root)):
        raise Refused('the root is certificates only (-----BEGIN CERTIFICATE-----)')
    roots = PEM_CERT_RE.findall(root)
    if len(roots) > 4:
        raise Refused('%d roots - a certificate leads to one' % len(roots))
    for c in roots:
        s, i = cert_names(c)
        if not s or s != i:
            raise Refused('%s is not a root (it is not self-signed): it belongs in the chain' % dn_cn(s))
    if not chain and not roots and not alt_chain:
        raise Refused('nothing to put in: no chain and no root')
    trust = trust_of({'root': ''.join(c.strip() + '\n' for c in roots),
                      'chain': ''.join(c + '\n' for c in chain)},
                     {'own_trust': True, 'chain': ''.join(c + '\n' for c in alt_chain), 'root': ''})
    return roots, trust


def tls_chain(raw):
    """(tls_chain) The chain of the certificate in place, and the company
    root kept to check with - the certificate itself and its key as they are:
    the cert file the same certificate with the new chain after it, the
    trusted file (OCSP stapling) the root and the chains, as an upload puts
    them. nginx -t, a reload, the broker told; as it was when nginx says no."""
    conf = nginx_conf()
    with open(conf) as f:
        main = f.read()
    where = server_block(main)
    if not where:
        raise Refused('no HTTPS server { } was found in %s' % conf)
    block = main[where[0]:where[1]]
    files = tls_files(block)
    dual = len(directives(block, 'ssl_certificate')) > 1
    leaf = (pem_blocks(files['cert']) or [''])[0]
    chain = chain_checked(leaf, raw.get('fp'), raw.get('chain'), 'the certificate')
    alt = raw.get('alt') if isinstance(raw.get('alt'), dict) else None
    alt_leaf, alt_chain = '', []
    if alt and dual:
        alt_leaf = (pem_blocks(files['alt_cert']) or [''])[0]
        alt_chain = chain_checked(alt_leaf, alt.get('fp'), alt.get('chain'), 'the second certificate')
    roots, trust = chain_roots(raw, chain, alt_chain)
    snap = snapshot([conf, files['cert'], files['alt_cert'], files['root']])
    said = []
    try:
        progress('writing the chain of the certificate', 3)
        write_root(files['cert'], leaf.strip() + '\n' + ''.join(c + '\n' for c in chain), 0o644)
        if alt_leaf:
            write_root(files['alt_cert'], alt_leaf.strip() + '\n' + ''.join(c + '\n' for c in alt_chain), 0o644)
        if trust:
            write_root(files['root'], trust, 0o644)
            new = set_directive(block, 'ssl_trusted_certificate', files['root'])
            if new != block:
                write_root(conf, main[:where[0]] + new + main[where[1]:], 0o644)
        said.append('the chain of %s: %s' % (dn_cn(cert_names(leaf)[0]), ', '.join(
            dn_cn(cert_names(c)[0]) for c in chain) or 'none'))
        if alt_leaf:
            said.append('the chain of the second one: %s' % (', '.join(
                dn_cn(cert_names(c)[0]) for c in alt_chain) or 'none'))
        if roots:
            said.append('the root kept to check with (never sent): %s' % ', '.join(
                dn_cn(cert_names(c)[0]) for c in roots))
        progress('asking nginx, and reloading it', 4)
        t = subprocess.run(NGINX_TEST, capture_output=True, text=True)
        if t.returncode != 0:
            raise Refused('nginx does not take it, so it is as it was: %s'
                          % ((t.stderr or '').strip().splitlines() or ['?'])[-1][:300])
        service('reload', 'nginx')
        said.append('nginx reloaded')
    except BaseException:
        put_back(snap)
        raise
    if mosquitto_reads([files['cert'], files['key']]):
        said.append(mosquitto_hup())
    return {}, said


# ---- the firewall -------------------------------------------------------------
# iptables: a chain of its own, ZIGMON-IN, jumped to first from INPUT - the
# loopback, the answers to what this machine asked itself, IPv6's neighbour
# discovery, then the rules in the order the dashboard gives them; what it
# does not let in goes back to INPUT and the rules that were there before.
# Kept in /etc/sysconfig/iptables and ip6tables between lines that start
# "# zigmon:", so it is there after a reboot.
#
# firewalld: rich rules, in every active zone, with a priority below zero so
# they are looked at before the zone's own services and ports - in the order
# the dashboard gives them. firewalld's own rules are left exactly as they
# are; which rich rules are zigmon's is kept in root's own folder, so they
# can be taken away again and nothing else is ever touched.
FW_CHAIN = 'ZIGMON-IN'
FW_FILES = {4: os.environ.get('ZIGMON_FW_FILE4', '/etc/sysconfig/iptables'),
            6: os.environ.get('ZIGMON_FW_FILE6', '/etc/sysconfig/ip6tables')}
FW_TOOLS = {4: ('iptables', 'iptables-restore', 'iptables-save'),
            6: ('ip6tables', 'ip6tables-restore', 'ip6tables-save')}
FW_PROTOS = ('tcp', 'udp', 'icmp', 'vrrp', 'any')
# (5.53.3) a rule may name the port an answer comes FROM: mDNS answers sent by unicast come
# from port 5353 to whatever port the question went out of. The daemon looks for this name
# in this file before it asks for such a rule, so an older helper is never handed one
FW_SPORT = True
FW_MARK = '# zigmon:'
FWD_STATE = 'firewalld-rules.json'
FWD_FIRST = -30000                  # the first rule; one more for every rule after it


def tool(name):
    if IPT_PREFIX:
        p = os.path.join(IPT_PREFIX, name)
        return p if os.access(p, os.X_OK) else None
    return shutil.which(name)


def firewalld_running():
    if not (shutil.which(FIREWALL_CMD) or os.access(FIREWALL_CMD, os.X_OK)):
        return False
    return subprocess.run([FIREWALL_CMD, '--state'], capture_output=True).returncode == 0


def fw_backend():
    if firewalld_running():
        return 'firewalld'
    if tool('iptables'):
        return 'iptables'
    return ''


def fw_rule_checked(x):
    if not isinstance(x, dict):
        raise Refused('a firewall rule is not an object')
    try:
        fam = int(x.get('family') or 0)
    except (TypeError, ValueError):
        fam = 0
    if fam not in (4, 6):
        raise Refused('a firewall rule is for IPv4 or IPv6')
    proto = str(x.get('proto') or 'any')
    if proto not in FW_PROTOS:
        raise Refused('the protocol is one of %s' % ', '.join(FW_PROTOS))
    port = str(x.get('port') or '').replace(' ', '')
    if port:
        if proto not in ('tcp', 'udp'):
            raise Refused('a port is for TCP or UDP')
        parts = port.split(',')
        if sum(2 if '-' in p else 1 for p in parts) > 15 or \
                not all(re.fullmatch(r'[0-9]{1,5}(-[0-9]{1,5})?', p) for p in parts):
            raise Refused('the ports are numbers or ranges, by commas: 80,443 or 8000-8100')
        for p in parts:
            a, _, b = p.partition('-')
            if not 1 <= int(a) <= 65535 or (b and not int(a) <= int(b) <= 65535):
                raise Refused('%s is not a port or a range of them' % p)
    sport = str(x.get('sport') or '').strip()
    if sport:
        if proto not in ('tcp', 'udp') or port:
            raise Refused('a port answers come from is for TCP or UDP, on a rule without a port')
        if not re.fullmatch(r'[0-9]{1,5}', sport) or not 1 <= int(sport) <= 65535:
            raise Refused('%s is not a port' % sport[:20])
    src = str(x.get('source') or '').strip()
    if src:
        try:
            net = plain(src, 'network')
        except ValueError:
            raise Refused('%r is not an address or a network' % src[:60])
        if net.version != fam:
            raise Refused('%s is not an IPv%d address' % (src, fam))
        src = str(net)
    action = str(x.get('action') or 'accept')
    if action not in ('accept', 'drop', 'reject'):
        raise Refused('a rule accepts, drops or rejects')
    note = re.sub(r'[^A-Za-z0-9 ._:/@()+,-]', '', str(x.get('note') or ''))[:120]
    out = {'family': fam, 'proto': proto, 'port': port, 'source': src, 'action': action,
           'note': note}
    if sport:
        out['sport'] = sport
    return out


# -- iptables --
def fw_args(r):
    a = ['-A', FW_CHAIN]
    if r['source']:
        a += ['-s', r['source']]
    if r['proto'] != 'any':
        proto = 'ipv6-icmp' if (r['proto'] == 'icmp' and r['family'] == 6) else r['proto']
        a += ['-p', proto]
    if r['port']:
        if ',' in r['port']:
            a += ['-m', 'multiport', '--dports', r['port'].replace('-', ':')]
        else:
            a += ['--dport', r['port'].replace('-', ':')]
    if r.get('sport'):
        a += ['--sport', r['sport']]
    a += ['-m', 'comment', '--comment', '"zigmon: %s"' % (r['note'] or r['proto'])]
    a += ['-j', r['action'].upper()]
    return ' '.join(a)


def fw_base(fam):
    """What the chain lets through before anybody's rule: the loopback, the
    answers to what this machine asked itself (MQTT out to a broker, the
    boxes it polls, DNS, ntfy), and on IPv6 the neighbour discovery it
    cannot live without. Ahead of the rules, so a DROP of somebody's never
    shuts them out."""
    out = ['-A %s -i lo -m comment --comment "zigmon: loopback" -j ACCEPT' % FW_CHAIN,
           '-A %s -m conntrack --ctstate ESTABLISHED,RELATED -m comment --comment '
           '"zigmon: answers" -j ACCEPT' % FW_CHAIN]
    if fam == 6:
        out += ['-A %s -p ipv6-icmp -m icmp6 --icmpv6-type %d -m comment --comment '
                '"zigmon: neighbour discovery" -j ACCEPT' % (FW_CHAIN, t) for t in (133, 134, 135, 136)]
    return out


def fw_strip(text):
    """A saved ruleset without anything zigmon put in it."""
    out = []
    for line in text.split('\n'):
        k = re.sub(r'^\[\d+:\d+\]\s+', '', line.strip())
        if k.startswith(FW_MARK) or re.match(r'^:%s - \[\d+:\d+\]$' % FW_CHAIN, k) or \
                k == '-A INPUT -j %s' % FW_CHAIN or k.startswith('-A %s ' % FW_CHAIN):
            continue
        out.append(line)
    return '\n'.join(out)


def fw_into(text, lines, on):
    """zigmon's chain into a saved ruleset (iptables-services' file), in the
    *filter table: its name, the jump from INPUT first, its rules last."""
    text = fw_strip(text)
    if not on:
        return text
    rows = text.split('\n')
    try:
        start = next(i for i, l in enumerate(rows) if l.strip() == '*filter')
    except StopIteration:
        rows += ['*filter', ':INPUT ACCEPT [0:0]', ':FORWARD ACCEPT [0:0]',
                 ':OUTPUT ACCEPT [0:0]', 'COMMIT']
        start = len(rows) - 5
    end = next((i for i in range(start + 1, len(rows)) if rows[i].strip() == 'COMMIT'), None)
    if end is None:
        raise Refused('the saved firewall has a *filter table without COMMIT')
    last_decl = max([i for i in range(start, end) if rows[i].startswith(':')] or [start])
    first_input = next((i for i in range(start, end) if rows[i].startswith('-A INPUT')), end)
    block = ['%s zigmon opens what its functions need here (dashboard: Firewall and access); '
             'changed only there' % FW_MARK] + lines + ['%s end' % FW_MARK]
    rows = (rows[:last_decl + 1] + [':%s - [0:0]' % FW_CHAIN] +
            rows[last_decl + 1:first_input] +
            ['%s every rule zigmon makes is in %s' % (FW_MARK, FW_CHAIN), '-A INPUT -j %s' % FW_CHAIN] +
            rows[first_input:end] + block + rows[end:])
    return '\n'.join(rows)


def fw_said(stderr):
    lines = [x.strip() for x in (stderr or '').strip().splitlines()
             if x.strip() and not x.strip().startswith('Try `')]
    return '; '.join(lines[-3:]) or '?'


def ipt_apply(f, said):
    for fam in (4, 6):
        ipt, restore, _save = (tool(n) for n in FW_TOOLS[fam])
        lines = fw_base(fam) + [fw_args(r) for r in f['rules'] if r['family'] == fam]
        if not ipt or not restore:
            continue
        if f['on']:
            snippet = '*filter\n:%s - [0:0]\n%s\nCOMMIT\n' % (FW_CHAIN, '\n'.join(lines))
            got = subprocess.run([restore, '--noflush'], input=snippet, capture_output=True, text=True)
            if got.returncode != 0:
                raise Refused('%s does not take the rules: %s' % (FW_TOOLS[fam][1], fw_said(got.stderr)))
            if subprocess.run([ipt, '-C', 'INPUT', '-j', FW_CHAIN], capture_output=True).returncode != 0:
                subprocess.run([ipt, '-I', 'INPUT', '1', '-j', FW_CHAIN], capture_output=True)
            said.append('IPv%d: %d rule(s) in %s' % (fam, len(lines), FW_CHAIN))
        else:
            ipt_take_away(ipt)
        path = FW_FILES[fam]
        if os.path.exists(path):
            with open(path) as fh:
                old = fh.read()
            new = fw_into(old, lines, f['on'])
            if new != old:
                fd, tmp = tempfile.mkstemp(prefix='.zigmon-fw-', dir=os.path.dirname(path))
                with os.fdopen(fd, 'w') as fh:
                    fh.write(new if new.endswith('\n') else new + '\n')
                    fh.flush()
                    os.fchmod(fh.fileno(), os.stat(path).st_mode & 0o777)
                test = subprocess.run([restore, '--test', tmp], capture_output=True, text=True)
                if test.returncode != 0:
                    os.unlink(tmp)
                    raise Refused('%s would not take the file, so it was left as it was: %s' % (
                        FW_TOOLS[fam][1], fw_said(test.stderr)))
                os.replace(tmp, path)
                relabel(path)
                said.append('%s: kept over a reboot' % path)
        elif f['on']:
            said.append('IPv%d: not kept over a reboot - %s is not there (dnf install '
                        'iptables-services)' % (fam, path))


def ipt_take_away(ipt):
    while subprocess.run([ipt, '-D', 'INPUT', '-j', FW_CHAIN], capture_output=True).returncode == 0:
        pass
    subprocess.run([ipt, '-F', FW_CHAIN], capture_output=True)
    subprocess.run([ipt, '-X', FW_CHAIN], capture_output=True)


def ipt_full(fam):
    save = tool(FW_TOOLS[fam][2])
    if not save:
        return []
    got = subprocess.run([save, '-t', 'filter'], capture_output=True, text=True)
    out = []
    for line in got.stdout.split('\n'):
        line = re.sub(r'^\[\d+:\d+\]\s+', '', line.strip())
        if not line or line.startswith('#') or line in ('*filter', 'COMMIT'):
            continue
        out.append(re.sub(r' \[\d+:\d+\]$', '', line))
    return out[:1500]


def ipt_part(f, said):
    was_live, was_file = {}, {}
    for fam in (4, 6):
        save = tool(FW_TOOLS[fam][2])
        if save:
            was_live[fam] = subprocess.run([save], capture_output=True, text=True).stdout
        if os.path.exists(FW_FILES[fam]):
            was_file[fam] = snapshot([FW_FILES[fam]])
    try:
        ipt_apply(f, said)
    except BaseException:
        for fam, text in was_live.items():
            restore, ipt = tool(FW_TOOLS[fam][1]), tool(FW_TOOLS[fam][0])
            if text.strip() and restore:
                subprocess.run([restore], input=text, capture_output=True, text=True)
            elif ipt:
                ipt_take_away(ipt)
        for snap in was_file.values():
            put_back(snap)
        raise


# -- firewalld --
def fwd(*args):
    return subprocess.run([FIREWALL_CMD] + list(args), capture_output=True, text=True)


def fwd_zones():
    """Every zone an interface or a source is in now; the default zone when
    none is."""
    got = fwd('--get-active-zones')
    zones = [l.strip() for l in got.stdout.split('\n') if l.strip() and not l.startswith((' ', '\t'))]
    zones = [z for z in zones if re.match(r'^[A-Za-z0-9_-]{1,40}$', z)]
    if not zones:
        d = fwd('--get-default-zone').stdout.strip()
        if re.match(r'^[A-Za-z0-9_-]{1,40}$', d):
            zones = [d]
    return list(dict.fromkeys(zones))


def rich(r, priority):
    """One rule as firewalld's rich rules - one per port where it names
    several, since a rich rule takes one port or one range."""
    head = 'rule family="ipv%d" priority="%d"' % (r['family'], priority)
    if r['source']:
        head += ' source address="%s"' % r['source']
    act = {'accept': 'accept', 'drop': 'drop', 'reject': 'reject'}[r['action']]
    if r['proto'] in ('tcp', 'udp') and r['port']:
        return ['%s port port="%s" protocol="%s" %s' % (head, p, r['proto'], act)
                for p in r['port'].split(',')]
    if r['proto'] in ('tcp', 'udp') and r.get('sport'):
        return ['%s source-port port="%s" protocol="%s" %s' % (head, r['sport'], r['proto'], act)]
    if r['proto'] in ('tcp', 'udp'):
        return ['%s protocol value="%s" %s' % (head, r['proto'], act)]
    if r['proto'] == 'icmp':
        return ['%s protocol value="%s" %s' % (head, 'icmp' if r['family'] == 4 else 'ipv6-icmp', act)]
    if r['proto'] == 'vrrp':
        return ['%s protocol value="vrrp" %s' % (head, act)]
    return ['%s %s' % (head, act)]


def own_fd():
    os.makedirs(OWN_DIR, mode=0o700, exist_ok=True)
    os.chmod(OWN_DIR, 0o700)
    return OWN_DIR


def own_read(name):
    try:
        with open(os.path.join(own_fd(), name)) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def own_write(name, data):
    path = os.path.join(own_fd(), name)
    fd, tmp = tempfile.mkstemp(dir=OWN_DIR)
    with os.fdopen(fd, 'w') as f:
        f.write(json.dumps(data))
        f.flush()
        os.fchmod(f.fileno(), 0o600)
    os.replace(tmp, path)


def fwd_part(f, said):
    had = own_read(FWD_STATE) or []
    had = [(z, r) for z, r in had if isinstance(z, str) and isinstance(r, str)]
    want = []
    if f['on']:
        zones = fwd_zones()
        if not zones:
            raise Refused('firewalld says no zone is active and names no default zone')
        n = 0
        for r in f['rules']:
            for one in rich(r, FWD_FIRST + n):
                for z in zones:
                    want.append((z, one))
            n += 1
    gone = [x for x in had if x not in want]
    new = [x for x in want if x not in had]
    done_add, done_rm = [], []
    try:
        for z, rr in gone:
            for perm in ([], ['--permanent']):
                fwd(*(perm + ['--zone=%s' % z, '--remove-rich-rule=%s' % rr]))
            done_rm.append((z, rr))
        for z, rr in new:
            for perm in ([], ['--permanent']):
                got = fwd(*(perm + ['--zone=%s' % z, '--add-rich-rule=%s' % rr]))
                if got.returncode != 0 and 'ALREADY_ENABLED' not in (got.stderr + got.stdout):
                    raise Refused('firewalld does not take %s in %s: %s' % (
                        rr, z, fw_said(got.stderr or got.stdout)))
            done_add.append((z, rr))
    except BaseException:
        for z, rr in done_add:
            for perm in ([], ['--permanent']):
                fwd(*(perm + ['--zone=%s' % z, '--remove-rich-rule=%s' % rr]))
        for z, rr in done_rm:
            for perm in ([], ['--permanent']):
                fwd(*(perm + ['--zone=%s' % z, '--add-rich-rule=%s' % rr]))
        raise
    own_write(FWD_STATE, want)
    if f['on']:
        said.append('firewalld: %d rich rule(s) of zigmon\'s in %s' % (
            len(want), ', '.join(sorted({z for z, _r in want})) or '-'))
    elif had:
        said.append('firewalld: zigmon\'s rich rules taken away; the rest is as it was')


def fwd_full():
    out = []
    ours = {r for _z, r in (own_read(FWD_STATE) or []) if isinstance(r, str)}
    for z in fwd_zones():
        got = fwd('--zone=%s' % z, '--list-all')
        for line in got.stdout.split('\n'):
            if line.strip():
                out.append(line.rstrip())
    return out[:1500], sorted(ours)


def fw_part(f):
    """The firewall as asked: (words, report)."""
    said = []
    backend = fw_backend()
    if f is None:
        return said, {'backend': backend}
    if not backend:
        if f['on']:
            raise Refused('there is neither firewalld nor iptables on this machine')
        return said, {'backend': backend}
    progress('the firewall', 5)
    if backend == 'firewalld':
        fwd_part(f, said)
    else:
        ipt_part(f, said)
    return said, {'backend': backend}


def fw_look():
    backend = fw_backend()
    out = {'backend': backend, 'at': time.time()}
    if backend == 'iptables':
        out['full'] = {'4': ipt_full(4), '6': ipt_full(6)}
        out['chain'] = FW_CHAIN
        out['files'] = {str(k): v for k, v in FW_FILES.items() if os.path.exists(v)}
    elif backend == 'firewalld':
        lines, ours = fwd_full()
        out['full'] = {'4': lines, '6': []}
        out['ours'] = ours
        out['zones'] = fwd_zones()
    return out


# ---- a backup of the whole installation -------------------------------------
# One .tar.gz with everything this machine needs to be this house again: the
# database (a consistent copy, made while the daemon runs), /etc/zigmon, the
# dashboard's nginx files and its password file, the certificate and its key,
# the broker's configuration with its passwords and ACL, the firewall's saved
# rules, the units. MANIFEST.json lists every file with its place, owner, mode
# and SHA-256, and MANIFEST.mac seals the list with a key that only root on
# this machine has (/var/lib/zigmon-root/backup.key) - so a backup this
# machine made can be put back whole from the dashboard, while one from
# anywhere else can only give its database, its configuration and its
# certificate back there: putting a unit, nginx's configuration or the
# broker's files back from an uploaded file would be root for anybody holding
# the PIN. Root on the command line may put anything back from anywhere.
PARTS = ('database', 'config', 'web', 'tls', 'broker', 'firewall', 'system', 'zigbee')
UNTRUSTED_OK = ('database', 'config', 'tls', 'zigbee')
PART_WORDS = {'database': 'the database: history, events, every setting made on the dashboard',
              'config': '/etc/zigmon/config.json - the broker, the PIN, the paths',
              'web': 'the dashboard\'s nginx files and its password file',
              'tls': 'the certificate, its chain and its private key',
              'broker': 'mosquitto: its configuration, passwords and ACL',
              'firewall': 'the firewall\'s saved rules',
              'system': 'the zigmon unit, its log rotation and its sudo line',
              'zigbee': 'the newest Zigbee2MQTT coordinator backup'}
MOST_FULL = 4 * 1024 ** 3


def backup_key():
    path = os.path.join(own_fd(), 'backup.key')
    try:
        with open(path) as f:
            k = f.read().strip()
        if re.fullmatch(r'[0-9a-f]{64}', k):
            return bytes.fromhex(k)
    except OSError:
        pass
    k = os.urandom(32)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, 'w') as f:
        f.write(k.hex() + '\n')
    return k


def config_values():
    try:
        with open(CONFIG_FILE) as f:
            got = json.load(f)
        return got if isinstance(got, dict) else {}
    except (OSError, ValueError):
        return {}


def db_file():
    p = str(config_values().get('db_file') or '').strip()
    return p if p.startswith('/') else os.path.join(STATE_DIR, 'history.db')


# What in config.json belongs to this machine rather than to the house - the
# daemon's own FILE_LOCAL. A backup from elsewhere does not bring them: a
# db_file of /etc/ld.so.preload, put back from an uploaded file, made the
# next database put back a file root wrote anywhere it was told.
CONFIG_LOCAL = ('db_file', 'log_file', 'token_file', 'log_to_journal', 'api_host', 'api_port',
                'state_dir')
SQLITE_HEAD = b'SQLite format 3\x00'


def config_kept_local(data):
    """An uploaded config.json with this machine's own paths and port kept
    as they are now."""
    got = json.loads(data.decode('utf-8') if isinstance(data, bytes) else data)
    if not isinstance(got, dict):
        raise Refused('the configuration in the backup is not a JSON object')
    now = config_values()
    for key in CONFIG_LOCAL:
        if key in now:
            got[key] = now[key]
        else:
            got.pop(key, None)
    return (json.dumps(got, indent=2) + '\n').encode('utf-8')


def db_file_ours(path):
    """The database is in the state folder, by its real path."""
    real = os.path.realpath(path)
    return os.path.dirname(real) == os.path.realpath(STATE_DIR)


def owner_names(st):
    try:
        u = pwd.getpwuid(st.st_uid).pw_name
    except KeyError:
        u = str(st.st_uid)
    try:
        g = grp.getgrgid(st.st_gid).gr_name
    except KeyError:
        g = str(st.st_gid)
    return u, g


def nginx_files_of(conf_text, block):
    out = []
    m = re.search(r'(?m)^\s*auth_basic_user_file\s+([^;\s]+);', conf_text)
    if m:
        out.append(m.group(1))
    return out


def gather():
    """{part: [absolute paths]} of what is on this machine to keep."""
    parts = {p: [] for p in PARTS}
    if os.path.isfile(CONFIG_FILE):
        parts['config'].append(CONFIG_FILE)
    conf = nginx_conf()
    text = ''
    if os.path.isfile(conf):
        parts['web'].append(conf)
        with open(conf) as f:
            text = f.read()
    for extra in ('/etc/nginx/conf.d/zigmon-tap.conf', '/etc/nginx/conf.d/zigmon-ntfy.conf'):
        if os.path.isfile(extra) and extra not in parts['web']:
            parts['web'].append(extra)
    where = server_block(text) if text else None
    if where:
        files = tls_files(text[where[0]:where[1]])
        for k in ('cert', 'key', 'root', 'dh'):
            if os.path.isfile(files[k]):
                parts['tls'].append(files[k])
        parts['web'] += [p for p in nginx_files_of(text, None) if os.path.isfile(p)]
    for conf_file in mosquitto_confs():
        parts['broker'].append(conf_file)
    for path in mosquitto_files():
        if os.path.isfile(path) and path not in parts['tls'] and path.startswith(FS_ROOT + '/etc/'):
            parts['broker'].append(path)
    for path in FW_FILES.values():
        if os.path.isfile(path):
            parts['firewall'].append(path)
    zones = '/etc/firewalld/zones'
    if os.path.isdir(zones):
        parts['firewall'] += sorted(os.path.join(zones, n) for n in os.listdir(zones)
                                    if n.endswith('.xml'))
    for path in ('/etc/systemd/system/zigmon.service', '/etc/logrotate.d/zigmon',
                 '/etc/sudoers.d/zigmon'):
        if os.path.isfile(path):
            parts['system'].append(path)
    try:
        bfd = sub_fd('backups')
        zips = sorted(n for n in os.listdir(bfd) if re.match(r'^zigbee2mqtt-[0-9-]+\.zip$', n))
        if zips:
            parts['zigbee'].append(os.path.join(STATE_DIR, 'backups', zips[-1]))
    except OSError:
        pass
    return parts


def hostname():
    return re.sub(r'[^A-Za-z0-9.-]', '', socket.gethostname())[:60] or 'zigmon'


def installed_version():
    for p in ('/usr/local/lib/zigmon/zigmon.py',):
        try:
            with open(p, encoding='utf-8') as f:
                for line in f:
                    m = re.match(r"^__version__ = '([0-9.]+)'", line)
                    if m:
                        return m.group(1)
        except OSError:
            pass
    return ''


def add_bytes(tar, name, data, mode=0o600):
    info = tarfile.TarInfo(name)
    info.size = len(data)
    info.mode = mode
    info.mtime = int(time.time())
    tar.addfile(info, io.BytesIO(data))


def full_make(why='by hand', db_name=None, keep=7, suffix=''):
    """A backup of the whole installation into FULL_DIR. `db_name` is a copy
    of the database the daemon made a moment ago in its backups folder;
    without one (the command line, the daemon stopped) the live file itself is
    copied with SQLite's own backup."""
    os.makedirs(FULL_DIR, mode=0o700, exist_ok=True)
    os.chmod(FULL_DIR, 0o700)
    stamp = time.strftime('%Y-%m-%d-%H%M%S')
    top = 'zigmon-full-%s-%s%s' % (hostname(), stamp, suffix)
    name = top + '.tar.gz'
    path = os.path.join(FULL_DIR, name)
    n = 1
    while os.path.exists(path):
        n += 1
        name = '%s-%d.tar.gz' % (top, n)
        path = os.path.join(FULL_DIR, name)
    parts = gather()
    manifest = {'kind': 'zigmon-full', 'format': 1, 'version': installed_version(),
                'host': hostname(), 'made_at': int(time.time()), 'why': str(why)[:80],
                'top': top, 'files': []}
    work = tempfile.mkdtemp(prefix='zigmon-full-')
    tmp_path = path + '.part'
    try:
        db_copy = os.path.join(work, 'history.db')
        if db_name:
            if not re.match(r'^zigmon-db-[0-9A-Za-z._-]+\.sqlite$', db_name):
                raise Refused('the database copy has no name of a copy')
            with open_plain(sub_fd('backups'), db_name) as src, open(db_copy, 'xb') as out:
                shutil.copyfileobj(src, out, 1 << 20)
        elif os.path.exists(db_file()):
            import sqlite3
            src = sqlite3.connect('file:%s?mode=ro' % db_file(), uri=True)
            dst = sqlite3.connect(db_copy)
            try:
                src.backup(dst)
            finally:
                dst.close()
                src.close()
        fd = os.open(tmp_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as raw, tarfile.open(fileobj=raw, mode='w:gz') as tar:
            def put(part, real, dest, st_from):
                st = os.stat(st_from)
                u, g = owner_names(st)
                h = hashlib.sha256()
                arc = '%s/%s/%s' % (top, part, dest.lstrip('/'))
                with open(real, 'rb') as fh:
                    info = tar.gettarinfo(fileobj=fh, arcname=arc)
                    info.mode, info.uid, info.gid, info.uname, info.gname = 0o600, 0, 0, 'root', 'root'
                    tar.addfile(info, fh)
                with open(real, 'rb') as fh:
                    for lump in iter(lambda: fh.read(1 << 20), b''):
                        h.update(lump)
                manifest['files'].append({'part': part, 'path': dest, 'archive': arc,
                                          'mode': '%o' % (st.st_mode & 0o7777), 'owner': u,
                                          'group': g, 'bytes': os.path.getsize(real),
                                          'sha256': h.hexdigest()})
            if os.path.exists(db_copy):
                live = db_file()
                put('database', db_copy, live, live if os.path.exists(live) else db_copy)
            for part in PARTS:
                if part == 'database':
                    continue
                for p in parts[part]:
                    if part == 'zigbee':
                        with open_plain(sub_fd('backups'), os.path.basename(p)) as src:
                            data = src.read()
                        z = os.path.join(work, os.path.basename(p))
                        with open(z, 'wb') as out:
                            out.write(data)
                        put(part, z, p, z)
                        continue
                    put(part, p, p, p)
            body = json.dumps(manifest, indent=1, sort_keys=True).encode('utf-8')
            add_bytes(tar, '%s/MANIFEST.json' % top, body)
            add_bytes(tar, '%s/MANIFEST.mac' % top,
                      hmac.new(backup_key(), body, hashlib.sha256).hexdigest().encode() + b'\n')
            add_bytes(tar, '%s/RESTORE.txt' % top, RESTORE_TXT.encode('utf-8'), 0o644)
        # on the disk before it takes its name (5.43.3): a power cut just
        # after the rename left an empty or cut-off file under a backup's
        # name, which the pruning then counted as one of the days kept
        sync_fd = os.open(tmp_path, os.O_RDONLY)
        try:
            os.fsync(sync_fd)
        finally:
            os.close(sync_fd)
        os.replace(tmp_path, path)
    except BaseException:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
    finally:
        shutil.rmtree(work, ignore_errors=True)
    if keep:
        full_prune(int(keep), spare=name)
    return {'file': name, 'bytes': os.path.getsize(path), 'parts': sorted({f['part'] for f in manifest['files']})}


RESTORE_TXT = """A backup of a whole zigmon installation.

Put it back, as root, on this machine or a freshly installed one
(./install.sh first, from the same version or newer):

    zigmon --full-restore THIS-FILE.tar.gz            everything in it
    zigmon --full-restore THIS-FILE.tar.gz --parts database,config,tls

MANIFEST.json says what each file is and where it goes, with its owner, mode
and SHA-256. The private key of the certificate and every password of the
house are in here: keep this file as carefully as those.
"""


def full_list():
    try:
        names = sorted((n for n in os.listdir(FULL_DIR) if FULL_FILE.match(n)), reverse=True)
    except OSError:
        return []
    out = []
    for n in names:
        try:
            st = os.stat(os.path.join(FULL_DIR, n))
        except OSError:
            continue
        out.append({'file': n, 'bytes': st.st_size, 'ts': int(st.st_mtime),
                    'why': 'uploaded' if '-uploaded' in n else
                    'before a restore' if '-before-restore' in n else ''})
    return out


def full_prune(keep, spare=None):
    """The newest `keep` made on the clock or by hand; of those made before a
    restore and those uploaded, the newest three each."""
    # newest first by when it was made (5.43.3), not by name: the name
    # begins with the host's, and once the machine was renamed the backups
    # of its old name sorted first - the newest `keep` were the old ones,
    # kept for good, and every new one but the last was deleted
    def made_at(x):
        m = re.search(r'-(\d{4}-\d{2}-\d{2}-\d{6})', x['file'])
        return (m.group(1) if m else '', x['ts'])
    names = [x['file'] for x in sorted(full_list(), key=made_at, reverse=True)]
    groups = {'made': [], 'before': [], 'uploaded': []}
    for n in names:
        groups['uploaded' if '-uploaded' in n else 'before' if '-before-restore' in n else 'made'].append(n)
    for kind, kept in (('made', keep), ('before', 3), ('uploaded', 3)):
        for n in groups[kind][kept:]:
            if n != spare:
                try:
                    os.unlink(os.path.join(FULL_DIR, n))
                except OSError:
                    pass


def full_path(name):
    name = os.path.basename(str(name or ''))
    if not FULL_FILE.match(name):
        raise Refused('that is not the name of a backup of the whole installation')
    path = os.path.join(FULL_DIR, name)
    if not os.path.isfile(path):
        raise Refused('there is no backup called %s' % name)
    return path


def decrypt(src, dst, passphrase):
    env = dict(os.environ, ZIGMON_PASS=passphrase)
    got = subprocess.run(['openssl', 'enc', '-d', '-aes-256-cbc', '-pbkdf2', '-iter', '600000',
                          '-in', src, '-out', dst, '-pass', 'env:ZIGMON_PASS'],
                         capture_output=True, text=True, env=env)
    if got.returncode != 0:
        raise Refused('it does not open with that password')


# ---- the certificate handed over with its key (5.30) ------------------------
EXPORT_FORMATS = ('pem_key', 'key', 'pfx', 'pfx_legacy')
EXPORT_FILE = re.compile(r'^zigmon-cert-[A-Za-z0-9._-]{1,100}\.(pem|key|pfx)$')


def chain_walk(certs, pool):
    """The certificates of `pool` above the last of `certs`, in order up to
    its root (5.42): with two certificates side by side the chain nginx
    trusts holds both chains, and only the chosen one's goes with it."""
    def names(c):
        out = run(['openssl', 'x509', '-noout', '-subject', '-issuer', '-nameopt', 'RFC2253'],
                  'a certificate', data=c + '\n')
        s = re.search(r'(?m)^subject=\s*(.*)$', out)
        i = re.search(r'(?m)^issuer=\s*(.*)$', out)
        return (s.group(1).strip() if s else ''), (i.group(1).strip() if i else '')
    info = {}
    for c in pool:
        try:
            info[c] = names(c)
        except Refused:
            continue
    out = list(certs)
    subj, at = names(out[-1])
    for _ in range(8):
        if subj == at:
            break
        nxt = next((c for c in info if info[c][0] == at and c not in out), None)
        if not nxt:
            break
        out.append(nxt)
        subj, at = info[nxt]
    return out


def tls_export(raw, given=None, dual=False):
    """The certificate nginx serves, with its private key, in one file for a
    download: PEM (the certificate, its chain and the key - the key locked
    with the password when one is given), the key alone, or PFX / PKCS#12
    (with the chain; the legacy kind for older Windows and Java). Only the
    files nginx's own server block names are read, the password goes to
    openssl through its environment and is kept nowhere, and the file is
    handed over once, readable by the service, and taken away when fetched."""
    fmt = str(raw.get('format') or '')
    if fmt not in EXPORT_FORMATS:
        raise Refused('the format is one of %s' % ', '.join(EXPORT_FORMATS))
    pw = str(raw.get('password') or '')
    if len(pw) > 200 or re.search(r'[\r\n\x00]', pw):
        raise Refused('the password is one line of at most 200 characters')
    if fmt.startswith('pfx') and len(pw) < 4:
        # Windows and most of what imports a PFX refuse one with no password
        raise Refused('a PFX needs a password (four characters or more)')
    if fmt in ('pem_key', 'key') and pw and len(pw) < 4:
        raise Refused('a password for the key is four characters or more')
    with_root = bool(raw.get('with_root'))
    # which of two side by side (5.42): the first (RSA), or the second (EC) -
    # each with its own key and chain only, never both keys in one file
    pair = str(raw.get('pair') or 'main')
    if pair not in ('main', 'alt'):
        raise Refused('the certificate is the first (main) or the second (alt)')
    now = {}
    if given:
        cert_text, key_text, root_text = given
    else:
        now = tls_now()
        if not now.get('server'):
            raise Refused('nginx has no HTTPS server block to read the certificate from')
        files = now['files']
        dual = bool(now.get('dual'))
        if pair == 'alt' and not dual:
            raise Refused('nginx serves no second certificate to hand over')
        try:
            with open(files['alt_cert' if pair == 'alt' else 'cert']) as f:
                cert_text = f.read(500000)
            with open(files['alt_key' if pair == 'alt' else 'key']) as f:
                key_text = f.read(100000)
        except OSError as e:
            raise Refused('the certificate or its key cannot be read: %s' % e)
        root_text = ''
        if with_root and os.path.exists(files['root']):
            try:
                with open(files['root']) as f:
                    root_text = f.read(200000)
            except OSError:
                pass
    certs = re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', cert_text, re.S)
    if not certs:
        raise Refused('there is no certificate to hand over')
    if with_root and dual:
        # (5.42) the chain nginx trusts holds both certificates' chains: only
        # what lies above this one goes with it
        certs = chain_walk(certs, re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',
                                             root_text or '', re.S))
    elif with_root:
        for c in re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', root_text or '', re.S):
            if c not in certs:
                certs.append(c)
    leaf, chain = certs[0], certs[1:]
    # the key nginx has must be the certificate's - never hand over a pair
    # that does not belong together
    want = run(['openssl', 'pkey', '-pubout'], 'the key', data=key_text).strip()
    have = run(['openssl', 'x509', '-noout', '-pubkey'], 'the certificate', data=leaf).strip()
    if want != have:
        raise Refused('the key nginx has does not belong to its certificate')
    cn = ''
    subj = run(['openssl', 'x509', '-noout', '-subject', '-nameopt', 'RFC2253'], 'the certificate', data=leaf)
    m = re.search(r'CN=([^,/\n]+)', subj)
    if m:
        cn = m.group(1).strip()
    base = re.sub(r'[^A-Za-z0-9._-]+', '-', (cn or now.get('server_name') or 'server').replace('*', 'star'))[:80].strip('-.') or 'server'
    if pair == 'alt':
        base = base[:73] + '-ecdsa'
    ext = {'pem_key': 'pem', 'key': 'key', 'pfx': 'pfx', 'pfx_legacy': 'pfx'}[fmt]
    name = 'zigmon-cert-%s.%s' % (base, ext)
    out_fd = child_fd(root_fd(), 'out', make=True)
    for n in os.listdir(out_fd):                       # one certificate handed over at a time
        if EXPORT_FILE.match(n):
            try:
                os.unlink(n, dir_fd=out_fd)
            except OSError:
                pass
    env = dict(os.environ, ZIGMON_PASS=pw)
    with tempfile.TemporaryDirectory(prefix='zigmon-cert-') as t:
        os.chmod(t, 0o700)
        kf, cf, chf, made = (os.path.join(t, x) for x in ('key.pem', 'cert.pem', 'chain.pem', 'out'))
        for path, text in ((kf, key_text), (cf, leaf + '\n'), (chf, '\n'.join(chain) + '\n')):
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as fh:
                fh.write(text)
        if fmt in ('pem_key', 'key'):
            if pw:
                key_out = run(['openssl', 'pkey', '-in', kf, '-aes256', '-passout', 'env:ZIGMON_PASS'],
                              'locking the key', env=env)
            else:
                key_out = run(['openssl', 'pkey', '-in', kf], 'the key')
            body = key_out if fmt == 'key' else (leaf + '\n' + ''.join(c + '\n' for c in chain) + key_out)
            with open(made, 'w') as fh:
                fh.write(body)
        else:
            cmd = ['openssl', 'pkcs12', '-export', '-inkey', kf, '-in', cf, '-out', made,
                   '-passout', 'env:ZIGMON_PASS', '-name', cn or base]
            if chain:
                cmd += ['-certfile', chf]
            if fmt == 'pfx_legacy':
                # what Windows before 2019, older Java and many appliances read
                cmd += ['-keypbe', 'PBE-SHA1-3DES', '-certpbe', 'PBE-SHA1-3DES', '-macalg', 'sha1']
            run(cmd, 'making the PFX', env=env)
        fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640, dir_fd=out_fd)
        with os.fdopen(fd, 'wb') as out, open(made, 'rb') as fh:
            shutil.copyfileobj(fh, out)
            os.fchown(out.fileno(), 0, service_gid())
    words = {'pem_key': 'PEM with its key', 'key': 'the key alone', 'pfx': 'PFX',
             'pfx_legacy': 'PFX (legacy)'}[fmt]
    return {'out': name, 'out_bytes': os.stat(name, dir_fd=out_fd).st_size}, \
        ['the %scertificate%s handed over for a download: %s, %s%s' % (
            'second (EC) ' if pair == 'alt' else '', ' and its key' if fmt != 'key' else '\'s key', name, words,
            ' (locked with a password)' if pw else '')]


# ---- the certificate on the server in front (5.33) -------------------------
# The same certificate and the same TLS settings as here, on the nginx of the
# server in front, over SSH: its configuration read with nginx -T, every
# server { } that serves the certificate of the dashboard's name changed with
# the same functions as here, written back with a copy of each file beside it,
# nginx -t, a reload - or every file put back as it was.
PROXY_HOST_RE = re.compile(r'^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?$|^[0-9A-Fa-f:.]{2,45}$')
PROXY_USER_RE = re.compile(r'^[a-z_][a-z0-9_.-]{0,31}$')
PROXY_PATH_RE = re.compile(r'^/[A-Za-z0-9_./-]{2,200}$')
SSH_KEY_RE = re.compile(r'^\s*-----BEGIN [A-Z ]*PRIVATE KEY-----[\sA-Za-z0-9+/=:,.-]+-----END [A-Z ]*PRIVATE KEY-----\s*$')
SSH_BIN = os.environ.get('ZIGMON_SSH_BIN') or 'ssh'
PROXY_SSH_TIMEOUT = 120

PROXY_PUT_SCRIPT = r"""set -u
umask 077
d=$(mktemp -d /tmp/zigmon-tls.XXXXXX) || exit 20
trap 'rm -rf "$d"' EXIT
tar -xf - -C "$d" || exit 21
# a copy left by a run that was cut short is not what was there before this one
while read -r src mode dst; do rm -f "$dst.zigmon-before"; done < "$d/list"
back() {
  while read -r src mode dst; do
    if [ -e "$dst.zigmon-before" ]; then cat "$dst.zigmon-before" > "$dst"; rm -f "$dst.zigmon-before"
    elif [ -e "$d/new.$src" ]; then rm -f "$dst"; fi
  done < "$d/list"
}
while read -r src mode dst; do
  if [ -e "$dst" ]; then
    cp -p "$dst" "$dst.zigmon-before" && cat "$d/$src" > "$dst" || { back; echo ZIGMON-NOT-WRITTEN; exit 22; }
  else
    : > "$d/new.$src"
    install -D -m "$mode" "$d/$src" "$dst" || { back; echo ZIGMON-NOT-WRITTEN; exit 22; }
    command -v restorecon >/dev/null 2>&1 && restorecon "$dst"
  fi
done < "$d/list"
if ! nginx -t >"$d/t" 2>&1; then
  back; tail -n 3 "$d/t"; echo ZIGMON-REFUSED; exit 23
fi
if command -v systemctl >/dev/null 2>&1; then systemctl reload nginx || nginx -s reload; else nginx -s reload; fi
while read -r src mode dst; do rm -f "$dst.zigmon-before"; done < "$d/list"
%(fp)s
echo ZIGMON-DONE
"""


def proxy_ssh_checked(raw):
    s = raw.get('ssh') if isinstance(raw.get('ssh'), dict) else {}
    host = str(s.get('host') or '').strip()
    user = str(s.get('user') or 'root').strip()
    try:
        port = int(s.get('port') or 22)
    except (TypeError, ValueError):
        port = 0
    if not PROXY_HOST_RE.match(host) or not PROXY_USER_RE.match(user) or not 0 < port < 65536:
        raise Refused('the server in front is named by an address, a user and a port')
    key = str(s.get('key') or '')
    if not key:
        raise Refused('the server in front is reached with a password here: its certificate is '
                      'looked after with the key way (Front server & router - a key)')
    if len(key) > 20000 or not SSH_KEY_RE.match(key):
        raise Refused('the SSH key does not read')
    return {'host': host, 'user': user, 'port': port, 'key': key,
            'known_hosts': str(s.get('known_hosts') or '')[:200000]}


def proxy_ssh(ssh, command, data=b''):
    """One command on the server in front: (exit code, standard output, its error)."""
    with tempfile.TemporaryDirectory(prefix='zigmon-proxy-') as t:
        os.chmod(t, 0o700)
        for name, text in (('id', ssh['key'] if ssh['key'].endswith('\n') else ssh['key'] + '\n'),
                           ('known_hosts', ssh['known_hosts'])):
            fd = os.open(os.path.join(t, name), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w') as fh:
                fh.write(text)
        argv = [SSH_BIN, '-p', str(ssh['port']), '-i', os.path.join(t, 'id'),
                '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
                '-o', 'StrictHostKeyChecking=accept-new',
                '-o', 'UserKnownHostsFile=%s' % os.path.join(t, 'known_hosts'),
                '-o', 'LogLevel=ERROR', '%s@%s' % (ssh['user'], ssh['host']), command]
        try:
            got = subprocess.run(argv, input=data, capture_output=True, timeout=PROXY_SSH_TIMEOUT)
        except subprocess.TimeoutExpired:
            raise Refused('%s did not answer within %d s' % (ssh['host'], PROXY_SSH_TIMEOUT))
    return got.returncode, got.stdout.decode('utf-8', 'replace'), got.stderr.decode('utf-8', 'replace')


def nginx_t_files(text):
    """nginx -T's dump: {file: its text}, in the order nginx read them."""
    files, cur, lines = {}, None, []
    for line in text.split('\n'):
        m = re.match(r'^# configuration file (/\S+):\s*$', line)
        if m:
            if cur:
                files[cur] = '\n'.join(lines)
            cur, lines = m.group(1), []
            continue
        if cur:
            lines.append(line)
    if cur:
        files[cur] = '\n'.join(lines)
    return files


def server_blocks(text):
    """Every server { } of a file: [(start, end)]."""
    out, i = [], 0
    while True:
        m = re.search(r'(?m)^[ \t]*server[ \t]*\{', text[i:])
        if not m:
            return out
        start = i + m.start()
        end = block_end(text, i + m.end() - 1)
        if end is None:
            return out
        out.append((start, end))
        i = end


def proxy_find(files, name):
    """The certificate the server for `name` serves, and every HTTPS server
    { } that serves the same one: (cert path, [(file, start, end)])."""
    cert = None
    for path, text in files.items():
        for start, end in server_blocks(text):
            block = text[start:end]
            names = (directive(block, 'server_name') or '').split()
            c = directive(block, 'ssl_certificate')
            if c and name in names:
                cert = c
                break
        if cert:
            break
    if not cert:
        raise Refused('nginx on the server in front has no HTTPS server for %s' % name)
    where = []
    for path, text in files.items():
        for start, end in server_blocks(text):
            if directive(text[start:end], 'ssl_certificate') == cert:
                where.append((path, start, end))
    return cert, where


def proxy_files_of(block, cert):
    base = os.path.dirname(cert) or '/etc/nginx/certs'
    out = {'cert': cert,
           'key': directive(block, 'ssl_certificate_key') or os.path.join(base, 'server.key'),
           'root': directive(block, 'ssl_trusted_certificate') or os.path.join(base, 'server.ca'),
           'dh': directive(block, 'ssl_dhparam') or os.path.join(base, 'zigmon-dh.pem')}
    for k, v in out.items():
        if not PROXY_PATH_RE.match(v) or '..' in v.split('/'):
            raise Refused('nginx on the server in front names a file that is not a plain path: %s' % v[:120])
    return out


def proxy_dh(choice, had):
    """The DH parameters for the server in front, made here (a group of RFC
    7919 at once, or made bits - minutes); the same as last time is not made
    again, it is already there."""
    if choice == 'none' or choice == had:
        return None
    if choice.startswith('ffdhe'):
        return openssl(['genpkey', '-genparam', '-algorithm', 'DH', '-pkeyopt', 'group:%s' % choice],
                       'the DH group %s' % choice)
    progress('making DH parameters of %s bits for the server in front' % choice[3:], 2,
             DH_EXPECT_S.get(choice))
    return openssl(['dhparam', choice[3:]], 'making DH parameters of %s bits' % choice[3:])


def proxy_ntfy_paths(files, where, cert_path, paths, front_name):
    """ntfy's server block(s) on the server in front (5.41): its files, never
    one of the front's. A certificate or key file the front's blocks name as
    well is refused (one file for both is looked after on the front's card);
    a trusted chain or DH file of its blocks that is none, or the front's
    (its defaults server.ca and zigmon-dh.pem are the front's), is one of
    ntfy's own beside its certificate. Its blocks only: never one that
    answers for the front's name as well."""
    front = set()
    front_cert = None
    try:
        front_cert, fwhere = proxy_find(files, front_name)
    except Refused:
        fwhere = []
    for path, start, end in fwhere:
        fp = proxy_files_of(files[path][start:end], front_cert)
        front |= set(fp.values()) | set(alt_paths(fp['cert'], fp['key']))
    if front_cert == cert_path or paths['cert'] in front or paths['key'] in front:
        raise Refused('ntfy is served the same certificate files as the front there (%s): it is '
                      'looked after with the card of the server in front' % cert_path[:120])
    stem = os.path.splitext(paths['cert'])[0]
    blocks = [files[p][s:e] for p, s, e in where]
    if paths['root'] in front or not any(directive(b, 'ssl_trusted_certificate') for b in blocks):
        paths['root'] = stem + '.ca'
    if paths['dh'] in front or not any(directive(b, 'ssl_dhparam') for b in blocks):
        paths['dh'] = stem + '-dh.pem'
    for v in (paths['root'], paths['dh']):
        if v in front or not PROXY_PATH_RE.match(v) or '..' in v.split('/'):
            raise Refused('a file for ntfy there would be one of the front\'s: %s' % v[:120])
    return [w for w in where if front_name not in
            (directive(files[w[0]][w[1]:w[2]], 'server_name') or '').split()]


def tls_proxy(raw, which='front'):
    """The certificate and how TLS is spoken, on the server in front (5.33).
    which='ntfy' (5.41): the second certificate there, ntfy's - in its own
    server block(s) and its own files only; the front's are never touched,
    and the certificate of this machine never goes there."""
    ssh = proxy_ssh_checked(raw)
    name = str(raw.get('name') or '').strip().lower()
    if not re.match(r'^[A-Za-z0-9*]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$', name):
        raise Refused('the name of the server is a host name')
    front_name = str(raw.get('front_name') or '').strip().lower() or (name if which == 'front' else '')
    if not re.match(r'^[A-Za-z0-9*]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?$', front_name) or \
            which == 'ntfy' and front_name == name:
        raise Refused('ntfy\'s server there is told apart from the front\'s by both names')
    op = str(raw.get('op') or 'apply')
    if which == 'ntfy' and str(raw.get('source') or '') == 'here':
        raise Refused('ntfy there never takes the certificate of this machine: it has its own')
    PROGRESS.update(step=0, total=4)
    progress('reading nginx on %s' % ssh['host'], 1)
    code, out, err = proxy_ssh(ssh, 'nginx -T 2>/dev/null')
    files = nginx_t_files(out)
    if code != 0 or not files:
        why = (err or out).strip().splitlines()
        raise Refused('%s: nginx -T did not answer (%s)' % (ssh['host'], why[-1][:160] if why else code))
    if op == 'acme_http':
        return proxy_acme_http(raw, ssh, files, name, front_name, which)
    cert_path, where = proxy_find(files, name)
    first = files[where[0][0]][where[0][1]:where[0][2]]
    paths = proxy_files_of(first, cert_path)
    if which == 'ntfy':
        where = proxy_ntfy_paths(files, where, cert_path, paths, front_name)
        if not where:
            raise Refused('nginx on the server in front has no HTTPS server of its own for %s' % name)
    if op == 'export':
        return proxy_export(raw, ssh, paths, files[where[0][0]][where[0][1]:where[0][2]])
    if op == 'chain':
        return proxy_chain(raw, ssh, files, where, paths, which)
    t = raw.get('tls')
    pol = None
    if isinstance(t, dict) and t.get('protocols'):
        pol = tls_checked({k: t.get(k) for k in ('protocols', 'ciphers', 'prefer', 'dh', 'hsts')})
    pem = None
    source = str(raw.get('source') or '')
    alt = None
    if source == 'here':
        cert_text, key_text = proxy_pem_here()
        here_now = tls_now()
        here_files = here_now.get('files') or {}
        if here_now.get('dual'):
            try:
                with open(here_files['alt_cert']) as f:
                    at = f.read(500000)
                with open(here_files['alt_key']) as f:
                    ak = f.read(100000)
                ac = re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', at, re.S)
                alt = pem_set(ac[0], ak, '\n'.join(ac[1:])) if ac else None
            except OSError:
                alt = None
        certs = re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', cert_text, re.S)
        if not certs:
            raise Refused('there is no certificate here to put there')
        root_text = ''
        here = tls_now().get('files') or {}
        if here.get('root') and os.path.exists(here['root']):
            try:
                with open(here['root']) as f:
                    root_text = ''.join(c + '\n' for c in re.findall(
                        r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', f.read(200000), re.S)
                        if c not in certs)
            except OSError:
                root_text = ''
        pem = pem_set(certs[0], key_text, '\n'.join(certs[1:]), root_text)
    elif source == 'given':
        pem = pem_set(raw.get('cert'), raw.get('key'), raw.get('chain'), raw.get('root'))
        # an EC one beside it (5.42): uploaded with it, as both are put in here
        a = raw.get('alt') if isinstance(raw.get('alt'), dict) else None
        if a and pem:
            alt = pem_set(a.get('cert'), a.get('key'), a.get('chain'), a.get('root'))
            if alt:
                alt['own_trust'] = True
    if not pem and not pol:
        raise Refused('nothing to put on the server in front')
    progress('making the files for %s' % ssh['host'], 2)
    put = []                                    # (data, mode, path)
    alt_paths_there = alt_paths(paths['cert'], paths['key'])
    if pem:
        put.append((pem['cert'] + pem['chain'], '644', paths['cert']))
        put.append((pem['key'], '600', paths['key']))
        if alt:
            put.append((alt['cert'] + alt['chain'], '644', alt_paths_there[0]))
            put.append((alt['key'], '600', alt_paths_there[1]))
        trust = trust_of(pem, alt)
        # ntfy's (5.41): where one of its blocks staples or names one - or
        # (5.41.1) a root was given with it: then it is kept there and named,
        # as on the front, not dropped (the card said "Root: not given" for a
        # root uploaded with ntfy's certificate)
        if trust and (which != 'ntfy' or pem['root'] or any(
                (directive(files[p][s:e], 'ssl_stapling') or '') == 'on' or
                directive(files[p][s:e], 'ssl_trusted_certificate') for p, s, e in where)):
            put.append((trust, '644', paths['root']))
    dh_had = str(raw.get('dh_had') or '')
    if pol and dh_had and not all(directive(files[p][s:e], 'ssl_dhparam') == paths['dh'] for p, s, e in where):
        # made last time for blocks that named it (5.43.3): one that does not
        # yet - another name chosen on the card, the certificate moved to
        # another folder - had ssl_dhparam set to a file never put there, and
        # nginx -t refused every putting-in until the DH choice was changed
        dh_had = ''
    dh_pem = proxy_dh(pol['dh'], dh_had) if pol else None
    if dh_pem:
        put.append((dh_pem, '644', paths['dh']))
    said = []
    if pol or pem:
        changed = {}
        for path, start, end in sorted(where, key=lambda w: (w[0], -w[1])):
            text = changed.get(path, files[path])
            block = text[start:end]
            if pem:
                if alt:
                    block = set_directives(block, 'ssl_certificate', [paths['cert'], alt_paths_there[0]])
                    block = set_directives(block, 'ssl_certificate_key', [paths['key'], alt_paths_there[1]])
                elif len(directives(block, 'ssl_certificate')) > 1:
                    block = set_directive(block, 'ssl_certificate', paths['cert'])
                    block = set_directive(block, 'ssl_certificate_key', paths['key'])
                trust = trust_of(pem, alt)
                # only where there is a chain to trust, and the block staples
                # or names one already (5.37.1: a self-signed one, with no
                # chain, rewrote a block's own trusted file to a path that
                # may not be there)
                if trust and (pem['root'] or (directive(block, 'ssl_stapling') or '') == 'on' or
                              directive(block, 'ssl_trusted_certificate')):
                    block = set_directive(block, 'ssl_trusted_certificate', paths['root'])
            if pol:
                block = set_directive(block, 'ssl_protocols', ' '.join(pol['protocols']))
                block = set_directive(block, 'ssl_ciphers', pol['ciphers'] or CIPHERS_DEFAULT)
                block = set_directive(block, 'ssl_prefer_server_ciphers', 'on' if pol['prefer'] else 'off')
                block = set_directive(block, 'ssl_dhparam', paths['dh'] if pol['dh'] != 'none' else None)
                if pol['hsts']:
                    block = set_directive(block, 'add_header Strict-Transport-Security',
                                          '"max-age=%d" always' % pol['hsts'])
                else:
                    block = set_directive(block, 'add_header Strict-Transport-Security', None)
            changed[path] = text[:start] + block + text[end:]
        for path, text in changed.items():
            if text != files[path]:
                if not PROXY_PATH_RE.match(path) or '..' in path.split('/'):
                    raise Refused('nginx on the server in front reads a file that is not a plain path')
                put.append((text if text.endswith('\n') else text + '\n', '644', path))
        if pol:
            said.append('%s; %s; DH %s%s' % (' '.join(pol['protocols']),
                                             'ciphers as set' if pol['ciphers'] else 'the usual ciphers',
                                             pol['dh'], '; HSTS %d s' % pol['hsts'] if pol['hsts'] else ''))
    fp = ''
    if pem:
        fp = run(['openssl', 'x509', '-noout', '-fingerprint', '-sha256'], 'the certificate', data=pem['cert'])
        fp = fp.strip().split('=', 1)[-1].replace(':', '').lower()
        subj = openssl(['x509', '-noout', '-subject', '-enddate'], 'the certificate',
                       pem['cert']).strip().replace('\n', ', ')
        said.insert(0, 'certificate: %s' % subj)
    # one file once (5.37.1): the same path twice - a trusted certificate that
    # is the certificate file itself - wrote its copy from before over with
    # the new content, and a rollback put back the new one
    # - the first is kept: the certificate with its chain serves as the
    # chain to trust as well
    seen, once = set(), []
    for item in put:
        if item[2] not in seen:
            seen.add(item[2])
            once.append(item)
    put = once
    progress('putting it on %s' % ssh['host'], 3)
    out = proxy_put(ssh, put, paths['cert'] if pem else None)
    there = re.search(r'Fingerprint=([0-9A-Fa-f:]+)', out)
    there = there.group(1).replace(':', '').lower() if there else ''
    if fp and there and there != fp:
        raise Refused('%s serves a different certificate from the file it was given' % ssh['host'])
    fields = {'proxy': {'host': ssh['host'], 'at': int(time.time()), 'source': source or None,
                        'fingerprint': fp or None, 'files': len(put)}}
    if which == 'ntfy':
        fields['proxy']['which'] = 'ntfy'
    if pol:
        fields['proxy']['dh'] = pol['dh']
    return fields, ['on the server in front (%s), %s%d server block(s): %s; nginx reloaded'
                    % (ssh['host'], 'ntfy\'s ' if which == 'ntfy' else '', len(where),
                       '; '.join(said) or 'as it was')]


def proxy_cat(ssh, path):
    """The certificates of a file there, in order."""
    if not PROXY_PATH_RE.match(path or '') or '..' in path.split('/'):
        return []
    code, out, _err = proxy_ssh(ssh, 'cat %s' % shlex.quote(path))
    return PEM_CERT_RE.findall(out) if code == 0 else []


def proxy_chain(raw, ssh, files, where, paths, which):
    """(op chain) The chain of the certificate in place there - and the
    company root kept to check with - the certificate and its key as they
    are, as tls_chain() does it here: the same checks, the same files, nginx
    -t and a reload there, every file put back when nginx says no."""
    first = files[where[0][0]][where[0][1]:where[0][2]]
    certs = directives(first, 'ssl_certificate')
    leaf = (proxy_cat(ssh, paths['cert']) or [''])[0]
    chain = chain_checked(leaf, raw.get('fp'), raw.get('chain'), 'the certificate there')
    alt = raw.get('alt') if isinstance(raw.get('alt'), dict) else None
    alt_leaf, alt_chain, alt_path = '', [], ''
    if alt and len(certs) > 1:
        alt_path = certs[1]
        alt_leaf = (proxy_cat(ssh, alt_path) or [''])[0]
        alt_chain = chain_checked(alt_leaf, alt.get('fp'), alt.get('chain'), 'the second certificate there')
    roots, trust = chain_roots(raw, chain, alt_chain)
    progress('making the files for %s' % ssh['host'], 2)
    put = [(leaf.strip() + '\n' + ''.join(c + '\n' for c in chain), '644', paths['cert'])]
    if alt_leaf:
        put.append((alt_leaf.strip() + '\n' + ''.join(c + '\n' for c in alt_chain), '644', alt_path))
    if trust and paths['root'] not in (paths['cert'], alt_path):
        put.append((trust, '644', paths['root']))
        changed = {}
        for path, start, end in sorted(where, key=lambda w: (w[0], -w[1])):
            text = changed.get(path, files[path])
            block = text[start:end]
            if roots or (directive(block, 'ssl_stapling') or '') == 'on' or \
                    directive(block, 'ssl_trusted_certificate'):
                block = set_directive(block, 'ssl_trusted_certificate', paths['root'])
            changed[path] = text[:start] + block + text[end:]
        for path, text in changed.items():
            if text != files[path]:
                if not PROXY_PATH_RE.match(path) or '..' in path.split('/'):
                    raise Refused('nginx on the server in front reads a file that is not a plain path')
                put.append((text if text.endswith('\n') else text + '\n', '644', path))
    progress('putting it on %s' % ssh['host'], 3)
    out = proxy_put(ssh, put, paths['cert'])
    there = re.search(r'Fingerprint=([0-9A-Fa-f:]+)', out)
    there = there.group(1).replace(':', '').lower() if there else ''
    fp = re.sub(r'[^0-9a-f]', '', str(raw.get('fp') or '').lower())
    if there and there != fp:
        raise Refused('%s serves a different certificate from the file it was given' % ssh['host'])
    fields = {'proxy': {'host': ssh['host'], 'at': int(time.time()), 'source': 'chain', 'fingerprint': fp,
                        'files': len(put)}}
    if which == 'ntfy':
        fields['proxy']['which'] = 'ntfy'
    words = 'the chain: %s' % (', '.join(dn_cn(cert_names(c)[0]) for c in chain) or 'none')
    if roots:
        words += '; the root kept to check with (never sent): %s' % ', '.join(dn_cn(cert_names(c)[0]) for c in roots)
    return fields, ['on the server in front (%s), %s%s; nginx reloaded' % (
        ssh['host'], 'ntfy\'s certificate, ' if which == 'ntfy' else '', words)]


def proxy_put(ssh, put, fp_of=None):
    """[(data, mode, path)] written on the server in front, a copy of each
    file beside it, nginx -t, a reload - or every file put back as it was.
    What it said."""
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w') as tar:
        listing = []
        for n, (data, mode, path) in enumerate(put):
            raw_data = data.encode()
            info = tarfile.TarInfo('f%d' % n)
            info.size, info.mode = len(raw_data), 0o600
            tar.addfile(info, io.BytesIO(raw_data))
            listing.append('f%d %s %s' % (n, mode, path))
        lst = ('\n'.join(listing) + '\n').encode()
        info = tarfile.TarInfo('list')
        info.size, info.mode = len(lst), 0o600
        tar.addfile(info, io.BytesIO(lst))
    script = PROXY_PUT_SCRIPT % {'fp': ('command -v openssl >/dev/null 2>&1 && openssl x509 -noout '
                                        '-fingerprint -sha256 -in %s' % shlex.quote(fp_of)) if fp_of else ''}
    code, out, err = proxy_ssh(ssh, 'sh -c %s' % shlex.quote(script), buf.getvalue())
    if 'ZIGMON-REFUSED' in out:
        last = out.split('ZIGMON-REFUSED')[0].strip().splitlines()[-1:] or ['']
        raise Refused('nginx on %s would not take it (%s) - its files are as they were'
                      % (ssh['host'], last[0][:200]))
    if 'ZIGMON-DONE' not in out:
        why = (err or out).strip().splitlines()
        raise Refused('%s: %s' % (ssh['host'], why[-1][:200] if why else 'ssh ended with %d' % code))
    return out


# Automatic certificates of a name on the server in front (5.41): the CA's
# HTTP-01 question comes to port 80 THERE. The plain-HTTP server { } of the
# name gets, between zigmon's marks, a location for /.well-known/acme-
# challenge/ handed on to this machine (where the front's block sends the
# rest - its proxy_pass), whose port 80 gives the daemon's answer; the
# server's own `return` set aside into a `location /` as here. For one order
# only: taken out again once it is done, the block as it was.
PROXY_ACME_UP_RE = re.compile(r'(?m)^\s*proxy_pass\s+https?://([A-Za-z0-9.-]+|\[[0-9A-Fa-f:]+\])(?::\d+)?[/;\s]')


def proxy_acme_block(block, house, host_name, name, on):
    if acme_marked(block):
        block = re.sub(r'\n*^[ \t]*%s[^\n]*\n.*?\n[ \t]*%s[^\n]*' % (re.escape(ACME_BEGIN),
                                                                      re.escape(ACME_END)),
                       '', block, count=1, flags=re.S | re.M)
        block = re.sub(r'(?m)^([ \t]*)%s(return\s[^\n]*)$' % re.escape(ACME_ASIDE), r'\1\2', block)
    if not on:
        return block
    lines = block.split('\n')
    depth, aside = 0, []
    for n, line in enumerate(lines):
        if depth == 1 and re.match(r'^\s*return\s', line):
            aside.append(line)
            lines[n] = re.sub(r'^(\s*)', lambda m: m.group(1) + ACME_ASIDE, line, count=1)
        depth += line.count('{') - line.count('}')
    block = '\n'.join(lines)
    pad = '    '
    add = [pad + ACME_BEGIN + ' (Automatic certificates of %s, set on the dashboard)' % name,
           pad + 'location ^~ %s {' % ACME_LOC,
           pad + '    # the ACME CA\'s HTTP-01 question, answered by zigmon at home',
           pad + '    client_max_body_size 1k;',
           pad + '    proxy_pass http://%s;' % house,
           pad + '    proxy_set_header Host %s;' % host_name,
           pad + '    proxy_read_timeout 15s;',
           pad + '}']
    if aside:
        add += [pad + 'location / {'] + [pad + '    ' + a.strip() for a in aside] + [pad + '}']
    add.append(pad + ACME_END)
    close = block.rfind('}')
    return block[:close].rstrip('\n') + '\n\n' + '\n'.join(add) + '\n' + block[close:]


def proxy_acme_http(raw, ssh, files, name, front_name, which):
    """Port 80 of the server in front answering the CA for `name`, or not."""
    on = raw.get('on') is True
    house = None
    try:
        _cert, fwhere = proxy_find(files, front_name)
    except Refused:
        fwhere = []
    for path, start, end in fwhere:
        m = PROXY_ACME_UP_RE.search(files[path][start:end])
        if m:
            house = m.group(1)
            break
    changed = {}
    for path, text in files.items():
        for start, end in sorted(server_blocks(text), key=lambda w: -w[0]):
            block = text[start:end]
            if re.search(r'(?m)^\s*listen\s+[^;]*ssl', block) or \
                    name not in (directive(block, 'server_name') or '').split():
                continue
            if on and not house:
                raise Refused('the server for %s there does not say where this machine is (a '
                              'proxy_pass): the CA\'s HTTP-01 question cannot be handed here - '
                              'choose DNS-01' % front_name)
            cur = changed.get(path, text)
            changed[path] = cur[:start] + proxy_acme_block(block, house, front_name, name, on) + cur[end:]
    if on and not changed:
        raise Refused('nginx on the server in front has no plain-HTTP server for %s on port 80: the '
                      'CA\'s HTTP-01 question cannot be answered there (DNS-01 needs none)' % name)
    put = []
    for path, text in changed.items():
        if text != files[path]:
            if not PROXY_PATH_RE.match(path) or '..' in path.split('/'):
                raise Refused('nginx on the server in front reads a file that is not a plain path')
            put.append((text if text.endswith('\n') else text + '\n', '644', path))
    if put:
        progress('port 80 on %s' % ssh['host'], 3)
        proxy_put(ssh, put)
    return {'proxy': {'host': ssh['host'], 'at': int(time.time()), 'acme_http': on, 'which': which}}, \
        [('the server in front (%s): port 80 %s the ACME CA for %s' % (
            ssh['host'], 'answers' if on else 'no longer answers', name)) if put else
         'the server in front (%s): port 80 for %s as it was' % (ssh['host'], name)]


def proxy_pem_here():
    """The certificate nginx serves here, its chain and its key."""
    now = tls_now()
    if not now.get('server'):
        raise Refused('nginx here has no HTTPS server block to take the certificate from')
    files = now['files']
    try:
        with open(files['cert']) as f:
            cert_text = f.read(500000)
        with open(files['key']) as f:
            key_text = f.read(100000)
    except OSError as e:
        raise Refused('the certificate or its key cannot be read: %s' % e)
    return cert_text, key_text


def proxy_export(raw, ssh, paths, block=''):
    """The certificate of the server in front with its key, for a download -
    read there by root here, made into a file as the one of this machine.
    The second of two side by side (5.42, pair 'alt'): the files its block
    names second."""
    q = shlex.quote
    certs, keys = directives(block, 'ssl_certificate'), directives(block, 'ssl_certificate_key')
    dual = len(certs) > 1 and len(keys) > 1
    cert_path, key_path = paths['cert'], paths['key']
    if str(raw.get('pair') or 'main') == 'alt':
        if not dual:
            raise Refused('nginx on %s serves no second certificate to hand over' % ssh['host'])
        cert_path, key_path = certs[1], keys[1]
        for v in (cert_path, key_path):
            if not PROXY_PATH_RE.match(v) or '..' in v.split('/'):
                raise Refused('nginx on the server in front names a file that is not a plain path: %s' % v[:120])
    code, out, err = proxy_ssh(ssh, 'cat %s; echo; echo ZIGMON-KEY; cat %s; echo; echo ZIGMON-ROOT; '
                                    'cat %s 2>/dev/null; true' % (q(cert_path), q(key_path),
                                                                  q(paths['root'])))
    if code != 0 or 'ZIGMON-KEY' not in out:
        raise Refused('the certificate or its key cannot be read on %s' % ssh['host'])
    cert_text, rest = out.split('ZIGMON-KEY', 1)
    key_text, root_text = (rest.split('ZIGMON-ROOT', 1) + [''])[:2]
    return tls_export(raw, given=(cert_text, key_text.strip() + '\n', root_text), dual=dual)


def encrypt(src, dst, passphrase):
    env = dict(os.environ, ZIGMON_PASS=passphrase)
    run(['openssl', 'enc', '-aes-256-cbc', '-pbkdf2', '-iter', '600000', '-salt',
         '-in', src, '-out', dst, '-pass', 'env:ZIGMON_PASS'], 'encrypting the copy', env=env)


def full_inspect(path, extract_to=None):
    """What a backup holds, trusting none of it: one folder, plain files
    only, every one listed in MANIFEST.json with the right hash, every place
    it names one this kind of backup may have. `trusted` says whether its
    list was sealed by this machine's root."""
    try:
        size = os.path.getsize(path)
    except OSError as e:
        raise Refused('the file cannot be read: %s' % e)
    if size > MOST_FULL:
        raise Refused('the file is bigger than any backup of this house can be')
    try:
        tar = tarfile.open(path, 'r:gz')
    except (tarfile.TarError, OSError, EOFError) as e:
        raise Refused('that is not a .tar.gz (or it needs its password): %s' % e)
    with tar:
        members = []
        try:
            while True:
                one = tar.next()
                if one is None:
                    break
                members.append(one)
                if len(members) > 2000:
                    raise Refused('the file holds far too many files')
        except (tarfile.TarError, OSError, EOFError) as e:
            raise Refused('the file is damaged: %s' % e)
        if not members:
            raise Refused('the file holds nothing')
        top = members[0].name.split('/')[0]
        if not re.match(r'^zigmon-full-[A-Za-z0-9._-]{1,100}$', top):
            raise Refused('that is not a backup of a zigmon installation')
        files, total = {}, 0
        for one in members:
            parts = one.name.split('/')
            if one.name.startswith('/') or '..' in parts or parts[0] != top or '\\' in one.name:
                raise Refused('the file has a path outside its folder: %s' % one.name[:120])
            if one.isdir():
                continue
            if not one.isreg():
                raise Refused('the file holds something that is not a plain file: %s' % one.name[:120])
            total += one.size
            if total > 3 * MOST_FULL:
                raise Refused('the file unpacks to far more than any backup of this house')
            files[one.name] = one
        man_name, mac_name = top + '/MANIFEST.json', top + '/MANIFEST.mac'
        if man_name not in files:
            raise Refused('the file has no MANIFEST.json')
        if files[man_name].size > 4 * 1024 * 1024:
            raise Refused('MANIFEST.json is far too big')
        body = tar.extractfile(files[man_name]).read()
        mac = tar.extractfile(files[mac_name]).read().decode('ascii', 'replace').strip() \
            if mac_name in files else ''
        trusted = bool(mac) and hmac.compare_digest(
            mac, hmac.new(backup_key(), body, hashlib.sha256).hexdigest())
        try:
            man = json.loads(body.decode('utf-8'))
        except ValueError:
            raise Refused('MANIFEST.json does not read')
        if not isinstance(man, dict) or man.get('kind') != 'zigmon-full':
            raise Refused('MANIFEST.json does not describe a backup of a zigmon installation')
        listed = []
        for f in man.get('files') or []:
            if not isinstance(f, dict):
                raise Refused('MANIFEST.json has a line that is not a file')
            part, dest, arc = str(f.get('part') or ''), str(f.get('path') or ''), str(f.get('archive') or '')
            if part not in PARTS:
                raise Refused('MANIFEST.json names a part this kind of backup does not have')
            if arc not in files:
                raise Refused('MANIFEST.json names %s, which is not in the file' % arc[:120])
            if not place_ok(part, dest):
                raise Refused('MANIFEST.json would put a file where no backup of zigmon puts one: %s'
                              % dest[:160])
            if not re.fullmatch(r'[0-7]{3,4}', str(f.get('mode') or '')):
                raise Refused('MANIFEST.json gives %s a mode that is not one' % dest[:120])
            h = hashlib.sha256()
            src = tar.extractfile(files[arc])
            for lump in iter(lambda: src.read(1 << 20), b''):
                h.update(lump)
            if h.hexdigest() != str(f.get('sha256') or ''):
                raise Refused('%s is not the file the list says it is' % dest[:120])
            listed.append({'part': part, 'path': dest, 'archive': arc, 'bytes': files[arc].size,
                           'mode': str(f['mode']), 'owner': str(f.get('owner') or 'root')[:32],
                           'group': str(f.get('group') or 'root')[:32]})
        if extract_to:
            for f in listed:
                out = os.path.join(extract_to, f['archive'])
                os.makedirs(os.path.dirname(out), mode=0o700, exist_ok=True)
                with tar.extractfile(files[f['archive']]) as src, open(out, 'xb') as dst:
                    shutil.copyfileobj(src, dst, 1 << 20)
    by_part = {}
    for f in listed:
        p = by_part.setdefault(f['part'], {'part': f['part'], 'files': 0, 'bytes': 0,
                                           'words': PART_WORDS.get(f['part'], f['part']), 'paths': []})
        p['files'] += 1
        p['bytes'] += f['bytes']
        if len(p['paths']) < 12:
            p['paths'].append(f['path'])
    return {'top': top, 'version': str(man.get('version') or '')[:20],
            'host': str(man.get('host') or '')[:60], 'made_at': man.get('made_at'),
            'why': str(man.get('why') or '')[:80], 'trusted': trusted, 'bytes': size,
            'parts': [by_part[p] for p in PARTS if p in by_part],
            'from_page': [p for p in PARTS if p in by_part and (trusted or p in UNTRUSTED_OK)],
            'files': listed}


def tls_check(work, files, trusted):
    """The certificate that comes back has its key with it, and from a backup
    made somewhere else it goes back only into the files nginx reads its
    certificate from now - nowhere else under /etc."""
    pems = {}
    for f in files:
        with open(os.path.join(work, f['archive']), 'r', errors='replace') as fh:
            pems[f['path']] = fh.read()
    keys = [t for t in pems.values() if 'PRIVATE KEY' in t]
    certs = []
    for text in pems.values():
        certs += re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----', text, re.S)
    if keys:
        for c in certs:
            try:
                pem_set(c, keys[0])
                break
            except Refused:
                continue
        else:
            raise Refused('no certificate in the backup belongs to its key')
    if not trusted:
        try:
            with open(nginx_conf()) as fh:
                text = fh.read()
            where = server_block(text)
            now = set(tls_files(text[where[0]:where[1]]).values()) if where else set()
        except OSError:
            now = set()
        stray = [p for p in pems if p not in now]
        if stray:
            raise Refused('from a backup made somewhere else a certificate goes back only where '
                          'nginx reads it now (%s), not to %s' % (', '.join(sorted(now)) or '-', stray[0]))


PLACES = {
    'config': (r'^/etc/zigmon/config\.json$',),
    'web': (r'^/etc/nginx/conf\.d/[A-Za-z0-9._-]+\.conf$', r'^/etc/nginx/[A-Za-z0-9._-]+\.htpasswd$'),
    'tls': (r'^/etc/nginx/certs/[A-Za-z0-9._-]+$', r'^/etc/mosquitto/(certs/|ca_certificates/)?[A-Za-z0-9._-]+$'),
    'broker': (r'^/etc/mosquitto/[A-Za-z0-9._/-]+$',),
    'firewall': (r'^/etc/sysconfig/ip6?tables$', r'^/etc/firewalld/zones/[A-Za-z0-9_-]+\.xml$'),
    'system': (r'^/etc/systemd/system/zigmon\.service$', r'^/etc/logrotate\.d/zigmon$',
               r'^/etc/sudoers\.d/zigmon$'),
    'zigbee': (r'^/var/lib/zigmon/backups/zigbee2mqtt-[0-9-]+\.zip$',),
    'database': (r'^/[A-Za-z0-9._/-]+\.db$',),
}


def place_ok(part, dest):
    if '..' in dest.split('/') or not dest.startswith('/'):
        return False
    if part == 'zigbee':
        return bool(re.match(r'^%s/backups/zigbee2mqtt-[0-9-]+\.zip$' % re.escape(STATE_DIR), dest))
    if FS_ROOT:
        if not dest.startswith(FS_ROOT + '/'):
            return part == 'database' and bool(re.match(PLACES['database'][0], dest))
        dest = dest[len(FS_ROOT):]
    return any(re.match(rx, dest) for rx in PLACES.get(part) or ())


def owner_ids(user, group):
    try:
        uid = pwd.getpwnam(user).pw_uid
    except KeyError:
        uid = 0
    try:
        gid = grp.getgrnam(group).gr_gid
    except KeyError:
        gid = 0
    return uid, gid


ACCOUNT_TABLES = ("CREATE TABLE IF NOT EXISTS accounts (name TEXT PRIMARY KEY COLLATE NOCASE, "
                  "role TEXT NOT NULL, pw TEXT NOT NULL, disabled INTEGER DEFAULT 0, "
                  "must_change INTEGER DEFAULT 0, note TEXT DEFAULT '', created INTEGER, "
                  "last_in INTEGER, last_from TEXT DEFAULT '', kind TEXT DEFAULT 'password', "
                  "pin_len INTEGER DEFAULT 0);"
                  "CREATE TABLE IF NOT EXISTS signins (token_hash TEXT PRIMARY KEY, name TEXT NOT NULL, "
                  "created INTEGER, last INTEGER, expires INTEGER, ip TEXT DEFAULT '', "
                  "agent TEXT DEFAULT '');"
                  # the passkeys of the accounts (5.43): public keys, kept with them
                  "CREATE TABLE IF NOT EXISTS passkeys (id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE, "
                  "label TEXT DEFAULT '', pem TEXT NOT NULL, alg INTEGER NOT NULL, count INTEGER DEFAULT 0, "
                  "created INTEGER, last_used INTEGER, host TEXT DEFAULT '', backed_up INTEGER DEFAULT 0);")


def accounts_of(db):
    """The accounts of the dashboard and its sign-ins, as the live database
    has them now (5.19) - kept across putting a database back: a backup
    from before 5.19 has none, and one from last month an old password, and
    the person restoring would be signed out of the house they are mending."""
    import sqlite3
    if not os.path.isfile(db):
        return None
    try:
        con = sqlite3.connect('file:%s?mode=ro' % db, uri=True)
        try:
            con.row_factory = sqlite3.Row
            acc = [dict(r) for r in con.execute('SELECT * FROM accounts')]
            sig = [dict(r) for r in con.execute('SELECT * FROM signins')]
            # and their passkeys (5.43), where the database is new enough to have them
            try:
                pks = [dict(r) for r in con.execute('SELECT * FROM passkeys')]
            except sqlite3.OperationalError:
                pks = []
        finally:
            con.close()
    except sqlite3.Error as e:
        print('zigmon_root.py: the accounts of the dashboard could not be read before the database '
              'was put back (%s): it brings its own' % e, file=sys.stderr)
        return None
    return {'accounts': acc, 'signins': sig, 'passkeys': pks} if acc else None


def accounts_into(db, kept, owner):
    import sqlite3
    con = sqlite3.connect(db)
    try:
        con.executescript(ACCOUNT_TABLES)
        for col in ("kind TEXT DEFAULT 'password'", 'pin_len INTEGER DEFAULT 0'):
            try:
                con.execute('ALTER TABLE accounts ADD COLUMN ' + col)
            except sqlite3.OperationalError:
                pass
        con.execute('DELETE FROM accounts')
        con.execute('DELETE FROM signins')
        con.execute('DELETE FROM passkeys')
        for table in ('accounts', 'signins', 'passkeys'):
            for row in kept.get(table) or []:
                cols = sorted(row)
                con.execute('INSERT INTO %s (%s) VALUES (%s)' % (table, ','.join(cols), ','.join('?' * len(cols))),
                            [row[c] for c in cols])
        con.commit()
    finally:
        con.close()
    # root opened it: anything it left beside the file is the daemon's again
    # (5.44.1) by the open file, never by its name: the folder is zigmon's,
    # and a name there may be a link to a file of root's
    for extra in (db, db + '-wal', db + '-shm', db + '-journal'):
        try:
            fd = os.open(extra, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        except OSError:
            continue
        try:
            if stat.S_ISREG(os.fstat(fd).st_mode):
                os.fchown(fd, owner[0], owner[1])
        except OSError:
            pass
        finally:
            os.close(fd)


def full_restore(path, parts, from_page=True, passphrase='', before=True, say=None):
    """Put the chosen parts of a backup back. The daemon is stopped while its
    database or its configuration are put back, everything is put back as it
    was when nginx refuses what came out, and a backup of how it was right
    before is made first - so a restore can itself be undone."""
    said = []

    def note(text):
        said.append(text)
        if say:
            say(text)
    info = full_inspect(path)
    parts = [p for p in parts if p in PARTS]
    if not parts:
        raise Refused('choose what to put back')
    missing = [p for p in parts if p not in {x['part'] for x in info['parts']}]
    if missing:
        raise Refused('the backup has no %s' % ', '.join(missing))
    if from_page and not info['trusted']:
        bad = [p for p in parts if p not in UNTRUSTED_OK]
        if bad:
            raise Refused('this backup was not made by this machine, so %s can only be put back by '
                          'root on the command line (zigmon --full-restore FILE --parts %s)'
                          % (', '.join(bad), ','.join(parts)))
    work = tempfile.mkdtemp(prefix='zigmon-restore-')
    os.chmod(work, 0o700)
    stopped = False
    snap = {}
    try:
        full_inspect(path, extract_to=work)
        chosen = [f for f in info['files'] if f['part'] in parts]
        if 'tls' in parts:
            tls_check(work, [f for f in chosen if f['part'] == 'tls'], trusted=info['trusted'])
        if 'config' in parts:
            for f in chosen:
                if f['part'] == 'config':
                    try:
                        json.load(open(os.path.join(work, f['archive'])))
                    except ValueError:
                        raise Refused('the configuration in the backup is not JSON')
        if before:
            note('a backup of how it is now: %s' % full_make('before a restore', keep=7,
                                                               suffix='-before-restore')['file'])
        if {'database', 'config'} & set(parts):
            service('stop', 'zigmon')
            stopped = True
            note('zigmon stopped')
        dests = [f['path'] for f in chosen if f['part'] != 'database']
        live_db = db_file()
        if 'database' in parts and from_page and not db_file_ours(live_db):
            raise Refused('the database is not in %s (db_file is %s), so it is put back by root on '
                          'the command line only' % (STATE_DIR, live_db))
        if 'database' in parts:
            dests += [live_db, live_db + '-wal', live_db + '-shm']
        snap = snapshot(dests)
        for f in chosen:
            src = os.path.join(work, f['archive'])
            with open(src, 'rb') as fh:
                data = fh.read()
            if f['part'] == 'database':
                if not data.startswith(SQLITE_HEAD):
                    raise Refused('the database in the backup is not an SQLite database')
                kept = accounts_of(live_db)
                for extra in (live_db + '-wal', live_db + '-shm'):
                    try:
                        os.unlink(extra)
                    except OSError:
                        pass
                try:
                    owner = (service_uid(), service_gid())
                except KeyError:
                    owner = (0, 0)
                write_root(live_db, data, 0o640, owner=owner)
                if kept:
                    accounts_into(live_db, kept, owner)
                note('the database put back (%d MB)%s' % (
                    len(data) // 1048576, ', the accounts of the dashboard kept as they were' if kept else ''))
                continue
            uid, gid = owner_ids(f['owner'], f['group'])
            mode = int(f['mode'], 8) & 0o777
            if f['part'] == 'zigbee':
                uid, gid = owner_ids(SERVICE_USER, SERVICE_USER)
            if from_page and not info['trusted']:
                # who owns it and who may read it are not the uploaded list's
                # to say: it made config.json 0666, and the private key
                # anybody's. The file there now keeps its own; a new one is
                # nobody's but its owner's.
                mode &= 0o640
                if f['part'] == 'config':
                    data = config_kept_local(data)
                if f['part'] != 'zigbee':
                    write_root(f['path'], data, 0o600)
                    note('%s put back' % f['path'])
                    continue
            if f['part'] == 'zigbee':
                # (5.44.1) into the state folder by its descriptor: the
                # zigmon account may put a link in place of backups/
                write_here(os.path.basename(f['path']), data, dir_fd=sub_fd('backups'),
                           mode=mode, owner=(uid, gid))
                note('%s put back' % f['path'])
                continue
            write_root(f['path'], data, mode, owner=(uid, gid))
            note('%s put back' % f['path'])
        if {'web', 'tls'} & set(parts):
            t = subprocess.run(NGINX_TEST, capture_output=True, text=True)
            if t.returncode != 0:
                raise Refused('nginx does not take what came back, so all of it is as it was: %s'
                              % ((t.stderr or '').strip().splitlines() or ['?'])[-1][:300])
            service('reload', 'nginx')
            note('nginx reloaded')
        if 'system' in parts:
            service('daemon-reload')
        if 'broker' in parts:
            got = service('restart', 'mosquitto')
            note('mosquitto restarted' if got.returncode == 0 else
                 'mosquitto did not restart: %s' % (got.stderr or '').strip()[-160:])
        elif 'tls' in parts:
            tls_paths = [f['path'] for f in chosen if f['part'] == 'tls']
            if mosquitto_reads(tls_paths):
                note(mosquitto_hup())
        if 'firewall' in parts:
            if firewalld_running():
                got = fwd('--reload')
                note('firewalld read its zones again' if got.returncode == 0 else
                     'firewalld did not reload: %s' % fw_said(got.stderr))
            else:
                for fam in (4, 6):
                    restore = tool(FW_TOOLS[fam][1])
                    if restore and os.path.exists(FW_FILES[fam]):
                        got = subprocess.run([restore, FW_FILES[fam]], capture_output=True, text=True)
                        note('IPv%d: the saved rules put in' % fam if got.returncode == 0 else
                             'IPv%d: %s' % (fam, fw_said(got.stderr)))
    except BaseException:
        if snap:
            put_back(snap)
            note('everything put back as it was')
        raise
    finally:
        shutil.rmtree(work, ignore_errors=True)
        if stopped:
            service('start', 'zigmon')
            note('zigmon started')
    return said



# ---- the machine's network, its name, and switching it off (5.21) ---------------------
# Asked in net.ask, answered in net.json, beside request.json and never behind
# it: what the network is now (read), a new one put in NetworkManager with the
# host name and /etc/hosts (apply), or a restart or a power-off a few seconds
# on (power). Every value is checked here again - addresses by ipaddress,
# names by NAME_RE, the connection by the list NetworkManager gives - whatever
# the daemon checked before. Ported from otp 1.0.137, which keeps a machine's
# network the same way; zigmon takes DHCP as well, both ways.
NET_ASK = 'net.ask'
NET_FILE = 'net.json'
NMCLI = os.environ.get('ZIGMON_NMCLI', 'nmcli')
HOSTNAMECTL = os.environ.get('ZIGMON_HOSTNAMECTL', 'hostnamectl')
HOSTS_FILE = os.environ.get('ZIGMON_HOSTS_FILE', '/etc/hosts')
POWER_CMD = os.environ.get('ZIGMON_POWER_CMD', '')        # tests: a file written instead
IP_CMD = os.environ.get('ZIGMON_IP_CMD', 'ip')
RESOLV_FILE = os.environ.get('ZIGMON_RESOLV', '/etc/resolv.conf')
NAME_RE = re.compile(r'^(?=.{1,253}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?'
                     r'(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$')


def drop_ask(name, d):
    """An asking file taken away, whatever the zigmon account made of it: a
    link (refused by O_NOFOLLOW) or a folder left there would have the path
    unit start this service again and again until systemd gave up - and with
    it every later certificate, firewall and backup."""
    try:
        os.unlink(name, dir_fd=d)
        return
    except FileNotFoundError:
        return
    except OSError:
        pass
    try:
        os.rmdir(name, dir_fd=d)
        return
    except OSError:
        pass
    try:
        os.rename(name, '.refused-%s-%d' % (name, int(time.time())), src_dir_fd=d, dst_dir_fd=d)
    except OSError:
        pass


def nm_fields(con, fields):
    out = run([NMCLI, '-t', '-g', ','.join(fields), 'connection', 'show', con],
              'nmcli connection show')
    vals = out.rstrip('\n').split('\n')
    got = {}
    for k, v in zip(fields, vals + [''] * (len(fields) - len(vals))):
        got[k] = v.replace('\\:', ':').strip()
    return got


def nm_list(text):
    return [x.strip() for x in re.split(r'[,\s]+', text or '') if x.strip() and x.strip() != '--']


NM_FIELDS = ['ipv4.method', 'ipv4.addresses', 'ipv4.gateway', 'ipv4.dns', 'ipv4.dns-search',
             'ipv6.method', 'ipv6.addresses', 'ipv6.gateway', 'ipv6.dns']


def net_read():
    out = {'nm': bool(shutil.which(NMCLI)), 'devices': [], 'con': '', 'dev': '', 'conf': {},
           'live': {'addrs4': [], 'addrs6': [], 'gw4': '', 'gw6': '', 'dns': []}}
    try:
        with open('/proc/sys/net/ipv6/conf/all/disable_ipv6') as f:
            out['ipv6_kernel'] = f.read().strip() == '0'
    except OSError:
        out['ipv6_kernel'] = False
    try:
        for line in run([IP_CMD, '-o', 'addr', 'show'], 'ip addr').splitlines():
            f = line.split()
            if len(f) < 4 or f[1] == 'lo':
                continue
            try:
                ifc = ipaddress.ip_interface(f[3])
            except ValueError:
                continue
            if ifc.ip.is_loopback or ifc.ip.is_link_local:
                continue
            (out['live']['addrs4'] if ifc.version == 4 else out['live']['addrs6']).append(
                {'addr': str(ifc), 'dev': f[1].split('@')[0]})
        for fam, key in (('-4', 'gw4'), ('-6', 'gw6')):
            r = run([IP_CMD, fam, 'route', 'show', 'default'], 'ip route', ok=(0, 1, 2))
            m = re.search(r'default via (\S+) dev (\S+)', r)
            if m:
                out['live'][key] = m.group(1)
                if key == 'gw4':
                    out['dev'] = m.group(2)
    except (Refused, OSError):
        pass
    try:
        with open(RESOLV_FILE) as f:
            out['live']['dns'] = [l.split()[1] for l in f if l.startswith('nameserver ')
                                  and len(l.split()) > 1][:6]
    except OSError:
        pass
    try:
        out['hostname'] = run([HOSTNAMECTL, '--static'], 'hostnamectl').strip() or \
            os.uname().nodename
    except (Refused, OSError):
        out['hostname'] = os.uname().nodename
    if not out['nm']:
        return out
    try:
        for line in run([NMCLI, '-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device'],
                        'nmcli device').splitlines():
            f = line.replace('\\:', '\x00').split(':')
            f = [x.replace('\x00', ':') for x in f]
            if len(f) >= 4 and f[1] in ('ethernet', 'bond', 'vlan', 'bridge', 'team', 'wifi'):
                out['devices'].append({'dev': f[0], 'type': f[1], 'state': f[2], 'con': f[3]})
    except Refused as e:
        out['nm_said'] = str(e)
    dev = out['dev'] or next((d['dev'] for d in out['devices'] if d['con']), '')
    con = next((d['con'] for d in out['devices'] if d['dev'] == dev and d['con']), '')
    out['dev'], out['con'] = dev, con
    if con:
        try:
            g = nm_fields(con, NM_FIELDS)
            out['conf'] = {'ipv4_method': g['ipv4.method'],
                           'ipv4_addresses': nm_list(g['ipv4.addresses']),
                           'ipv4_gateway': g['ipv4.gateway'] if g['ipv4.gateway'] != '--' else '',
                           'ipv4_dns': nm_list(g['ipv4.dns']),
                           'ipv4_search': nm_list(g['ipv4.dns-search']),
                           'ipv6_method': g['ipv6.method'],
                           'ipv6_addresses': nm_list(g['ipv6.addresses']),
                           'ipv6_gateway': g['ipv6.gateway'] if g['ipv6.gateway'] != '--' else '',
                           'ipv6_dns': nm_list(g['ipv6.dns'])}
        except Refused as e:
            out['nm_said'] = str(e)
    return out


def net_checked(r):
    """An apply request, every value in its one shape."""
    out = {'con': str(r.get('con') or ''), 'reboot_in': 0}
    if not out['con'] or len(out['con']) > 120 or any(c in out['con'] for c in '\n\r\x00'):
        raise Refused('which connection?')
    v4 = r.get('ipv4') or {}
    out['method4'] = 'auto' if str(v4.get('method') or 'manual') == 'auto' else 'manual'
    out['addr4'], out['gw4'] = '', ''
    if out['method4'] == 'manual':
        try:
            a4 = plain(v4.get('addr'), 'interface')
        except ValueError:
            raise Refused('the IPv4 address is an address with its prefix (192.0.2.10/24)')
        if a4.version != 4 or '/' not in str(v4.get('addr')):
            raise Refused('the IPv4 address is an address with its prefix (192.0.2.10/24)')
        out['addr4'] = str(a4)
        gw = str(v4.get('gw') or '').strip()
        if gw:
            try:
                g = plain(gw, 'address')
            except ValueError:
                raise Refused('the gateway is one IPv4 address')
            if g.version != 4 or g not in a4.network:
                raise Refused('the gateway %s is not in %s' % (g, a4.network))
            out['gw4'] = str(g)
    dns = []
    for d in list(v4.get('dns') or [])[:4] + list((r.get('ipv6') or {}).get('dns') or [])[:4]:
        try:
            dns.append(str(plain(d, 'address')))
        except ValueError:
            raise Refused('%r is not the address of a DNS server' % str(d)[:60])
    out['dns4'] = [d for d in dns if ':' not in d]
    out['dns6'] = [d for d in dns if ':' in d]
    search = []
    for s_ in list(v4.get('search') or [])[:6]:
        if not NAME_RE.match(str(s_)):
            raise Refused('%r is not a domain' % str(s_)[:60])
        search.append(str(s_))
    out['search'] = search
    v6 = r.get('ipv6') or {}
    mode = str(v6.get('mode') or 'off')
    if mode not in ('off', 'auto', 'manual', 'keep'):
        raise Refused('IPv6 is off, auto, manual or keep')
    out['mode6'] = mode
    if mode == 'manual':
        try:
            a6 = plain(v6.get('addr'), 'interface')
        except ValueError:
            raise Refused('the IPv6 address is an address with its prefix (2001:db8::10/64)')
        if a6.version != 6 or a6.ip.is_link_local or '/' not in str(v6.get('addr')):
            raise Refused('the IPv6 address is a global one with its prefix (2001:db8::10/64)')
        out['addr6'] = str(a6)
        out['gw6'] = ''
        g6 = str(v6.get('gw') or '').strip()
        if g6:
            try:
                gg = plain(g6, 'address')
            except ValueError:
                raise Refused('the IPv6 gateway is one IPv6 address')
            if gg.version != 6:
                raise Refused('the IPv6 gateway is one IPv6 address')
            out['gw6'] = str(gg)
    host = str(r.get('hostname') or '').strip().rstrip('.').lower()
    if host and (not NAME_RE.match(host) or '.' not in host):
        raise Refused('the host name is the whole name: zigmon.example.cz')
    out['hostname'] = host
    olds = []
    for o in list(r.get('old') or [])[:8]:
        try:
            olds.append(str(plain(o, 'address')))
        except ValueError:
            pass
    out['old'] = olds
    old_host = str(r.get('old_hostname') or '').strip().lower()
    out['old_hostname'] = old_host if NAME_RE.match(old_host or 'x') else ''
    try:
        out['reboot_in'] = max(0, min(600, int(r.get('reboot_in') or 0)))
    except (TypeError, ValueError):
        out['reboot_in'] = 0
    return out


def hosts_lines(text, n):
    """/etc/hosts with this machine's lines for its old addresses and names
    taken out and its new ones put in; localhost lines kept as they are. With
    an address from DHCP there is no address to write: the old lines go, and
    the name is left to DNS."""
    short = n['hostname'].split('.')[0] if n['hostname'] else ''
    drop_names = set(x for x in (n['hostname'], short, n['old_hostname'],
                                 n['old_hostname'].split('.')[0]) if x)
    new4 = n['addr4'].split('/')[0] if n.get('addr4') else ''
    out = []
    for line in text.splitlines():
        f = line.split('#', 1)[0].split()
        if f and not f[0].startswith(('127.', '::1')):
            if f[0] in n['old'] or (new4 and f[0] == new4) or \
                    any(x.lower() in drop_names for x in f[1:]):
                continue
        out.append(line)
    if n['hostname'] and new4:
        out.append('%s %s %s    # this machine - written by zigmon' % (new4, n['hostname'], short))
        if n.get('addr6'):
            out.append('%s %s %s    # this machine - written by zigmon' % (
                n['addr6'].split('/')[0], n['hostname'], short))
    return '\n'.join(out) + '\n'


def power_after(what, secs):
    """A restart or a power-off a few seconds from now - after this helper
    has written its answer and the page has had it. A transient timer of
    systemd's: it outlives this oneshot service."""
    secs = max(3, int(secs or 5))
    if POWER_CMD:
        with open(POWER_CMD, 'a') as f:
            f.write('%s %d %s\n' % (what, secs, time.time()))
        return '%s in %d s (written to %s)' % (what, secs, POWER_CMD)
    if NO_SERVICES:
        return '%s in %d s (not here: tests)' % (what, secs)
    run(['systemd-run', '--on-active=%ds' % secs, '--unit',
         'zigmon-%s-%d' % (what, int(time.time())), '/usr/bin/systemctl', what],
        'systemd-run %s' % what)
    return '%s in %d s' % (what, secs)


def net_apply(n):
    if not shutil.which(NMCLI):
        raise Refused('NetworkManager (nmcli) is not on this machine: set the network by hand')
    cons = [l.replace('\\:', ':') for l in run([NMCLI, '-t', '-g', 'NAME', 'connection',
                                                'show'], 'nmcli connection show').splitlines()]
    if n['con'] not in cons:
        raise Refused('there is no connection %r here' % n['con'])
    said = []
    before = nm_fields(n['con'], NM_FIELDS)
    if n['method4'] == 'auto':
        # From DHCP: no address, no gateway of our own - the DNS servers given
        # here are kept in place of the lease's only when there are some
        args = [NMCLI, 'connection', 'modify', n['con'],
                'ipv4.method', 'auto', 'ipv4.addresses', '', 'ipv4.gateway', '',
                'ipv4.dns', ','.join(n['dns4']), 'ipv4.dns-search', ','.join(n['search']),
                'ipv4.ignore-auto-dns', 'yes' if n['dns4'] else 'no']
    else:
        args = [NMCLI, 'connection', 'modify', n['con'],
                'ipv4.method', 'manual', 'ipv4.addresses', n['addr4'],
                'ipv4.gateway', n['gw4'], 'ipv4.dns', ','.join(n['dns4']),
                'ipv4.dns-search', ','.join(n['search']), 'ipv4.ignore-auto-dns', 'yes']
    if n['mode6'] == 'off':
        args += ['ipv6.method', 'disabled', 'ipv6.addresses', '', 'ipv6.gateway', '',
                 'ipv6.dns', '']
    elif n['mode6'] == 'auto':
        args += ['ipv6.method', 'auto', 'ipv6.addresses', '', 'ipv6.gateway', '',
                 'ipv6.dns', ','.join(n['dns6'])]
    elif n['mode6'] == 'manual':
        args += ['ipv6.method', 'manual', 'ipv6.addresses', n['addr6'],
                 'ipv6.gateway', n['gw6'], 'ipv6.dns', ','.join(n['dns6'])]
    run(args, 'nmcli connection modify')
    said.append('NetworkManager: %s - %s, DNS %s%s' % (
        n['con'], 'an address from DHCP' if n['method4'] == 'auto' else
        '%s via %s' % (n['addr4'], n['gw4'] or 'no gateway'),
        ', '.join(n['dns4']) or ('from DHCP' if n['method4'] == 'auto' else 'none'),
        {'off': ', IPv6 off', 'auto': ', IPv6 automatic',
         'manual': ', IPv6 %s' % n.get('addr6'), 'keep': ''}[n['mode6']]))
    if n['mode6'] in ('auto', 'manual'):
        # IPv6 switched off in the kernel by an earlier hand: on again
        write_root(FS_ROOT + '/etc/sysctl.d/90-zigmon-ipv6.conf',
                   '%s\nnet.ipv6.conf.all.disable_ipv6 = 0\nnet.ipv6.conf.default.'
                   'disable_ipv6 = 0\n' % MARK, 0o644)
    if n['hostname']:
        run([HOSTNAMECTL, 'set-hostname', n['hostname']], 'hostnamectl set-hostname')
        said.append('host name: %s' % n['hostname'])
    try:
        with open(HOSTS_FILE) as f:
            had = f.read()
    except OSError:
        had = '127.0.0.1 localhost localhost.localdomain\n::1 localhost localhost.localdomain\n'
    new = hosts_lines(had, n)
    if new != had:
        try:
            write_root(HOSTS_FILE + '.zigmon-before', had, 0o644)
        except OSError:
            pass
        write_root(HOSTS_FILE, new, 0o644)
        said.append('%s: this machine\'s lines' % HOSTS_FILE)
    if n['reboot_in']:
        said.append(power_after('reboot', n['reboot_in']))
    return {'said': said, 'before': before}


def ask_part(ask, answer, handle_one, most=65536):
    """One asking file of the daemon's: read, always taken away, answered."""
    d = root_fd()
    try:
        raw = read_req(ask, most)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_ask(ask, d)
        return
    drop_ask(ask, d)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        r = json.loads(raw.decode('utf-8'))
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        until = r.get('until')
        if isinstance(until, (int, float)) and not isinstance(until, bool) and time.time() > until:
            # asked while a backup held this service: the daemon has given
            # up waiting and told everyone it was not done - so it is not
            raise Refused('asked too long ago - nobody waits for it any more')
        out['data'] = handle_one(r)
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(answer, json.dumps(out))


def net_one(r):
    what = r.get('do')
    if what == 'read':
        return net_read()
    if what == 'apply':
        return net_apply(net_checked(r))
    if what == 'power':
        how = r.get('how')
        if how not in ('reboot', 'poweroff'):
            raise Refused('reboot or poweroff')
        try:
            secs = int(r.get('in') or 5)
        except (TypeError, ValueError):
            secs = 5
        return {'said': [power_after(how, min(secs, 600))]}
    if what == 'console':
        # whether root signing in lands in zigmon's console: a file in /etc,
        # where the zigmon group cannot write - put in its place, so a link
        # found there is replaced, never followed
        path = os.environ.get('ZIGMON_CONSOLE_FLAG') or (FS_ROOT + '/etc/zigmon-console-login')
        word = 'on' if r.get('on') is True else 'off'
        write_root(path, word + '\n', 0o644, owner=(0, 0))
        return {'said': ['the console at login: %s' % word]}
    raise Refused('read, apply, power or console')


def net_part():
    ask_part(NET_ASK, NET_FILE, net_one)


# ---- the time: chrony (5.21) -------------------------------------------------------
# Asked in ntp.ask: how the clock is (read), chrony's servers set (apply), a
# step to the right time now (sync). /etc/chrony.conf keeps everything of its
# own; when zigmon sets the servers, the file's own server/pool/makestep/allow
# lines are commented out (#zigmon#) and zigmon's block is added between marks
# - put back as they were when it stops setting them.
NTP_ASK = 'ntp.ask'
NTP_FILE = 'ntp.json'
CHRONYC = os.environ.get('ZIGMON_CHRONYC', 'chronyc')
TIMEDATECTL = os.environ.get('ZIGMON_TIMEDATECTL', 'timedatectl')
CHRONY_CONF = os.environ.get('ZIGMON_CHRONY_CONF', '/etc/chrony.conf')
NTP_BEGIN = '# ---- zigmon: the time servers, set on the dashboard (Control - Time) ----'
NTP_END = '# ---- zigmon: end ----'
NTP_MARK = '#zigmon# '
NTP_KEYS = ('server', 'pool', 'peer', 'makestep', 'allow', 'minsources', 'maxdistance', 'sourcedir')
TZ_RE = re.compile(r'^[A-Za-z0-9_+-]{1,40}(/[A-Za-z0-9_+-]{1,40}){0,3}\Z')


def ntp_read():
    out = {'chrony': bool(shutil.which(CHRONYC)), 'tracking': {}, 'sources': []}
    try:
        t = run([TIMEDATECTL, 'show'], 'timedatectl', ok=(0, 1))
        for line in t.splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                if k in ('Timezone', 'NTP', 'NTPSynchronized', 'LocalRTC', 'CanNTP'):
                    out[k.lower()] = v
    except (Refused, OSError):
        pass
    out['time'] = time.time()
    if not out['chrony']:
        return out
    try:
        f = run([CHRONYC, '-c', 'tracking'], 'chronyc tracking').strip().split(',')
        if len(f) >= 14:
            out['tracking'] = {'ref_id': f[0], 'ref': f[1][:120], 'stratum': int(f[2] or 0),
                               'ref_time': float(f[3] or 0), 'offset': float(f[4] or 0),
                               'last_offset': float(f[5] or 0), 'rms': float(f[6] or 0),
                               'freq': float(f[7] or 0), 'skew': float(f[9] or 0),
                               'root_delay': float(f[10] or 0), 'root_disp': float(f[11] or 0),
                               'interval': float(f[12] or 0), 'leap': f[13][:40]}
    except (Refused, ValueError, OSError) as e:
        out['said'] = str(e)[:200]
    try:
        for line in run([CHRONYC, '-c', 'sources'], 'chronyc sources').splitlines():
            f = line.split(',')
            if len(f) < 10:
                continue
            try:
                out['sources'].append({'mode': f[0][:2], 'state': f[1][:2], 'name': f[2][:120],
                                       'stratum': int(f[3] or 0), 'poll': int(f[4] or 0),
                                       'reach': int(f[5] or 0, 8) if f[5] else 0,
                                       'last_rx': int(f[6]) if f[6].lstrip('-').isdigit() else None,
                                       'offset': float(f[7] or 0), 'measured': float(f[8] or 0),
                                       'error': float(f[9] or 0)})
            except ValueError:
                continue
    except (Refused, OSError):
        pass
    try:
        with open(CHRONY_CONF) as f:
            text = f.read()
        out['managed'] = NTP_BEGIN in text
        out['own'] = [l.strip() for l in text.splitlines()
                      if l.strip().split(' ')[0] in ('server', 'pool', 'peer')][:20]
    except OSError:
        out['managed'] = False
    return out


def ntp_checked(r):
    out = {'manage': bool(r.get('manage')), 'servers': [], 'allow': [],
           'makestep': [1.0, 3], 'minsources': 1, 'timezone': ''}
    for x in list(r.get('servers') or [])[:12]:
        if not isinstance(x, dict):
            raise Refused('a server is an object')
        host = str(x.get('host') or '').strip().lower().rstrip('.')
        try:
            host = str(plain(host, 'address'))
        except ValueError:
            if not NAME_RE.match(host):
                raise Refused('%r is not a host name or an address' % host[:80])
        out['servers'].append({'host': host, 'pool': bool(x.get('pool')),
                               'iburst': bool(x.get('iburst', True)),
                               'prefer': bool(x.get('prefer')), 'nts': bool(x.get('nts'))})
    for a in list(r.get('allow') or [])[:20]:
        try:
            out['allow'].append(str(plain(a, 'network')))
        except ValueError:
            raise Refused('%r is not a network (192.0.2.0/24)' % str(a)[:60])
    try:
        th = float((r.get('makestep') or [1.0, 3])[0])
        lim = int((r.get('makestep') or [1.0, 3])[1])
    except (TypeError, ValueError, IndexError):
        raise Refused('makestep is a threshold in seconds and a number of updates')
    if not (0.001 <= th <= 3600) or not (-1 <= lim <= 1000):
        raise Refused('makestep: 0.001 - 3600 s, and -1 (always) to 1000 updates')
    out['makestep'] = [th, lim]
    try:
        out['minsources'] = max(1, min(10, int(r.get('minsources') or 1)))
    except (TypeError, ValueError):
        out['minsources'] = 1
    tz = str(r.get('timezone') or '').strip()
    if tz and not TZ_RE.match(tz):
        raise Refused('%r is not a time zone' % tz[:60])
    out['timezone'] = tz
    if out['manage'] and not out['servers']:
        raise Refused('at least one time server')
    return out


def ntp_conf_text(text, n):
    """chrony.conf with zigmon's block (or without it, put back as it was)."""
    out, inside = [], False
    for l in text.splitlines():
        if l.strip() == NTP_BEGIN:
            inside = True
            continue
        if l.strip() == NTP_END:
            inside = False
            continue
        if inside:
            continue
        if l.startswith(NTP_MARK):
            l = l[len(NTP_MARK):]           # the file's own line, put back first
        out.append(l)
    if not n['manage']:
        return '\n'.join(out).rstrip('\n') + '\n'
    kept = [(NTP_MARK + l) if l.strip().split(' ')[0] in NTP_KEYS else l for l in out]
    block = [NTP_BEGIN]
    for x in n['servers']:
        opts = [o for o, on in (('iburst', x['iburst']), ('prefer', x['prefer']),
                                ('nts', x['nts'])) if on]
        block.append(('%s %s %s' % ('pool' if x['pool'] else 'server', x['host'], ' '.join(opts))).rstrip())
    for a in n['allow']:
        block.append('allow %s' % a)
    block.append('makestep %s %d' % (('%g' % n['makestep'][0]), n['makestep'][1]))
    if n['minsources'] > 1:
        block.append('minsources %d' % n['minsources'])
    block.append(NTP_END)
    return '\n'.join([l.rstrip() for l in kept]).rstrip('\n') + '\n\n' + '\n'.join(block) + '\n'


def ntp_apply(n):
    said = []
    if not shutil.which(CHRONYC) and not NO_SERVICES:
        if shutil.which('dnf'):
            run(['dnf', '-y', 'install', 'chrony'], 'dnf install chrony')
            said.append('chrony installed')
        else:
            raise Refused('chrony is not on this machine')
    try:
        with open(CHRONY_CONF) as f:
            had = f.read()
    except FileNotFoundError:
        had = 'driftfile /var/lib/chrony/drift\nrtcsync\nlogdir /var/log/chrony\n'
    new = ntp_conf_text(had, n)
    if new != had:
        if NTP_BEGIN not in had:
            try:
                write_root(CHRONY_CONF + '.zigmon-before', had, 0o644)
            except OSError:
                pass
        write_root(CHRONY_CONF, new, 0o644)
        said.append('%s: %s' % (CHRONY_CONF, ', '.join(x['host'] for x in n['servers'])
                                if n['manage'] else 'its own servers again'))
        if not NO_SERVICES:
            run(['systemctl', 'enable', '--now', 'chronyd'], 'systemctl enable chronyd')
            run(['systemctl', 'restart', 'chronyd'], 'systemctl restart chronyd')
            said.append('chronyd restarted')
    if n['timezone']:
        try:
            cur = run([TIMEDATECTL, 'show', '-p', 'Timezone', '--value'], 'timedatectl').strip()
        except (Refused, OSError):
            cur = ''
        if cur != n['timezone']:
            run([TIMEDATECTL, 'set-timezone', n['timezone']], 'timedatectl set-timezone')
            said.append('time zone: %s' % n['timezone'])
    if not NO_SERVICES and shutil.which(TIMEDATECTL):
        run([TIMEDATECTL, 'set-ntp', 'true'], 'timedatectl set-ntp', ok=(0, 1))
    return {'said': said}


def ntp_one(r):
    what = r.get('do')
    if what == 'read':
        got = ntp_read()
        if r.get('zones'):
            try:
                got['zones'] = [z for z in run([TIMEDATECTL, 'list-timezones'],
                                               'timedatectl').split() if TZ_RE.match(z)][:700]
            except (Refused, OSError):
                pass
        return got
    if what == 'apply':
        return ntp_apply(ntp_checked(r))
    if what == 'sync':
        said = run([CHRONYC, 'makestep'], 'chronyc makestep').strip()
        run([CHRONYC, 'burst', '4/4'], 'chronyc burst', ok=(0, 1))
        return {'said': [said[:200] or 'stepped']}
    raise Refused('read, apply or sync')


def ntp_part():
    ask_part(NTP_ASK, NTP_FILE, ntp_one)


# ---- the updates of the operating system (5.34, otp 1.0.158 - 1.0.193) ------------------
# Asked in osup.ask and answered at once in osup.ans: the work itself - minutes
# of dnf, a quarter of an hour on a slow line - runs as a unit of its own
# (systemd-run), so this oneshot service ends at once and every other ask is
# served meanwhile, and the daemon may restart, or be upgraded, while it goes
# on. The job holds a lock of its own for as long as it runs: a second one is
# refused, never queued. Its progress and its last lines go into osup.json
# every second or so, the whole of what dnf said into osup.log (a look's into
# osup-check.log, so that it does not write over the update's) - all written
# into the zigmon account's folder for the group to read, as every answer is.
# Nothing in the request reaches a command line but the two words the job is
# started with, each checked against the one shape it may have.
OSUP_ASK = 'osup.ask'
OSUP_ANS = 'osup.ans'
OSUP_FILE = 'osup.json'
OSUP_LOG = {'upgrade': 'osup.log', 'check': 'osup-check.log'}
OSUP_LOCK = os.environ.get('ZIGMON_OSUP_LOCK', '/run/zigmon-osup.lock')
# where the job looks for dnf and needs-restarting (tests: a folder of fakes first)
OSUP_PATH = os.environ.get('ZIGMON_OSUP_PATH', '/usr/sbin:/usr/bin:/sbin:/bin')
OSUP_JOB_RE = re.compile(r'^[0-9a-f]{12,32}\Z')
# The proxy dnf goes through (5.35, otp 1.0.166 - Control - Proxy): handed over
# in osup.ask, kept here for the job in a file only root reads (0600), and given
# to dnf in its environment - never on a command line, never in osup.json or
# osup.log (the job says only host:port). No proxy in the ask: the file goes.
OSUP_PROXY = os.environ.get('ZIGMON_OSUP_PROXY', '/run/zigmon-osup-proxy.json')
OSUP_PROXY_RE = re.compile(r'^http://(?:[^\s:@/]+(?::[^\s@/]*)?@)?'
                           r'(?:[A-Za-z0-9.-]{1,253}|\[[0-9A-Fa-f:.]+\])(?::\d{1,5})?/?\Z')
OSUP_KINDS = ('check', 'upgrade')
# The packages a restart is needed for once they are updated, as dnf
# needs-restarting -r names them (otp 1.0.159): told before the update is made.
REBOOT_PKGS = {'kernel', 'kernel-core', 'kernel-rt', 'kernel-rt-core', 'kernel-modules',
               'kernel-modules-core', 'kernel-uek', 'glibc', 'linux-firmware', 'systemd',
               'dbus', 'dbus-broker', 'dbus-daemon', 'microcode_ctl', 'zlib', 'zlib-ng-compat',
               'openssl-libs', 'gnutls'}


def osup_tool(name):
    return shutil.which(name, path=OSUP_PATH)


def osup_running():
    """Whether a job holds the lock now - asked without waiting for it."""
    import fcntl
    try:
        fd = os.open(OSUP_LOCK, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    except OSError:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    except OSError:
        return True
    finally:
        os.close(fd)


def osup_launch(job, kind, security=False):
    """The job started where it outlives this service: a transient unit of
    systemd's, or - with no systemd, and under the tests - a process of its
    own session."""
    if osup_running():
        raise Refused('an update or a look for updates is going on already')
    if not osup_tool('dnf'):
        raise Refused('dnf is not on this machine')
    argv = [sys.executable, '-I', os.path.abspath(__file__), '--os-job', job, kind] + \
        (['security'] if security else [])
    if not NO_SERVICES and shutil.which('systemd-run') and os.path.isdir('/run/systemd/system'):
        run(['systemd-run', '--unit', 'zigmon-os-%s-%s' % (kind, job[:12]), '--collect', '--quiet',
             '--property', 'TimeoutStopSec=30min'] + argv, 'systemd-run')
        how = 'a unit of its own'
    else:
        subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True, close_fds=True)
        how = 'a process of its own'
    # answered only once the job holds its lock: a second ask a moment after
    # is refused here, not started beside it to give up without a word
    end = time.time() + 15
    while not osup_running() and time.time() < end:
        time.sleep(0.05)
    return how


def osup_proxy_keep(r):
    """The proxy of the ask, kept for the job - or the file taken away."""
    url = r.get('proxy') or ''
    if not isinstance(url, str) or (url and not OSUP_PROXY_RE.match(url)):
        raise Refused('the proxy is not an http:// address')
    no = r.get('proxy_no') or ''
    if not isinstance(no, str):
        raise Refused('the names reached straight are not words')
    no = ','.join(w for w in re.split(r'[\s,;]+', re.sub(r'[^A-Za-z0-9.*:/\[\],;\s_-]', '', no))
                  if w)[:2000]
    if not url:
        try:
            os.unlink(OSUP_PROXY)
        except FileNotFoundError:
            pass
        return
    fd = os.open(OSUP_PROXY + '.new', os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w') as f:
        os.fchmod(f.fileno(), 0o600)
        f.write(json.dumps({'url': url, 'no': no}))
    os.replace(OSUP_PROXY + '.new', OSUP_PROXY)


def osup_proxy_env(env):
    """dnf's environment with the proxy kept for it (libcurl reads these);
    what may be said of it - host:port - or ''."""
    try:
        st = os.stat(OSUP_PROXY, follow_symlinks=False)
        if not stat.S_ISREG(st.st_mode) or st.st_mode & 0o077:
            return ''                                   # not root's alone: not believed
        with open(OSUP_PROXY) as f:
            got = json.loads(f.read(8192) or '{}')
    except (OSError, ValueError):
        return ''
    url = got.get('url') if isinstance(got, dict) else ''
    if not isinstance(url, str) or not OSUP_PROXY_RE.match(url):
        return ''
    for k in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY'):
        env[k] = url
    if got.get('no'):
        env['no_proxy'] = env['NO_PROXY'] = str(got['no'])
    return url.split('://', 1)[1].rsplit('@', 1)[-1].rstrip('/')


def osup_one(r):
    kind = r.get('kind')
    if r.get('do') != 'run' or kind not in OSUP_KINDS:
        raise Refused('run: check or upgrade')
    job = str(r.get('job') or '')
    if not OSUP_JOB_RE.match(job):
        raise Refused('the job has no id of the right shape')
    if 'security' in r and not isinstance(r['security'], bool):
        raise Refused('security is yes or no')
    security = r.get('security') is True and kind == 'upgrade'
    if osup_running():
        raise Refused('an update or a look for updates is going on already')
    osup_proxy_keep(r)
    how = osup_launch(job, kind, security)
    return {'started': kind, 'job': job, 'security': security, 'how': how}


def osup_part():
    ask_part(OSUP_ASK, OSUP_ANS, osup_one, 4096)


def reboot_for(packages):
    """Which of the packages waiting want a restart once updated."""
    out = []
    for p in packages:
        words = str(p).split()
        name = words[0] if words else ''
        if re.search(r'\.(x86_64|aarch64|noarch|i686|ppc64le|s390x)$', name):
            name = name.rsplit('.', 1)[0]
        if name in REBOOT_PKGS or name.startswith('kernel-core-'):
            out.append(name)
    return sorted(set(out))


def reboot_now(env, say=None):
    """Whether this machine waits for a restart already: needs-restarting -r
    says 1 when it does - the standalone one, or dnf's own."""
    cmd = [osup_tool('needs-restarting'), '-r'] if osup_tool('needs-restarting') else \
        [osup_tool('dnf'), 'needs-restarting', '-r']
    got = subprocess.run(cmd, capture_output=True, text=True, env=env, timeout=300,
                         stdin=subprocess.DEVNULL)
    if got.returncode == 1 and say:
        said = got.stdout.strip().splitlines()
        say(said[0] if said else 'a restart is needed')
    return got.returncode == 1


def osup_lock_take(wait=2.0):
    """The job's lock, or None when another job holds it. Tried for a
    moment (5.43.3): osup_running() takes the lock itself for an instant to
    see whether it is free, and osup_launch asks it every 50 ms while the job
    starts - a job that came to its lock in that instant gave up without a
    word, and the update asked for never ran."""
    import fcntl
    fd = os.open(OSUP_LOCK, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o600)
    end = time.time() + wait
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return fd
        except OSError:
            if time.time() >= end:
                os.close(fd)
                return None
            time.sleep(0.02)


def osup_job(job, kind, security=False):
    """The work itself, as root, in a process of its own: a look for what dnf
    has waiting, or the update."""
    fd = osup_lock_take()
    if fd is None:
        return 1
    state = {'id': job, 'kind': kind, 'state': 'running', 'pct': 1, 'lines': [], 'n': 0,
             'began': time.time(), 'at': time.time(), 'packages': [], 'reboot': False,
             'pm': 'dnf', 'phase': 'starting', 'security_only': bool(security)}
    whole = []
    last = [0.0]

    def put(force=False):
        state['at'] = time.time()
        if force or time.time() - last[0] > 0.8:
            last[0] = time.time()
            state['lines'] = state['lines'][-400:]
            del whole[:-5000]
            try:
                write_here(OSUP_FILE, json.dumps(state))
                write_here(OSUP_LOG[kind], '\n'.join(whole) + '\n')
            except OSError:
                pass

    def say(line):
        line = line.rstrip()
        if line:
            state['lines'].append(line[:300])
            whole.append(line[:300])
            state['n'] += 1
        put()

    env = {'PATH': OSUP_PATH, 'LANG': 'C', 'LC_ALL': 'C', 'HOME': '/root'}
    through = osup_proxy_env(env)

    def stream(cmd, on_line=None, ok=(0,)):
        say('$ ' + ' '.join([os.path.basename(cmd[0])] + cmd[1:]))
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                             stdin=subprocess.DEVNULL, text=True, bufsize=1, errors='replace')
        for ln in p.stdout:
            if on_line:
                on_line(ln)                         # the bar first: what is written has moved
            say(ln)
        rc = p.wait()
        if rc not in ok:
            raise Refused('%s ended with %d' % (os.path.basename(cmd[0]), rc))
        return rc

    dnf = osup_tool('dnf')
    try:
        if through:
            say('through the proxy %s (Control - Proxy)' % through)
        put(True)
        if not dnf:
            raise Refused('dnf is not on this machine')
        if kind == 'check':
            state['phase'] = 'asking for what is new'
            seen = []
            stream([dnf, '-q', '--refresh', 'check-update'], seen.append, ok=(0, 100))
            pk = []
            for ln in seen:
                parts = ln.split()
                if ln.startswith((' ', '\t')) or len(parts) < 3 or '.' not in parts[0] or \
                        parts[0].startswith(('Obsoleting', 'Security:', 'Last')):
                    continue
                pk.append('%s %s' % (parts[0], parts[1]))
            state['phase'] = 'which of them are security updates'
            sec = subprocess.run([dnf, '-q', 'updateinfo', 'list', '--security'],
                                 capture_output=True, text=True, env=env, timeout=600,
                                 stdin=subprocess.DEVNULL)
            names = set()
            for ln in sec.stdout.splitlines():
                parts = ln.split()
                if len(parts) >= 3 and not ln.startswith(' '):
                    names.add(parts[2])
            state['security'] = len(names) if sec.returncode == 0 else None
            state['packages'] = pk[:1000]
            state['count'] = len(pk)
            # whether the update will need a restart, told before it is made
            state['phase'] = 'whether a restart is needed'
            state['reboot_why'] = reboot_for(pk)
            state['reboot_after'] = bool(state['reboot_why'])
            try:
                state['reboot_now'] = reboot_now(env)
            except (OSError, subprocess.SubprocessError):
                state['reboot_now'] = False
            say('%d update(s) waiting, %s of them security' % (
                len(pk), '?' if state['security'] is None else state['security']))
            if state['reboot_now']:
                say('a restart is needed already, before any update')
            if state['reboot_why']:
                say('a restart will be needed after the update: %s' % ', '.join(state['reboot_why']))
            state['pct'] = 100
        else:
            seen = {'total': 0, 'done': 0}

            def count(ln):
                m = re.search(r'\b(\d+)/(\d+)\s*$', ln)
                if m and re.search(r'(Upgrading|Installing|Cleanup|Verifying|Running scriptlet|'
                                   r'Erasing|Reinstalling|Downgrading|Obsoleting)\s*:', ln):
                    seen['total'] = max(seen['total'], int(m.group(2)) * 2)  # put in, then verified
                    seen['done'] = min(seen['total'], seen['done'] + 1)
                    state['phase'] = 'putting the packages in'
                if ln.startswith('Downloading Packages'):
                    state['phase'] = 'downloading'
                    state['pct'] = max(state['pct'], 8)
                if seen['total']:
                    state['pct'] = max(state['pct'], min(97, 10 + int(87 * seen['done'] /
                                                                      seen['total'])))
            state['phase'] = 'asking for what is new'
            # only the security updates where asked (otp 1.0.164): dnf's own --security
            stream([dnf, '-y', '--refresh', 'upgrade'] + (['--security'] if security else []), count)
            state['phase'] = 'whether a restart is needed'
            try:
                state['reboot'] = reboot_now(env, say)
            except (OSError, subprocess.SubprocessError):
                state['reboot'] = False
            say('updated%s' % (' - a restart is needed' if state['reboot'] else
                               ', no restart needed'))
            state['pct'] = 100
        state['state'] = 'done'
        state['phase'] = 'done'
    except Refused as e:
        state.update(state='failed', said=str(e)[:300])
        say('failed: %s' % str(e)[:300])
    except Exception as e:                              # noqa: BLE001 - said, never lost
        state.update(state='failed', said='it broke: %s' % str(e)[:300])
        say('it broke: %s' % str(e)[:300])
    finally:
        state['ended'] = time.time()
        put(True)
        os.close(fd)
    return 0


# ---- the system's trusted roots (otp 1.0.265) -------------------------------------
# Certificate authorities of one's own - a company's root, an intermediate -
# put into the trust of the whole operating system: curl, dnf, LDAPS to a
# domain controller, mail, syslog over TLS and zigmon's own connections. Only
# by the system's own way of adding to it, never by touching the
# distribution's list:
#   RHEL / AlmaLinux / Rocky: /etc/pki/ca-trust/source/anchors/*.pem, then update-ca-trust extract
#   Debian / Ubuntu:          /usr/local/share/ca-certificates/*.crt, then update-ca-certificates
# Both tools merge that folder with the distribution's list every time they
# run - also when an update of the ca-certificates package runs them - so the
# distribution's list keeps coming with the system's updates and these stay
# beside it. zigmon's files are named zigmon-<first 16 hex of the SHA-256>.pem
# (.crt): only those are ever written or removed; anything else in the folder
# was put there by somebody else and is only shown, a link never followed.
# Asked in osroots.ask: what is there (list), what a text holds (check), the
# whole set wanted (sync). Every certificate is read by openssl here again -
# nothing of the request is trusted. The words are the daemon's (osr_facts).
OSROOTS_ASK = 'osroots.ask'
OSROOTS_FILE = 'osroots.json'
OSROOTS_MAX = 50                    # zigmon's certificates at most
OSROOTS_PEM_MAX = 16384             # one certificate, as PEM
OSROOTS_FILE_MAX = 1048576          # a file of somebody else's, read
OSROOTS_OTHERS_READ = 60            # others' files parsed (each one an openssl run)
OSROOTS_OTHERS_NAMED = 200
OSROOTS_NAME_RE = re.compile(r'^zigmon-[0-9a-f]{16}\.(pem|crt)\Z')
OSROOTS_BLOCK_RE = re.compile(r'-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]*?)-----END CERTIFICATE-----')
OSROOTS_FORBIDDEN_RE = re.compile(r'PRIVATE KEY|BEGIN ENCRYPTED|BEGIN PKCS7|BEGIN TRUSTED CERTIFICATE')
OSROOTS_FLAVOURS = {
    'rhel': {'dir': '/etc/pki/ca-trust/source/anchors', 'ext': '.pem',
             'tool': ['update-ca-trust', 'extract'],
             'bundle': '/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem',
             'pkg': ['rpm', '-q', 'ca-certificates']},
    'debian': {'dir': '/usr/local/share/ca-certificates', 'ext': '.crt',
               'tool': ['update-ca-certificates'],
               'bundle': '/etc/ssl/certs/ca-certificates.crt',
               'pkg': ['dpkg-query', '-W', '-f=ca-certificates ${Version}', 'ca-certificates']}}


def osroots_where():
    """Which way this system adds to its trust, or None. Each part can be
    pointed elsewhere for the checks - by the environment of the unit, which
    is root's alone (ZIGMON_OSROOTS_FLAVOUR, _DIR, _BUNDLE, _TOOL, _PKG)."""
    env = os.environ
    fl = env.get('ZIGMON_OSROOTS_FLAVOUR', '')
    if fl not in OSROOTS_FLAVOURS:
        fl = ''
        if os.path.isdir(FS_ROOT + '/etc/pki/ca-trust/source') or shutil.which('update-ca-trust'):
            fl = 'rhel'
        elif os.path.isdir(FS_ROOT + '/usr/local/share/ca-certificates') or \
                shutil.which('update-ca-certificates'):
            fl = 'debian'
    if not fl:
        return None
    w = dict(OSROOTS_FLAVOURS[fl], flavour=fl)
    w['dir'] = env.get('ZIGMON_OSROOTS_DIR') or (FS_ROOT + w['dir'])
    w['bundle'] = env.get('ZIGMON_OSROOTS_BUNDLE') or (FS_ROOT + w['bundle'])
    if env.get('ZIGMON_OSROOTS_TOOL'):
        w['tool'] = shlex.split(env['ZIGMON_OSROOTS_TOOL'])
    if 'ZIGMON_OSROOTS_PKG' in env:
        w['pkg'] = shlex.split(env['ZIGMON_OSROOTS_PKG'])
    return w


def osroots_blocks(text):
    """Each certificate of a text as (pem, der) - nothing but certificates: a
    private key, or a text with no certificate in it, refused whole."""
    text = str(text or '')
    if OSROOTS_FORBIDDEN_RE.search(text):
        raise Refused('no private key and nothing but certificates (-----BEGIN CERTIFICATE-----)')
    out = []
    for body in OSROOTS_BLOCK_RE.findall(text):
        try:
            der = base64.b64decode(re.sub(r'\s+', '', body), validate=True)
        except ValueError:
            raise Refused('a certificate that is not base64')
        if not der or len(der) > OSROOTS_PEM_MAX * 3 // 4:
            raise Refused('a certificate of %d bytes - one is a few kB at most' % len(der))
        enc = base64.b64encode(der).decode('ascii')
        out.append(('-----BEGIN CERTIFICATE-----\n%s\n-----END CERTIFICATE-----\n' % '\n'.join(
            enc[i:i + 64] for i in range(0, len(enc), 64)), der))
    if not out:
        raise Refused('no certificate in it (-----BEGIN CERTIFICATE-----)')
    return out


def _osroots_time(s):
    try:
        return calendar.timegm(time.strptime(re.sub(r'\s+', ' ', s.strip()), '%b %d %H:%M:%S %Y %Z'))
    except ValueError:
        return 0


def osroots_facts(pem, der):
    """What one certificate is, as openssl reads it - and what stands against
    it (`refused`) or is to be known (`warn`). The same words as the daemon's
    osr_facts."""
    txt = openssl(['x509', '-noout', '-text', '-nameopt', 'RFC2253'], 'not a certificate openssl reads',
                  data=pem)

    def one(rx):
        m = re.search(rx, txt, re.M)
        return m.group(1).strip() if m else ''
    f = {'fp': hashlib.sha256(der).hexdigest(), 'subject': one(r'^\s*Subject: ?(.*)$')[:400],
         'issuer': one(r'^\s*Issuer: ?(.*)$')[:400],
         'not_before': _osroots_time(one(r'Not Before\s*: (.*)$')),
         'not_after': _osroots_time(one(r'Not After\s*: (.*)$')),
         'sig': one(r'Signature Algorithm: (\S+)')[:60]}
    cn = re.search(r'(?:^|,)CN=((?:\\.|[^,])*)', f['subject'])
    f['cn'] = (cn.group(1) if cn else f['subject'])[:200]
    alg = one(r'Public Key Algorithm: (\S+)')
    bits = one(r'Public-Key: \((\d+) bit\)')
    curve = one(r'NIST CURVE: (\S+)') or one(r'ASN1 OID: (\S+)')
    f['key'] = ('RSA %s' % bits) if alg == 'rsaEncryption' else \
        ('EC %s' % (curve or bits)) if alg == 'id-ecPublicKey' else \
        (alg.replace('ED25519', 'Ed25519').replace('ED448', 'Ed448')[:40] if alg else '?')
    f['bits'] = int(bits) if bits.isdigit() else 0
    bc = re.search(r'X509v3 Basic Constraints:.*\n\s*(CA:(TRUE|FALSE))', txt)
    f['ca'] = bool(bc and bc.group(2) == 'TRUE')
    ku = re.search(r'X509v3 Key Usage:.*\n\s*(.*)', txt)
    f['ku_sign'] = None if not ku else ('Certificate Sign' in ku.group(1))
    f['root'] = f['subject'] == f['issuer']
    f['kind'] = 'root' if f['root'] else 'intermediate'
    refused, warn = [], []
    now = time.time()
    if not bc:
        refused.append('it says nothing of being an authority (no basicConstraints CA:TRUE) - '
                       'only a certificate authority goes here')
    elif not f['ca']:
        refused.append('it is not a certificate authority (CA:FALSE) - a server\'s own certificate '
                       'does not go here')
    if f['ku_sign'] is False:
        refused.append('its key usage does not let it sign certificates (no keyCertSign)')
    if f['not_after'] and f['not_after'] < now:
        warn.append('it ran out on %s - nothing it signed is trusted' % time.strftime(
            '%Y-%m-%d', time.gmtime(f['not_after'])))
    if f['not_before'] and f['not_before'] > now + 300:
        warn.append('it is valid only from %s' % time.strftime('%Y-%m-%d', time.gmtime(f['not_before'])))
    if not f['root'] and re.match(r'(?i)(sha1|md5|md2)', f['sig']):
        warn.append('it is signed with %s - the system\'s crypto policy (DEFAULT) refuses it, and '
                    'every chain through it' % f['sig'])
    if f['key'].startswith('RSA') and 0 < f['bits'] < 2048:
        warn.append('its key has %d bits - the system\'s crypto policy (DEFAULT) refuses fewer '
                    'than 2048' % f['bits'])
    f['refused'], f['warn'] = refused, warn
    return f


def osroots_dir_fd(d, make=False):
    """The folder of local additions, opened without following a link, and
    only when it is root's alone - or None where it is not there (made 0755
    only when something is to be written into it)."""
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    try:
        fd = os.open(d, flags)
    except FileNotFoundError:
        if not make:
            return None
        os.makedirs(d, 0o755, exist_ok=True)
        fd = os.open(d, flags)
    except OSError as e:
        if e.errno in (errno.ELOOP, errno.ENOTDIR):
            raise Refused('%s is not a folder (a link?) - nothing is written there' % d)
        raise
    st = os.fstat(fd)
    if st.st_uid != 0 or st.st_mode & 0o022:
        os.close(fd)
        raise Refused('%s is not root\'s alone (owner %d, mode %o) - nothing is written there'
                      % (d, st.st_uid, stat.S_IMODE(st.st_mode)))
    return fd


def _osroots_read_at(dir_fd, name, most):
    """A plain file's bytes - None for a link (never followed), a folder, a
    pipe; a file bigger than `most` is read no further than that."""
    try:
        fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=dir_fd)
    except OSError as e:
        if e.errno in (errno.ELOOP, errno.EISDIR, errno.ENXIO, errno.ENOENT):
            return None
        raise
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return None
        out, left = [], most
        while left > 0:
            got = os.read(fd, min(left, 65536))
            if not got:
                break
            out.append(got)
            left -= len(got)
        return b''.join(out)
    finally:
        os.close(fd)


def osroots_scan(dfd):
    """[(relative name, link target or None, dir_fd, name)] of the folder, one
    level of subfolders too (Debian reads them) - a link to a folder is not
    gone into. The subfolders' descriptors come back to be closed."""
    out, subs = [], []
    try:
        top = sorted(os.listdir(dfd))
    except OSError:
        return out, subs
    for n in top[:500]:
        try:
            st = os.lstat(n, dir_fd=dfd)
        except OSError:
            continue
        if stat.S_ISLNK(st.st_mode):
            try:
                to = os.readlink(n, dir_fd=dfd)[:300]
            except OSError:
                to = '?'
            out.append((n, to, dfd, n))
        elif stat.S_ISDIR(st.st_mode):
            try:
                sfd = os.open(n, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=dfd)
            except OSError:
                continue
            subs.append(sfd)
            try:
                inner = sorted(os.listdir(sfd))[:200]
            except OSError:
                inner = []
            for m in inner:
                try:
                    lnk = os.readlink(m, dir_fd=sfd)[:300]
                except OSError:
                    lnk = None
                out.append((n + '/' + m, lnk, sfd, m))
        else:
            out.append((n, None, dfd, n))
    return out, subs


def osroots_cert_of(raw):
    """The certificates of a file somebody else put there - PEM or DER - with
    their facts; [] when none reads."""
    text = raw.decode('ascii', 'replace')
    if '-----BEGIN CERTIFICATE-----' not in text:
        got = subprocess.run(['openssl', 'x509', '-inform', 'DER'], input=raw, capture_output=True,
                             timeout=30)
        if got.returncode != 0:
            return []
        text = got.stdout.decode('ascii', 'replace')
    try:
        blocks = osroots_blocks('\n'.join(m.group(0) for m in OSROOTS_BLOCK_RE.finditer(text)))
    except Refused:
        return []
    out = []
    for pem, der in blocks[:20]:
        try:
            f = osroots_facts(pem, der)
        except Refused:
            continue
        out.append({k: f[k] for k in ('fp', 'cn', 'subject', 'issuer', 'not_before', 'not_after',
                                      'key', 'kind', 'ca')})
    return out


def _osroots_bundle_bytes(w):
    """The system's list as its tool made it last - read as a plain file, a
    link in its place not followed."""
    d, name = os.path.split(w['bundle'])
    try:
        dfd = os.open(d or '/', os.O_RDONLY | os.O_DIRECTORY)
    except OSError:
        return None
    try:
        return _osroots_read_at(dfd, name, 64 * 1048576)
    finally:
        os.close(dfd)


def osroots_bundle(w, raw=None):
    """How many the system's own list holds, how large, when it was made -
    and the package that brings it, so it is seen the system's updates keep
    it coming."""
    out = {'path': w['bundle'], 'count': 0, 'bytes': 0, 'at': 0}
    raw = _osroots_bundle_bytes(w) if raw is None else raw
    if raw is None:
        out['missing'] = True
    else:
        out['count'] = raw.count(b'-----BEGIN CERTIFICATE-----')
        out['bytes'] = len(raw)
        try:
            out['at'] = os.stat(w['bundle'], follow_symlinks=False).st_mtime
        except OSError:
            pass
    pkg = ''
    if w.get('pkg'):
        try:
            got = subprocess.run(w['pkg'], capture_output=True, text=True, timeout=30)
            if got.returncode == 0 and got.stdout.strip():
                pkg = got.stdout.strip().splitlines()[0][:120]
        except (OSError, subprocess.SubprocessError):
            pkg = ''
    out['package'] = pkg
    return out


def osroots_in_bundle(raw, ders):
    """Which of these the tool put into the system's list: each one's base64
    found in it."""
    if raw is None:
        return {}
    flat = re.sub(rb'\s+', b'', raw)
    return {hashlib.sha256(x).hexdigest(): base64.b64encode(x) in flat for x in ders}


def osroots_read(w):
    """zigmon's own files, the others', the system's list."""
    ours, others = [], []
    dfd = None
    if w:
        try:
            dfd = osroots_dir_fd(w['dir'])
        except Refused:
            dfd = None
    subs = []
    try:
        entries, subs = osroots_scan(dfd) if dfd is not None else ([], [])
        parsed = 0
        for rel, lnk, pfd, name in entries:
            if OSROOTS_NAME_RE.match(rel) and lnk is None:
                raw = _osroots_read_at(pfd, name, OSROOTS_PEM_MAX * 2)
                try:
                    (pem, der), = osroots_blocks((raw or b'').decode('ascii', 'replace'))
                    f = osroots_facts(pem, der)
                    f.pop('refused', None)
                    f.update(file=rel, der=der)
                    ours.append(f)
                except (Refused, ValueError):
                    ours.append({'file': rel, 'broken': True})
                continue
            if len(others) >= OSROOTS_OTHERS_NAMED:
                continue
            if lnk is not None:
                others.append({'file': rel, 'link': lnk, 'certs': []})
                continue
            certs = []
            if parsed < OSROOTS_OTHERS_READ:
                raw = _osroots_read_at(pfd, name, OSROOTS_FILE_MAX)
                if raw:
                    parsed += 1
                    try:
                        certs = osroots_cert_of(raw)
                    except (OSError, subprocess.SubprocessError):
                        certs = []
            others.append({'file': rel, 'certs': certs})
    finally:
        for fd in subs:
            os.close(fd)
        if dfd is not None:
            os.close(dfd)
    raw = _osroots_bundle_bytes(w) if w else None
    inb = osroots_in_bundle(raw, [f['der'] for f in ours if f.get('der')])
    for f in ours:
        f.pop('der', None)
        if f.get('fp'):
            f['in_bundle'] = inb.get(f['fp'], False)
    return {'ours': ours, 'others': others, 'system': osroots_bundle(w, raw) if w else {},
            'flavour': (w or {}).get('flavour', ''), 'dir': (w or {}).get('dir', ''),
            'tool': ' '.join((w or {}).get('tool') or []),
            'tool_there': bool(w and shutil.which(w['tool'][0]))}


def osroots_selinux():
    if os.environ.get('ZIGMON_OSROOTS_SELINUX') == '1':
        return True
    return not NO_SERVICES and os.path.exists('/sys/fs/selinux/enforce')


def _osroots_put(dfd, name, pem):
    """Written beside it under a name of its own - root's, 0644 - and renamed
    into place in the same folder."""
    for n in range(50):
        tmp = '.zigmon-osroot.%d.%d' % (os.getpid(), n)
        try:
            fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=dfd)
        except FileExistsError:
            continue
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(pem.encode('ascii'))
                f.flush()
                os.fchmod(f.fileno(), 0o644)
                os.fchown(f.fileno(), 0, 0)
            os.replace(tmp, name, src_dir_fd=dfd, dst_dir_fd=dfd)
        except BaseException:
            try:
                os.unlink(tmp, dir_fd=dfd)
            except OSError:
                pass
            raise
        return
    raise OSError('could not write %s' % name)


def osroots_sync(w, certs, force=False):
    """The folder brought to hold exactly zigmon's certificates wanted - the
    others' left as they are - and the system's tool run when anything
    changed. (said, refused [{fp, cn, why}])."""
    if not w:
        raise Refused('this system has neither update-ca-trust (RHEL, AlmaLinux, Rocky) nor '
                      'update-ca-certificates (Debian, Ubuntu)')
    if not isinstance(certs, list) or len(certs) > OSROOTS_MAX:
        raise Refused('the certificates wanted: a list of %d at most' % OSROOTS_MAX)
    want, refused = {}, []
    for c in certs:
        if not isinstance(c, str) or len(c) > OSROOTS_PEM_MAX:
            raise Refused('each certificate as PEM text of %d bytes at most' % OSROOTS_PEM_MAX)
        blocks = osroots_blocks(c)
        if len(blocks) != 1:
            raise Refused('one certificate in each')
        pem, der = blocks[0]
        f = osroots_facts(pem, der)
        if f['refused']:
            refused.append({'fp': f['fp'], 'cn': f['cn'], 'why': '; '.join(f['refused'])})
            continue
        want['zigmon-%s%s' % (f['fp'][:16], w['ext'])] = pem
    dfd = osroots_dir_fd(w['dir'], make=bool(want))
    said, changed = [], False
    if dfd is not None:
        try:
            have = {}
            for n in os.listdir(dfd):
                if OSROOTS_NAME_RE.match(n):
                    have[n] = os.lstat(n, dir_fd=dfd)
            for name, pem in sorted(want.items()):
                st = have.get(name)
                if st is not None:
                    if stat.S_ISREG(st.st_mode):
                        raw = _osroots_read_at(dfd, name, OSROOTS_PEM_MAX * 2)
                        if raw is not None and raw == pem.encode('ascii'):
                            continue
                    # changed by somebody, or a link: put back as it is wanted
                    if stat.S_ISDIR(st.st_mode):
                        raise Refused('%s/%s is a folder - nothing is written over it' % (w['dir'], name))
                    os.unlink(name, dir_fd=dfd)
                _osroots_put(dfd, name, pem)
                said.append('added %s' % name)
                changed = True
                if osroots_selinux():
                    # the anchors folder is cert_t: the new file labelled as the folder wants
                    subprocess.run([os.environ.get('ZIGMON_OSROOTS_RESTORECON') or 'restorecon', '-F',
                                    os.path.join(w['dir'], name)], capture_output=True)
            for name, st in sorted(have.items()):
                if name not in want and not stat.S_ISDIR(st.st_mode):
                    os.unlink(name, dir_fd=dfd)
                    said.append('removed %s' % name)
                    changed = True
        finally:
            os.close(dfd)
    if changed or force:
        if not shutil.which(w['tool'][0]):
            raise Refused('%s is not on this machine - the files are in %s, the system\'s list is '
                          'not made again until it runs' % (w['tool'][0], w['dir']))
        got = subprocess.run(w['tool'], capture_output=True, text=True, timeout=300)
        if got.returncode != 0:
            raise Refused('%s ended with %d: %s' % (' '.join(w['tool']), got.returncode,
                                                    ((got.stderr or got.stdout).strip() or '-')[-300:]))
        said.append('%s run' % ' '.join(w['tool']))
    return said, refused


def osroots_one(r):
    w = osroots_where()
    do = r.get('do')
    if do == 'list':
        return dict(osroots_read(w), said=[], refused=[], not_in_bundle=[])
    if do == 'check':
        # a text read for the pages: what each certificate in it is - nothing written
        text = r.get('text')
        if not isinstance(text, str) or len(text) > OSROOTS_MAX * OSROOTS_PEM_MAX:
            raise Refused('the certificates as PEM text')
        return {'certs': [dict(osroots_facts(pem, der), pem=pem)
                          for pem, der in osroots_blocks(text)[:OSROOTS_MAX + 1]]}
    if do == 'sync':
        said, refused = osroots_sync(w, r.get('certs'), r.get('force') is True)
        got = osroots_read(w)
        # each of ours wanted, looked for in the list the tool made
        missing = [f['fp'] for f in got['ours'] if f.get('fp') and not f.get('in_bundle')]
        return dict(got, said=said, refused=refused, not_in_bundle=missing)
    raise Refused('list, check or sync')


def osroots_part():
    ask_part(OSROOTS_ASK, OSROOTS_FILE, osroots_one, most=OSROOTS_MAX * OSROOTS_PEM_MAX * 2 + 65536)


# ---- SELinux (otp 1.0.233 - 1.0.265) ----------------------------------------------------
# Asked in selinux.ask, answered in selinux.json: how SELinux is on this machine (check), the
# way to enforcing a step at a time - made ready and permissive from disabled, what zigmon
# needs put in (prepare), enforcing, permissive again - and a report for whoever writes
# zigmon's module. Nothing changes unless one of those is asked: disabled stays disabled.
#
#   absent (no getenforce: Debian, Ubuntu) - nothing to do
#   Disabled --prepare--> SELINUX=permissive, /.autorelabel, selinux=0 off the kernel's
#                         command line, the module tried (the machine is NOT restarted)
#   Permissive --prepare--> the module, the labels, the booleans, the ports; "applied at"
#              --enforce--> the same again, checked, refused while anything is missing or
#                           was refused; setenforce 1 and SELINUX=enforcing
#   Enforcing --permissive--> setenforce 0 and SELINUX=permissive
#
# The daemon says what this configuration needs (booleans, ports); every word of it is
# checked here against what may be set - an allow-list of booleans and of port types - and
# what nginx listens on is read here, from nginx's own file, not taken from the daemon.
SELINUX_ASK = 'selinux.ask'
SELINUX_FILE = 'selinux.json'
SE_CONFIG = os.environ.get('ZIGMON_SELINUX_CONFIG', '/etc/selinux/config')
SE_RELABEL = os.environ.get('ZIGMON_SELINUX_RELABEL', '/.autorelabel')
SE_CMDLINE = os.environ.get('ZIGMON_SELINUX_CMDLINE', '/proc/cmdline')
SE_CIL = os.environ.get('ZIGMON_SELINUX_CIL', '/usr/local/lib/zigmon/zigmon_server.cil')
SE_RUN = os.environ.get('ZIGMON_SELINUX_RUN', '/run/zigmon')
SE_WEB = os.environ.get('ZIGMON_SELINUX_WEB', '/var/www/zigmon')
# tests: a folder holding getenforce, semanage, semodule, ausearch ... - looked in alone
SE_BIN = os.environ.get('ZIGMON_SELINUX_BIN', '')
SE_MODULE = 'zigmon_server'
SE_APPLIED = 'selinux-applied'      # when zigmon's needs were last put in: root's own folder
SE_REPORT_FILE = 'selinux-report.tar.gz'
SE_REPORT_MOST = 2 * 1024 * 1024    # each part of the report at most, before it is packed
# What zigmon's files should be labelled (the third field of the context), and why.
SE_LABELS = ((SE_RUN, 'httpd_var_run_t', 'the folder of the API token'),
             (SE_RUN + '/api-token', 'httpd_var_run_t', 'the API token the pages read'),
             (SE_WEB, 'httpd_sys_content_t', 'the pages'))
# What may be switched on, and the port types that may be given - nothing else, whatever
# the request says. The pages ask the daemon on 127.0.0.1:9849; nginx on a port of its own.
SE_BOOLEANS = ('httpd_can_network_connect',)
SE_PORT_TYPES = ('http_port_t',)
# The TCP ports a type nginx may bind already has (http_port_t, http_cache_port_t): a port
# of either is never asked for, and is no problem.
SE_HTTPD_TYPES = ('http_port_t', 'http_cache_port_t')
# The programs whose refusals are zigmon's business: the web server and php-fpm, systemd
# (its RuntimeDirectory), logrotate (the HUP), chronyd (the time servers set from the pages),
# the journal, and zigmon itself (unconfined, but what touches its files says its name).
SE_DOMAINS = ('httpd_t', 'init_t', 'logrotate_t', 'chronyd_t', 'syslogd_t', 'unconfined_service_t',
              'system_cronjob_t')


class SeRefused(Refused):
    pass


def se_tool(name):
    if SE_BIN:
        p = os.path.join(SE_BIN, name)
        return p if os.access(p, os.X_OK) else None
    return shutil.which(name)


def se_run(cmd, timeout=120, light=False, data=None):
    """A tool of SELinux's, or None when it is not on this machine. `light`: the heavy ones
    (semanage loads the whole policy, ausearch reads the audit log since the start) at the
    lowest priority - looked at every half hour beside the house's own work."""
    exe = se_tool(cmd[0])
    if not exe:
        return None
    cmd = [exe] + list(cmd[1:])
    if light:
        # (5.56.2) best effort at its lowest, not idle: the idle class gets
        # the disk only when nobody else wants it, and on a slow disk kept
        # busy (a man-db rebuild after an update, an integrity check) that
        # was never - semodule -l alone outlasted the daemon's three minutes
        if shutil.which('ionice'):
            cmd = [shutil.which('ionice'), '-c', '2', '-n', '7'] + cmd
        if shutil.which('nice'):
            cmd = [shutil.which('nice'), '-n', '19'] + cmd
    try:
        return subprocess.run(cmd, input=data, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None


def se_said(got):
    return ((got.stderr or got.stdout or '') if got is not None else 'not on this machine').strip()[-200:]


def se_read(path):
    try:
        with open(path, errors='replace') as f:
            return f.read(1 << 20)
    except OSError:
        return None


def se_applied_at():
    """When zigmon's needs were last put in - in root's own folder: in the service's, a time
    ahead written there would have hidden every refusal from the check before enforcing."""
    got = own_read(SE_APPLIED)
    try:
        return float((got or {}).get('at') or 0)
    except (TypeError, ValueError, AttributeError):
        return 0.0


def se_auditd():
    """Whether what SELinux refuses is written down at all: auditd running."""
    fake = os.environ.get('ZIGMON_SELINUX_AUDITD')
    if fake:
        return fake == 'active'
    if NO_SERVICES:
        return True
    got = service('is-active', 'auditd')
    return (got.stdout or '').strip() == 'active'


def se_mode():
    got = se_run(['getenforce'], 20)
    if got is None:
        return 'absent'
    m = (got.stdout or '').strip()
    return m if m in ('Enforcing', 'Permissive', 'Disabled') else 'Disabled'


def se_config():
    text = se_read(SE_CONFIG) or ''
    out = {}
    for line in text.splitlines():
        m = re.match(r'^\s*(SELINUX|SELINUXTYPE)\s*=\s*([A-Za-z0-9_-]+)\s*$', line)
        if m:
            out[m.group(1)] = m.group(2)
    return {'mode': out.get('SELINUX', ''), 'type': out.get('SELINUXTYPE', ''), 'there': bool(text)}


def se_config_set(mode):
    """SELINUX= in /etc/selinux/config, the rest of the file as it is."""
    if mode not in ('permissive', 'enforcing'):
        raise SeRefused('permissive or enforcing')
    text = se_read(SE_CONFIG)
    if text is None:
        raise SeRefused('%s is not there - is the SELinux policy installed? '
                        '(dnf install selinux-policy-targeted)' % SE_CONFIG)
    if re.search(r'(?m)^\s*SELINUX\s*=', text):
        new = re.sub(r'(?m)^(\s*)SELINUX\s*=.*$', r'\g<1>SELINUX=%s' % mode, text)
    else:
        new = text.rstrip('\n') + '\nSELINUX=%s\n' % mode
    if new != text:
        write_root(SE_CONFIG, new, 0o644)


def se_cmdline_off():
    """selinux=0 on the kernel's command line: the configuration alone does not switch it on."""
    return bool(re.search(r'(?:^|\s)selinux=0(?:\s|$)', se_read(SE_CMDLINE) or ''))


def se_label(path):
    fake = os.environ.get('ZIGMON_SELINUX_LABELS')         # tests: {path: label}
    if fake:
        try:
            with open(fake) as f:
                return (json.load(f) or {}).get(path)
        except (OSError, ValueError, AttributeError):
            return None
    try:
        raw = os.getxattr(path, 'security.selinux', follow_symlinks=False)
    except (OSError, AttributeError):
        return None
    parts = raw.decode('utf-8', 'replace').rstrip('\0').split(':')
    return parts[2] if len(parts) >= 3 else None


def se_label_ok(got, want):
    # newer policies call the run files' types *_runtime_t (the old name an alias)
    return got in (want, want.replace('_var_run_t', '_runtime_t'))


def se_module_in():
    got = se_run(['semodule', '-l'], 120, light=True)
    if got is None or got.returncode != 0:
        return None
    return any(line.split()[:1] == [SE_MODULE] for line in got.stdout.splitlines())


def se_bool(name):
    got = se_run(['getsebool', name], 20)
    if got is None or got.returncode != 0:
        return None
    return bool(re.search(r'-->\s*on\s*$', got.stdout.strip()))


def se_ports():
    """semanage port -l: {(type, proto): [(lo, hi), ...]}; None without semanage."""
    got = se_run(['semanage', 'port', '-l'], 120, light=True)
    if got is None or got.returncode != 0:
        return None
    out = {}
    for line in got.stdout.splitlines():
        m = re.match(r'^(\S+_port_t)\s+(tcp|udp|sctp|dccp)\s+(.+)$', line.strip())
        if not m:
            continue
        for p in m.group(3).split(','):
            a, _, b = p.strip().partition('-')
            try:
                out.setdefault((m.group(1), m.group(2)), []).append((int(a), int(b or a)))
            except ValueError:
                continue
    return out


def se_port_has(ports, kind, proto, port):
    kinds = SE_HTTPD_TYPES if kind == 'http_port_t' else (kind,)
    return any(lo <= port <= hi for k in kinds for lo, hi in (ports or {}).get((k, proto), []))


def se_nginx_ports():
    """The ports nginx listens on for the pages, read from its own file here: one that is not
    a port nginx may bind keeps nginx from starting under enforcing. 80 and 443 are always."""
    text = se_read(nginx_conf()) or ''
    seen = []
    for line in text.splitlines():
        line = line.split('#', 1)[0]
        m = re.match(r'^\s*listen\s+([^;\s]+)', line)
        if not m or m.group(1).startswith('unix:'):
            continue
        p = re.search(r'(?:^|:)(\d{1,5})$', m.group(1))
        if not p:
            continue
        n = int(p.group(1))
        if 1 <= n <= 65535 and n not in (80, 443) and n not in seen:
            seen.append(n)
    return [{'port': n, 'proto': 'tcp', 'type': 'http_port_t', 'why': 'nginx serves the pages on it'}
            for n in seen[:8]]


def se_denials(since=0.0, text=None, skip=None):
    """What SELinux refused since the machine started - or since zigmon's needs were last put
    in (what was refused before that is what they put right) - for the programs zigmon works
    with, grouped by what was refused, the most first; and those the policy loaded now allows
    (audit2why: a newer module, a boolean switched on since) told apart, not counted.
    `text`: what ausearch said, read once for this and the findings (5.55); `skip`: the
    refusals put right on the card since, by event - they no longer count here either."""
    if text is None:
        got = se_run(['ausearch', '-m', 'AVC,USER_AVC', '-ts', 'boot'], 120, light=True)
        if got is None:
            return {'tool': False, 'total': 0, 'groups': [], 'since': since, 'settled': 0}
        text = got.stdout or ''
    groups, lines, total = {}, {}, 0
    for line in text.splitlines():
        if 'avc:' not in line or 'denied' not in line:
            continue
        when = re.search(r'msg=audit\((\d+)(?:\.\d+)?:', line)
        if since and when and int(when.group(1)) < since:
            continue
        if skip:
            m0, p0 = SE_AUDIT_ID.search(line), SE_PERMS_RE.search(line)
            c0 = re.search(r'tclass=([a-z0-9_]+)', line)
            if m0 and p0 and c0 and (m0.group(1) + ':' + m0.group(2), ' '.join(sorted(set(p0.group(1).split()))),
                                     c0.group(1)) in skip:
                continue
        perms = re.search(r'denied\s+\{([^}]*)\}', line)
        sc = re.search(r'scontext=(\S+)', line)
        tc = re.search(r'tcontext=(\S+)', line)
        cl = re.search(r'tclass=(\S+)', line)
        if not (perms and sc and tc and cl):
            continue
        st = (sc.group(1).split(':') + ['', '', ''])[2]
        tt = (tc.group(1).split(':') + ['', '', ''])[2]
        if st not in SE_DOMAINS and 'zigmon' not in line:
            continue
        comm = re.search(r'\bcomm=(\S+)', line)
        name = re.search(r'\bname=(\S+)', line)
        # a name with a space in it is written in hex: the words as the program has them (5.55)
        what = ' '.join(x for x in (se_field('comm', comm.group(1)) if comm else '',
                                    se_field('name', name.group(1)) if name else '') if x)
        total += 1
        key = (st, tt, cl.group(1), perms.group(1).strip())
        lines[key] = line
        g = groups.setdefault(key, {'source': st, 'target': tt, 'class': cl.group(1),
                                    'perms': perms.group(1).strip(), 'count': 0, 'what': ''})
        g['count'] += 1
        g['what'] = re.sub(r'[^\w./@:+-]+', ' ', what)[:120].strip() or g['what']
    settled = 0
    for key in se_allowed_now(lines):
        settled += groups[key]['count']
        total -= groups.pop(key)['count']
    out = sorted(groups.values(), key=lambda g: -g['count'])[:30]
    return {'tool': True, 'total': total, 'groups': out, 'since': since, 'settled': settled}


def se_allowed_now(lines):
    """Which kinds of refusal (one line of each) the policy loaded now allows, as audit2why
    says: "would be allowed by active policy". None when it is not there or says nothing."""
    by_id = {}
    for key, line in lines.items():
        m = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
        if m:
            by_id[m.group(1)] = key
    if not by_id:
        return []
    got = se_run(['audit2why'], 300, light=True, data=''.join(lines[k] + '\n' for k in by_id.values()))
    if got is None or got.returncode != 0:
        return []
    now, cur = set(), None
    for line in (got.stdout or '').splitlines():
        m = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
        if m and 'avc:' in line:
            cur = by_id.get(m.group(1))
            continue
        if cur is not None and 'would be allowed by active policy' in line:
            now.add(cur)
    return sorted(now)


def se_want_checked(r, left_out):
    """What the daemon says zigmon needs here, checked against what may be set: a boolean of
    another name refuses the request; a port of a type this helper does not set (a newer
    daemon, an older helper, in the middle of an upgrade) is left out with a word, so that the
    booleans and the other ports still go in. nginx's ports are read here, last."""
    bools = []
    for b in (r.get('booleans') or [])[:8]:
        if not isinstance(b, dict) or b.get('name') not in SE_BOOLEANS:
            raise SeRefused('a boolean zigmon does not set')
        bools.append({'name': b['name'], 'why': str(b.get('why') or '')[:120]})
    ports = []
    for p in (r.get('ports') or [])[:16]:
        if not isinstance(p, dict) or p.get('proto') not in ('tcp', 'udp'):
            raise SeRefused('a port is tcp or udp')
        if p.get('type') not in SE_PORT_TYPES:
            if re.match(r'^[a-z][a-z0-9_]{0,40}_port_t\Z', str(p.get('type') or '')):
                left_out.append('port %s/%s left out: this helper does not set %s - install.sh of the '
                                'daemon\'s version puts in one that does'
                                % (str(p.get('port'))[:6], p['proto'], p['type']))
                continue
            raise SeRefused('a port type zigmon does not set')
        try:
            n = int(p.get('port'))
        except (TypeError, ValueError):
            raise SeRefused('a port is a number')
        if isinstance(p.get('port'), bool) or not 1 <= n <= 65535:
            raise SeRefused('a port is 1 to 65535')
        ports.append({'port': n, 'proto': p['proto'], 'type': p['type'], 'why': str(p.get('why') or '')[:120]})
    for p in se_nginx_ports():
        if not any(x['port'] == p['port'] and x['proto'] == 'tcp' for x in ports):
            ports.append(p)
    return bools, ports


def se_check(r):
    left = []
    bools, ports = se_want_checked(r, left)
    mode = se_mode()
    conf = se_config()
    out = {'mode': mode, 'config': conf['mode'], 'policy': conf['type'],
           'relabel_pending': os.path.exists(SE_RELABEL), 'cmdline_off': se_cmdline_off(),
           'tools': {t: bool(se_tool(t)) for t in ('semanage', 'semodule', 'ausearch', 'audit2why')},
           'module': None, 'labels': [], 'booleans': [], 'ports': [],
           'denials': {'tool': False, 'total': 0, 'groups': [], 'since': 0, 'settled': 0},
           'problems': [], 'left_out': left}
    if mode == 'absent':
        out['ready'] = False
        return out
    on = mode in ('Enforcing', 'Permissive')
    out['module'] = se_module_in()
    for path, want, why in SE_LABELS:
        if not os.path.exists(path):
            continue
        got = se_label(path) if on else None
        out['labels'].append({'path': path, 'label': got, 'want': want, 'why': why,
                              'ok': se_label_ok(got, want) if on else None})
    for b in bools:
        out['booleans'].append(dict(b, on=se_bool(b['name']) if on else None))
    known = se_ports() if on else None
    for p in ports:
        out['ports'].append(dict(p, labelled=(se_port_has(known, p['type'], p['proto'], p['port'])
                                             if known is not None else None)))
    probs = out['problems']
    if on:
        # what SELinux refused, read once (5.55): counted as before, and every refusal of the
        # whole machine sorted by what puts it right - the findings
        got = se_run(['ausearch', '-m', 'AVC,USER_AVC,SELINUX_ERR,USER_SELINUX_ERR', '-ts', 'boot'], 300,
                     light=True)
        groups = se_findings(got.stdout or '', se_fixed_read(), known) if got is not None else None
        if got is None:
            out['denials'] = {'tool': False, 'total': 0, 'groups': [], 'since': se_applied_at(), 'settled': 0}
        else:
            skip = {(e, ' '.join(g['perms']), g['class']) for g in groups if g.get('put_right') for e in g['evs']}
            out['denials'] = se_denials(se_applied_at(), got.stdout or '', skip)
        out['auditd'] = se_auditd()
        se_look_into(out, groups)
        if out['module'] is False:
            probs.append('zigmon\'s module (%s) is not installed' % SE_MODULE)
        probs.extend('%s is labelled %s, not %s (%s)' % (x['path'], x['label'] or '?', x['want'], x['why'])
                     for x in out['labels'] if x['ok'] is False)
        probs.extend('the boolean %s is off (%s)' % (x['name'], x['why'])
                     for x in out['booleans'] if x['on'] is False)
        probs.extend('port %d/%s is not labelled %s (%s)' % (x['port'], x['proto'], x['type'], x['why'])
                     for x in out['ports'] if x['labelled'] is False)
        if known is None and ports:
            probs.append('semanage is not on this machine - the ports cannot be checked '
                         '(dnf install policycoreutils-python-utils)')
        d = out['denials']
        if d['total']:
            probs.append(('SELinux refused %d thing(s) since zigmon\'s needs were put in' if d.get('since')
                          else 'SELinux refused %d thing(s) since the machine started') % d['total'])
        if not out['auditd']:
            # nothing written down, nothing counted: enforcing let through on no word
            probs.append('auditd does not run - what SELinux refuses is not written down '
                         '(systemctl enable --now auditd)')
        if not d['tool']:
            probs.append('ausearch is not on this machine - what SELinux refused cannot be read '
                         '(dnf install audit)')
        n = out.get('counts') or {}
        if n.get('fixable'):
            probs.append('%d thing(s) SELinux refused can be put right here (Settings - Security - SELinux, '
                         'or zigmon --selinux-fix --all)' % n['fixable'])
        if n.get('notbutton'):
            probs.append('%d thing(s) SELinux refused are not for a button - each says why '
                         '(zigmon --selinux-look)' % n['notbutton'])
    out['ready'] = mode == 'Permissive' and not probs
    return out


# ---- What SELinux refuses, sorted by what puts it right (5.55, after fake-igd's kit) -----
# Every AVC, USER_AVC and SELINUX_ERR since the machine started, read with the records of its
# event (SYSCALL: the program; PATH: the whole path; the port), grouped by what was refused,
# each group put to audit2why and sorted into one kind:
#
#   allowed   the policy loaded now allows it (a boolean since, a label since): not counted
#   fixed     put right here a moment ago, nothing refused of it since: not counted
#   boolean   audit2why names a boolean - the program's own (httpd_* for httpd_t) or one of
#             SE_BOOLEANS, and never one that allows far more (SE_BOOL_DANGER, which wins
#             over every list): setsebool -P NAME 1
#   label     a file of zigmon's not labelled as matchpathcon says: restorecon -R -v PATH,
#             only ever on zigmon's own places
#   port      a program zigmon works with binding a port of no type of its own:
#             semanage port -a -t TYPE (http/ssh/ntp/howl_port_t only), never another's port
#   rule      nothing of the policy allows it, and exactly that is safe to allow: one rule in
#             zigmon's own local module (zigmon_local), each in an optional block of its own
#   notbutton zigmon's, but too much to allow from a page - shown with why, never put right
#   other     another program of this machine - shown, never put right here
#
# A finding's id is a hash of what was refused (12 hex): the same refusal has the same id at
# every look. The page sends only ids; every fix is worked out here again from the audit log,
# never taken from a request.
SE_LIB = os.environ.get('ZIGMON_SELINUX_LIB', '/usr/local/lib/zigmon')
SE_LOCAL = 'zigmon_local'
SE_LOCAL_SUB = 'selinux-local'          # in root's own folder: the list, the module, its copy
SE_FIXED = 'selinux-fixed'              # what was put right on the card, and when
SE_FIXED_SHOW_S = 900                   # "put right just now" shown this long, then gone
SE_FIND_MOST = 200
SE_ID_RE = re.compile(r'^[0-9a-f]{12}\Z')
SE_TYPE_RE = re.compile(r'^[a-z][a-z0-9_]{0,62}_t\Z')
SE_WORD_RE = re.compile(r'^[a-z][a-z0-9_]{0,40}\Z')
SE_BOOL_RE = re.compile(r'^[a-z][a-z0-9_]{1,62}\Z')
SE_KINDS = ('fixed', 'boolean', 'label', 'port', 'rule', 'notbutton', 'other', 'allowed')
SE_FIXABLE = ('boolean', 'label', 'port', 'rule')
# the domains of the tools zigmon's daemon runs (zigmon_server.cil lets them be entered from
# its NoNewPrivileges unit): a refusal between one of them and the daemon is zigmon's
SE_TOOL_DOMAINS = ('chronyc_t', 'ssh_t', 'ssh_keygen_t', 'iptables_t')
# the confined services zigmon works with: theirs only on zigmon's paths and ports
SE_PARTNERS = ('httpd_t', 'init_t', 'logrotate_t', 'chronyd_t', 'syslogd_t', 'system_cronjob_t',
               'systemd_tmpfiles_t', 'sshd_t', 'avahi_t', 'mosquitto_t', 'unconfined_service_t')
# a port of no type of its own given the type of the program that binds it - only these
SE_PORT_FIX = {'httpd_t': 'http_port_t', 'sshd_t': 'ssh_port_t', 'chronyd_t': 'ntp_port_t',
               'avahi_t': 'howl_port_t'}
SE_PORT_GENERIC = ('unreserved_port_t', 'reserved_port_t', 'hi_reserved_port_t', 'ephemeral_port_t', 'port_t')
# never switched on from a page: a boolean that lets a program far more than one thing
SE_BOOL_DANGER = re.compile(r'exec|unconfined|_manage_all|_read_all|_write_all|_all_|ptrace|^deny_|^secure_|'
                            r'^selinuxuser_|unified|full_access|sys_admin|sysadm|secadm|auditadm|cgi|_run_|'
                            r'sudo|setrlimit|nis_enabled|mount_anyfile|polyinstantiation|_home|user_content|'
                            r'staff|mmap_files|kernel|module|boot|bpf|privileged|tty|login|'
                            r'use_nfs|use_cifs|use_fusefs|anon_write|dontaudit|dump_core|'
                            r'domain_can_|global_ssp|fips_mode')
# security-sensitive targets: never allowed from here, whatever the permission
SE_SENSITIVE = re.compile(r'^(shadow_t|passwd_file_t|security_t|selinux_config_t|semanage_\w+|load_policy_\w+|'
                          r'policy_\w+|default_context_t|file_context_t|setfiles_\w+|kernel_t|proc_kcore_t|'
                          r'proc_kmsg_t|memory_device_t|sysctl\w*|\w*_key_t|\w*keytab\w*|\w*_keys_t|auditd_\w+|'
                          r'audit_\w+|audisp_\w+|sudo_\w+|\w*_home_t|\w*_home_dir_t|home_root_t|admin_home_t|'
                          r'user_tmp_t|boot_t|bootloader_\w+|fixed_disk_device_t|removable_device_t|lvm_\w+|'
                          r'init_exec_t|systemd_passwd_\w+|chkpwd_\w+|shadow_\w+|login_\w+|local_login_\w+|'
                          r'cert_t|\w*_cert_t|gpg_\w+|ssh_home_t|sshd_key_t|ssh_keysign_\w+|ssh_agent_\w+|'
                          r'kmod_\w+|modules_\w+|efivarfs_t|tpm_device_t|xserver_\w+|crack_\w+)\Z')
# what would let it run, change or reach far more than this
SE_DANGER_PERMS = frozenset(('execute', 'execute_no_trans', 'entrypoint', 'execmod', 'execmem', 'execstack',
                             'execheap', 'transition', 'dyntransition', 'ptrace', 'relabelfrom', 'relabelto',
                             'setexec', 'setcurrent', 'setfscreate', 'setkeycreate', 'setsockcreate', 'mounton',
                             'mount', 'remount', 'unmount', 'quotaon', 'quotamod', 'swapon', 'load_policy',
                             'setenforce', 'setbool', 'setsecparam', 'module_load', 'module_request',
                             'sys_module', 'siginh', 'rlimitinh', 'noatsecure', 'share', 'setrlimit',
                             'setsched', 'associate', 'audit_control', 'audit_write', 'mac_admin',
                             'mac_override'))
# classes of the kernel's or the policy's own (capabilities among them)
SE_DANGER_CLASSES = frozenset(('security', 'kernel_service', 'key', 'bpf', 'capability', 'capability2',
                               'cap_userns', 'cap2_userns', 'system', 'service', 'filesystem', 'perf_event',
                               'lockdown', 'user_namespace', 'dbus', 'passwd', 'context', 'netlink_audit_socket',
                               'netlink_selinux_socket', 'netlink_kobject_uevent_socket', 'infiniband_pkey',
                               'infiniband_endport', 'io_uring', 'binder', 'memprotect', 'key_socket',
                               'kernel', 'nscd', 'x_device', 'x_server', 'security_class'))
SE_PROCESS_OK = frozenset(('signal', 'sigchld', 'signull', 'sigkill', 'sigstop', 'getattr', 'getsched',
                           'getpgid', 'getsession', 'getcap'))
SE_PROCESS2_OK = frozenset(('nnp_transition', 'nosuid_transition'))
# types many programs share: a write to one is never allowed from here - the file wants a label
SE_GENERIC = frozenset(('etc_t', 'usr_t', 'bin_t', 'lib_t', 'shlib_t', 'textrel_shlib_t', 'var_t', 'var_lib_t',
                        'var_run_t', 'var_log_t', 'var_spool_t', 'default_t', 'tmp_t', 'usr_tmp_t', 'root_t',
                        'file_t', 'unlabeled_t', 'device_t', 'proc_t', 'sysfs_t', 'tmpfs_t', 'mnt_t', 'src_t',
                        'man_t', 'locale_t', 'etc_runtime_t', 'system_conf_t', 'net_conf_t', 'httpd_config_t',
                        'httpd_exec_t', 'httpd_sys_content_t', 'httpd_sys_script_exec_t', 'systemd_unit_file_t',
                        'cron_spool_t', 'system_cron_spool_t'))
SE_WRITE_PERMS = frozenset(('write', 'append', 'create', 'unlink', 'rename', 'add_name', 'remove_name', 'rmdir',
                            'reparent', 'setattr', 'link'))
SE_HEX_FIELDS = ('proctitle', 'name', 'path', 'comm', 'exe', 'cwd')
SE_FIELD = re.compile(r'(?:^|[\s\'])([a-z_][a-z0-9_]*)=("[^"]*"|[^\s\']*)')
SE_AUDIT_ID = re.compile(r'msg=audit\((\d+(?:\.\d+)?):(\d+)\)')
SE_PERMS_RE = re.compile(r'denied\s+\{([^}]*)\}')


def se_field(key, value):
    """One field of an audit record, as the program saw it: quoted is plain; a few fields
    (proctitle name path comm exe cwd) are written as hex when they hold a space or worse -
    decoded, and only those: never a port, never a context."""
    if len(value) >= 2 and value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if key in SE_HEX_FIELDS and len(value) % 2 == 0 and re.match(r'^[0-9A-Fa-f]{2,}\Z', value):
        try:
            raw = bytes.fromhex(value)
        except ValueError:
            return value
        if key == 'proctitle':
            raw = raw.replace(b'\0', b' ')
        return raw.decode('utf-8', 'replace').rstrip('\0')
    return value


def se_fields(line):
    out = {}
    for m in SE_FIELD.finditer(line):
        out.setdefault(m.group(1), se_field(m.group(1), m.group(2)))
    return out


def se_type(ctx):
    parts = str(ctx or '').split(':')
    return parts[2] if len(parts) >= 3 else ''


def se_clean(text, most=200):
    """Words from the audit log, for a page and a person: printable, one line, short - a
    program's name or a path are whatever that program made them."""
    return re.sub(r'[\x00-\x1f\x7f]', '?', str(text or ''))[:most]


def se_events(text):
    """The audit log's records by event: {event id: {'at', 'avc': [(type, line)], 'syscall',
    'paths', 'cwd', 'proctitle'}}."""
    ev = {}
    for line in (text or '').splitlines():
        line = line.strip()
        m = SE_AUDIT_ID.search(line)
        t = re.match(r'^(?:node=\S+\s+)?type=([A-Z_0-9]+)\s', line)
        if not m or not t:
            continue
        key = m.group(1) + ':' + m.group(2)
        e = ev.get(key)
        if e is None:
            if len(ev) >= 200000:
                continue
            e = ev[key] = {'at': float(m.group(1)), 'avc': [], 'syscall': {}, 'paths': [], 'cwd': '',
                           'proctitle': ''}
        kind = t.group(1)
        if kind in ('AVC', 'USER_AVC', 'SELINUX_ERR', 'USER_SELINUX_ERR'):
            if len(e['avc']) < 32:
                e['avc'].append((kind, line))
        elif kind == 'SYSCALL':
            e['syscall'] = se_fields(line)
        elif kind == 'PATH':
            f = se_fields(line)
            if f.get('name') and len(e['paths']) < 8:
                e['paths'].append((f['name'], se_type(f.get('obj'))))
        elif kind == 'CWD':
            e['cwd'] = se_fields(line).get('cwd', '')
        elif kind == 'PROCTITLE':
            e['proctitle'] = se_fields(line).get('proctitle', '')
    return ev


def se_our_paths():
    """zigmon's own places: a confined program's refusal is zigmon's on one of them."""
    roots = [SE_LIB, STATE_DIR, OWN_DIR, os.path.dirname(CONFIG_FILE) or '/etc/zigmon', SE_WEB, SE_RUN,
             '/var/log/zigmon', FULL_DIR, MOSQ_DIR, CERT_DIR, '/etc/logrotate.d/zigmon',
             '/etc/systemd/system/zigmon.service', '/etc/systemd/system/zigmon-root.service',
             '/etc/systemd/system/zigmon-root.path', '/etc/systemd/system/zigmon-upgrade.service',
             '/etc/systemd/system/zigmon-upgrade.path', '/etc/zigmon-console-login',
             '/etc/profile.d/zz-zigmon-console.sh']
    if SE_RUN.startswith('/run/'):
        roots.append('/var' + SE_RUN)
    roots.extend(NGINX_CANDIDATES)
    out = []
    for r in roots:
        r = os.path.normpath(str(r or ''))
        if r and r != '/' and r.count('/') >= 2 and r not in out:
            out.append(r)
    return out


def se_is_ours(path, roots=None):
    if not path or not path.startswith('/'):
        return False
    p = os.path.normpath(path)
    return any(p == r or p.startswith(r + '/') for r in (roots or se_our_paths()))


def se_our_ports():
    """zigmon's ports, read here from its own files - never from a request: the API, the
    broker where it is this machine's, the sensors' listener, the ports nginx serves on."""
    try:
        with open(CONFIG_FILE) as f:
            conf = json.load(f)
    except (OSError, ValueError):
        conf = {}
    if not isinstance(conf, dict):
        conf = {}
    want = [conf.get('api_port') or 9849, 80, 443]
    if str(conf.get('mqtt_host') or '127.0.0.1') in ('127.0.0.1', 'localhost', '::1'):
        want += [conf.get('mqtt_port') or 1883, 1883, 8883]
    if conf.get('sensor_listen'):
        want.append(conf.get('sensor_listen_port'))
    want += [p['port'] for p in se_nginx_ports()]
    out = set()
    for p in want:
        if isinstance(p, bool):
            continue
        try:
            n = int(p)
        except (TypeError, ValueError):
            continue
        if 1 <= n <= 65535:
            out.add(n)
    return out


def se_fixed_read():
    got = own_read(SE_FIXED)
    if not isinstance(got, dict):
        return {}
    return {k: v for k, v in got.items() if SE_ID_RE.match(str(k)) and isinstance(v, dict)}


def se_fixed_write(marks):
    # the newest 500: an old mark only hides refusals older than itself
    keep = sorted(marks.items(), key=lambda kv: -float(kv[1].get('at') or 0))[:500]
    own_write(SE_FIXED, dict(keep))


def se_local_dir():
    d = os.path.join(own_fd(), SE_LOCAL_SUB)
    os.makedirs(d, mode=0o700, exist_ok=True)
    os.chmod(d, 0o700)
    return d


def se_local_rules():
    """zigmon's local rules, as root keeps them: [{id, source, target, class, perms, why, ...}]
    - every one checked again for its shape, whatever is in the file."""
    try:
        with open(os.path.join(se_local_dir(), 'rules.json')) as f:
            got = json.load(f)
    except (OSError, ValueError):
        return []
    out = []
    for x in got if isinstance(got, list) else []:
        if not isinstance(x, dict):
            continue
        perms = x.get('perms')
        if (SE_ID_RE.match(str(x.get('id') or '')) and SE_TYPE_RE.match(str(x.get('source') or ''))
                and SE_TYPE_RE.match(str(x.get('target') or '')) and SE_WORD_RE.match(str(x.get('class') or ''))
                and isinstance(perms, list) and 1 <= len(perms) <= 32
                and all(SE_WORD_RE.match(str(p)) for p in perms)
                and not any(r['id'] == x['id'] for r in out)):
            try:
                at = float(x.get('at') or 0)
            except (TypeError, ValueError):
                at = 0.0
            out.append({'id': x['id'], 'source': x['source'], 'target': x['target'], 'class': x['class'],
                        'perms': sorted(set(perms)), 'why': se_clean(x.get('why'), 300),
                        'program': se_clean(x.get('program'), 64), 'at': at, 'by': se_clean(x.get('by'), 80)})
    return out[:500]


def se_rule_text(x):
    return '(allow %s %s (%s (%s)))' % (x['source'], x['target'], x['class'], ' '.join(x['perms']))


def se_local_text(rules):
    out = ['; zigmon\'s local rules (%s) - put in from Settings - Security - SELinux ("Put in what is' % SE_LOCAL,
           '; selected") or zigmon --selinux-fix, each exactly what SELinux refused here and nothing more.',
           '; Taken away one by one on the same card (or zigmon --selinux-rules --take-away ID);',
           '; install.sh --uninstall takes the module away. Written by root\'s helper from its own list',
           '; (%s); never edited by hand - the next change writes it again.' % SE_LOCAL_SUB, '']
    for x in rules:
        out.append('; %s - %s (%s)' % (x['id'], re.sub(r'[^ -~]', '?', x.get('why') or '')[:200],
                                       time.strftime('%Y-%m-%d %H:%M', time.localtime(x.get('at') or 0))))
        out.append('(optional %s_%s' % (SE_LOCAL, x['id']))
        out.append('    %s)' % se_rule_text(x))
    return '\n'.join(out) + '\n'


SE_CIL_ONE = re.compile(r'\(optional %s_[0-9a-f]{12} \(allow [a-z][a-z0-9_]*_t [a-z][a-z0-9_]*_t '
                        r'\([a-z][a-z0-9_]* \([a-z][a-z0-9_]*(?: [a-z][a-z0-9_]*)*\)\)\)\)' % SE_LOCAL)


def se_cil_ok(text):
    """The local module before it goes near semodule: balanced, and nothing but optional
    blocks of one allow each - in the shapes the list allows."""
    body = '\n'.join(line.split(';', 1)[0] for line in text.splitlines())
    depth = 0
    for ch in body:
        depth += {'(': 1, ')': -1}.get(ch, 0)
        if depth < 0:
            return False
    if depth:
        return False
    flat = re.sub(r'\s+', ' ', body)
    flat = re.sub(r'\(\s+', '(', flat)
    flat = re.sub(r'\s+\)', ')', flat).strip()
    return SE_CIL_ONE.sub('', flat).strip() == ''


def se_modules():
    got = se_run(['semodule', '-l'], 120, light=True)
    if got is None or got.returncode != 0:
        return None
    return {line.split()[0] for line in got.stdout.splitlines() if line.split()}


def se_local_put(rules, said):
    """The local module written again from its list and put into the policy; the last rule
    taken away: the module taken out. A change semodule refuses raises - the caller puts the
    list back."""
    d = se_local_dir()
    cil = os.path.join(d, SE_LOCAL + '.cil')
    if not rules:
        mods = se_modules()
        if mods is not None and SE_LOCAL in mods:
            got = se_run(['semodule', '-r', SE_LOCAL], 300)
            if got is None or got.returncode != 0:
                raise SeRefused('semodule -r %s: %s' % (SE_LOCAL, se_said(got)))
            said.append('zigmon\'s local module (%s) taken out of the policy - no rule left in it' % SE_LOCAL)
        for n in (SE_LOCAL + '.cil', SE_LOCAL + '.cil.in-policy'):
            try:
                os.unlink(os.path.join(d, n))
            except OSError:
                pass
        return
    text = se_local_text(rules)
    if not se_cil_ok(text):
        raise SeRefused('the local module came out in a shape it may not have - nothing put in')
    fd, tmp = tempfile.mkstemp(dir=d, prefix='.' + SE_LOCAL + '-', suffix='.cil')
    with os.fdopen(fd, 'w') as f:
        f.write(text)
        os.fchmod(f.fileno(), 0o600)
    # semodule names the module after the file: zigmon_local.cil, written whole first
    os.replace(tmp, cil)
    got = se_run(['semodule', '-i', cil], 300)
    if got is None or got.returncode != 0:
        raise SeRefused('semodule -i %s: %s' % (cil, se_said(got)))
    shutil.copyfile(cil, cil + '.in-policy')
    os.chmod(cil + '.in-policy', 0o600)
    said.append('zigmon\'s local module (%s) put into the policy - %d rule(s) in it' % (SE_LOCAL, len(rules)))


def se_local_save(rules):
    d = se_local_dir()
    fd, tmp = tempfile.mkstemp(dir=d, prefix='.rules-')
    with os.fdopen(fd, 'w') as f:
        f.write(json.dumps(rules, indent=1))
        os.fchmod(f.fileno(), 0o600)
    os.replace(tmp, os.path.join(d, 'rules.json'))


def se_local_back(rules):
    """A change the policy did not take: the list and the module's file as they were."""
    d = se_local_dir()
    cil = os.path.join(d, SE_LOCAL + '.cil')
    try:
        se_local_save(rules)
        if os.path.exists(cil + '.in-policy'):
            shutil.copyfile(cil + '.in-policy', cil)
        elif os.path.exists(cil):
            os.unlink(cil)
    except OSError:
        pass


def se_local_view(mods=None):
    rules = se_local_rules()
    cil = os.path.join(se_local_dir(), SE_LOCAL + '.cil')
    return {'module': SE_LOCAL, 'in_policy': (SE_LOCAL in mods) if mods is not None else None,
            'file': cil if os.path.exists(cil) else '',
            'rules': [dict(x, rule=se_rule_text(x)) for x in rules]}


def se_why_blocks(lines):
    """audit2why on one refusal of each group: {the line, stripped: what audit2why said}."""
    if not lines:
        return {}
    got = se_run(['audit2why'], 300, light=True, data=''.join(x + '\n' for x in lines))
    if got is None or got.returncode != 0:
        return {}
    want = {x.strip(): x for x in lines}
    by_ev = {}
    for x in lines:
        m = SE_AUDIT_ID.search(x)
        p = SE_PERMS_RE.search(x)
        if m:
            by_ev.setdefault((m.groups(), p.group(1).split() if p else None).__repr__(), x.strip())
    out, cur = {}, None
    for line in (got.stdout or '').splitlines():
        m = SE_AUDIT_ID.search(line)
        if m and re.search(r'type=(USER_)?(AVC|SELINUX_ERR)', line):
            cur = line.strip() if line.strip() in want else None
            if cur is None:
                # an audit2why that writes the line its own way: the same event, the same refusal
                p = SE_PERMS_RE.search(line)
                cur = by_ev.get((m.groups(), p.group(1).split() if p else None).__repr__())
            if cur is not None:
                out.setdefault(cur, '')
            continue
        if cur is not None and len(out[cur]) < 8000:
            out[cur] += line + '\n'
    return out


def se_matchpathcon(paths):
    """What the policy says each path should be labelled: {path: type}."""
    paths = [p for p in paths if p.startswith('/')][:SE_FIND_MOST]
    if not paths:
        return {}
    got = se_run(['matchpathcon'] + paths, 120, light=True)
    if got is None:
        return {}
    out = {}
    for line in (got.stdout or '').splitlines():
        m = re.match(r'^(/\S*)\s+(\S+)\s*$', line.strip())
        if m and se_type(m.group(2)):
            out[m.group(1)] = se_type(m.group(2))
    return out


def se_port_owners(known, proto, port):
    return sorted({t for (t, p), spans in (known or {}).items() if p == proto and t not in SE_PORT_GENERIC
                   and any(lo <= port <= hi for lo, hi in spans)})


def se_relabel_target(path, roots):
    """Where restorecon is run for a refusal on `path`: the path where it still is, else the
    nearest folder of it that is - never outside zigmon's places, never through a link that
    leads out of them."""
    p = os.path.normpath(path)
    while p and p != '/' and se_is_ours(p, roots):
        if os.path.lexists(p):
            return p if se_is_ours(os.path.realpath(p), roots) else ''
        p = os.path.dirname(p)
    return ''


def se_read_findings(text, roots=None, ports=None):
    """The groups of what was refused, before they are sorted: {key: group}."""
    roots = roots or se_our_paths()
    ports = se_our_ports() if ports is None else ports
    groups = {}
    for eid, e in se_events(text).items():
        sc = e['syscall']
        argv = (e['proctitle'] or '').split()
        exe = se_clean(sc.get('exe') or '', 300)
        zprog = exe.startswith(SE_LIB + '/') or any(a.startswith(SE_LIB + '/') for a in argv[:4]) or \
            os.path.basename(exe).startswith('zigmon')
        for kind, line in e['avc']:
            f = se_fields(line)
            perms_m = SE_PERMS_RE.search(line)
            err = kind.endswith('SELINUX_ERR')
            if not perms_m and not err:
                continue                       # granted (auditallow), or nothing to read
            src = se_type(f.get('scontext') or f.get('oldcontext'))
            tgt = se_type(f.get('tcontext') or f.get('newcontext'))
            cls = re.sub(r'[^a-z0-9_]', '', str(f.get('tclass') or ('process' if err else '')))[:40]
            if not src or not tgt or not cls:
                continue
            perms = sorted(set(perms_m.group(1).split())) if perms_m else \
                [re.sub(r'[^a-z0-9_]', '', str(f.get('op') or ''))[:40] or 'error']
            perms = [p[:40] for p in perms][:32] or ['?']
            comm = se_clean(f.get('comm') or sc.get('comm') or os.path.basename(f.get('exe') or exe) or '?', 64)
            exe1 = se_clean(f.get('exe') or exe, 300)
            name = str(f.get('name') or '')
            path = ''
            if str(f.get('path') or '').startswith('/'):
                path = f['path']
            else:
                cand = [(n, t) for n, t in e['paths'] if n not in ('(null)', '?')]
                pick = next((n for n, t in cand if t == tgt), None) or \
                    next((n for n, t in cand if name and n.endswith('/' + name)), None) or \
                    next((n for n, t in cand if n.startswith('/')), None)
                if pick and not pick.startswith('/') and e['cwd'].startswith('/'):
                    pick = os.path.join(e['cwd'], pick)
                path = pick if pick and pick.startswith('/') else ''
            path = se_clean(os.path.normpath(path), 400) if path else ''
            name = se_clean(name, 200) if not path and name not in ('(null)', '?') else ''
            port, proto = 0, ''
            if cls in ('tcp_socket', 'udp_socket', 'sctp_socket', 'dccp_socket'):
                for k in ('src', 'dest', 'lport', 'port'):
                    v = str(f.get(k) or '')
                    if re.match(r'^\d{1,5}\Z', v) and 1 <= int(v) <= 65535:
                        port, proto = int(v), cls.split('_')[0]
                        break
            where = path or ('port %d/%s' % (port, proto) if port else name)
            key = (src, tgt, cls, ' '.join(perms), comm, where)
            g = groups.get(key)
            if g is None:
                if len(groups) >= 2000:
                    continue
                g = groups[key] = {
                    'id': hashlib.sha256('|'.join(key).encode('utf-8', 'replace')).hexdigest()[:12],
                    'source': src, 'target': tgt, 'class': cls, 'perms': perms, 'program': comm, 'exe': exe1,
                    'path': path, 'name': name, 'port': port, 'proto': proto, 'count': 0,
                    'first': e['at'], 'last': e['at'], 'permissive': False, 'error': err, 'line': line,
                    'zprog': False, 'user': kind.startswith('USER_'), 'evs': set()}
            g['count'] += 1
            if len(g['evs']) < 20000:
                g['evs'].add(eid)
            g['first'] = min(g['first'], e['at'])
            if e['at'] >= g['last']:
                g['last'], g['line'] = e['at'], line
            g['permissive'] = g['permissive'] or str(f.get('permissive') or '') == '1'
            g['zprog'] = g['zprog'] or zprog
    for g in groups.values():
        g['ours'] = bool(
            g['zprog']
            or (g['source'] in SE_TOOL_DOMAINS and g['target'] == 'unconfined_service_t')
            or (g['source'] in SE_PARTNERS + SE_TOOL_DOMAINS
                and (se_is_ours(g['path'], roots) or (g['port'] and g['port'] in ports))))
    return groups


def se_danger(g):
    """Why it is not for a button, or ''."""
    perms, cls, tgt = set(g['perms']), g['class'], g['target']
    if g.get('error'):
        return 'an error of the policy itself (%s) - no rule put in here changes it' % ' '.join(g['perms'])
    if not (SE_TYPE_RE.match(g['source']) and SE_TYPE_RE.match(tgt) and SE_WORD_RE.match(cls)
            and perms and all(SE_WORD_RE.match(p) for p in perms)):
        return 'not the shape of a rule this helper writes - never put right from here'
    if SE_SENSITIVE.match(tgt) or SE_SENSITIVE.match(g['source']):
        return '%s is security-sensitive (%s) - never allowed from here' % (
            tgt if SE_SENSITIVE.match(tgt) else g['source'], cls)
    bad = sorted(p for p in perms if p in SE_DANGER_PERMS or p.startswith('exec'))
    if bad:
        return '%s { %s } would let it run, change or reach far more than this - never allowed from here' % (
            cls, ' '.join(bad))
    if cls in SE_DANGER_CLASSES:
        return '%s is a class of the kernel\'s or the policy\'s own - never allowed from here' % cls
    if cls == 'process' and not perms <= SE_PROCESS_OK:
        return 'process { %s } would let it reach far more than this - never allowed from here' % ' '.join(
            sorted(perms - SE_PROCESS_OK))
    if cls == 'process2' and not perms <= SE_PROCESS2_OK:
        return 'process2 { %s } - never allowed from here' % ' '.join(sorted(perms - SE_PROCESS2_OK))
    if 'name_bind' in perms and tgt.endswith('_port_t') and tgt not in SE_PORT_GENERIC:
        return '%s is another service\'s port type - a port is never taken from it here' % tgt
    return ''


def se_bool_ok(name, source):
    """A boolean audit2why names is switched on from here only when it is the program's own
    (httpd_* for httpd_t) or on SE_BOOLEANS - and never when it is one of SE_BOOL_DANGER, which
    wins over every list."""
    if not isinstance(name, str) or not SE_BOOL_RE.match(name) or SE_BOOL_DANGER.search(name):
        return False
    stem = source[:-2] if source.endswith('_t') else source
    return name in SE_BOOLEANS or (len(stem) >= 3 and name.startswith(stem + '_'))


def se_sort(g, why, matched, known, local, fixed, now):
    """One group's kind, why, and what puts it right (or nothing)."""
    g['fix'], g['fix_kind'], g['why'] = '', '', ''
    mark = fixed.get(g['id'])
    if mark and g['last'] <= float(mark.get('at') or 0):
        g['put_right'] = True
        if now - float(mark['at']) <= SE_FIXED_SHOW_S:
            g['kind'], g['fixed_at'] = 'fixed', float(mark['at'])
            g['why'] = 'put right %s - it goes at the next look' % time.strftime('%H:%M', time.localtime(mark['at']))
        else:
            g['kind'], g['why'] = 'allowed', 'put right since'
        return
    if not g['ours']:
        g['kind'] = 'other'
        g['why'] = 'not zigmon\'s: %s (%s) is another program of this machine - look at it with whoever ' \
                   'looks after it' % (g['program'], g['source'])
        return
    if 'would be allowed by active policy' in why or any(
            x['source'] == g['source'] and x['target'] == g['target'] and x['class'] == g['class']
            and set(g['perms']) <= set(x['perms']) for x in local):
        g['kind'], g['why'] = 'allowed', 'the policy loaded now allows it'
        return
    danger = se_danger(g)
    if danger:
        g['kind'], g['why'] = 'notbutton', danger
        return
    if re.search(r'(?i)constraint', why):
        g['kind'], g['why'] = 'notbutton', 'a constraint of the policy (audit2why) - an allow rule does not change it'
        return
    if re.search(r'(?i)missing role|role allow', why):
        g['kind'], g['why'] = 'notbutton', 'a role of the policy (audit2why) - no rule put in here changes it'
        return
    if g['path'] and se_is_ours(g['path']):
        want = matched.get(g['path'])
        if want and want != g['target']:
            now_label = se_label(g['path']) if os.path.lexists(g['path']) else None
            if now_label and (now_label == want or se_label_ok(now_label, want)):
                g['kind'], g['why'] = 'allowed', '%s is labelled %s since' % (g['path'], want)
                return
            target = se_relabel_target(g['path'], se_our_paths())
            if target:
                g['kind'], g['fix_kind'], g['relabel'] = 'label', 'label', target
                g['fix'] = 'restorecon -R -v %s' % target
                g['why'] = '%s is labelled %s - the policy says %s' % (g['path'], g['target'], want)
                return
    if g['port'] and g['perms'] == ['name_bind'] and g['source'] in SE_PORT_FIX \
            and g['target'] in SE_PORT_GENERIC and g['proto'] in ('tcp', 'udp'):
        kind = SE_PORT_FIX[g['source']]
        owners = se_port_owners(known, g['proto'], g['port'])
        if kind in owners or (kind == 'http_port_t' and 'http_cache_port_t' in owners):
            g['kind'], g['why'] = 'allowed', 'port %d/%s is %s since' % (g['port'], g['proto'], kind)
            return
        if owners:
            g['kind'] = 'notbutton'
            g['why'] = 'port %d/%s is %s\'s - another service\'s port is never taken from here' % (
                g['port'], g['proto'], ', '.join(owners))
            return
        if known is None:
            g['kind'] = 'notbutton'
            g['why'] = 'semanage is not on this machine - the port cannot be looked at ' \
                       '(dnf install policycoreutils-python-utils)'
            return
        g['kind'], g['fix_kind'], g['port_type'] = 'port', 'port', kind
        g['fix'] = 'semanage port -a -t %s -p %s %d' % (kind, g['proto'], g['port'])
        g['why'] = 'port %d/%s has no type of its own - %s may bind it once it is %s' % (
            g['port'], g['proto'], g['source'], kind)
        return
    names = re.findall(r'setsebool -P ([A-Za-z0-9_]+) (?:1|on|true)\b', why)
    if names:
        ok = [n for n in names if se_bool_ok(n, g['source'])]
        if ok:
            pick = next((n for n in ok if n in SE_BOOLEANS), ok[0])
            g['kind'], g['fix_kind'], g['boolean'] = 'boolean', 'boolean', pick
            g['fix'] = 'setsebool -P %s 1' % pick
            g['why'] = 'audit2why: the boolean %s allows it' % pick
            return
        g['kind'] = 'notbutton'
        g['why'] = 'audit2why names only a boolean that allows far more (%s) - never switched on from here' % (
            ', '.join(names[:3]))
        return
    if set(g['perms']) & SE_WRITE_PERMS and g['target'] in SE_GENERIC:
        g['kind'] = 'notbutton'
        g['why'] = '%s is a type many programs share - a write to it is never allowed from here; the file ' \
                   'wants a label of its own' % g['target']
        return
    g['kind'], g['fix_kind'] = 'rule', 'rule'
    g['fix'] = se_rule_text(g)
    g['why'] = 'nothing of the policy allows it: a rule of zigmon\'s own local module allows exactly this'


def se_findings(text, fixed=None, known=None):
    """Every refusal since the machine started, grouped and sorted (see above). `known`: the
    port types as semanage says (None: not there)."""
    now = time.time()
    fixed = se_fixed_read() if fixed is None else fixed
    groups = list(se_read_findings(text).values())
    ours = [g for g in groups if g['ours']]
    whys = se_why_blocks([g['line'] for g in ours][:SE_FIND_MOST * 2])
    matched = se_matchpathcon(sorted({g['path'] for g in ours if g['path'] and se_is_ours(g['path'])}))
    local = se_local_rules()
    if local:
        # (5.56) a rule of the list allows only while its module is in the policy: taken out
        # (install.sh --uninstall, semodule -r by hand) the list stays in root's folder, and
        # what it allowed was counted "allowed now" - hidden, with no button to put it back
        mods = se_modules()
        if mods is not None and SE_LOCAL not in mods:
            local = []
    for g in groups:
        se_sort(g, whys.get(g['line'].strip(), '') if g['ours'] else '', matched, known, local, fixed, now)
    order = {k: i for i, k in enumerate(SE_KINDS)}
    groups.sort(key=lambda g: (order.get(g['kind'], 99), -g['count'], g['id']))
    return groups


def se_finding_out(g):
    """A finding as the page and the command line get it: nothing of the raw record."""
    keep = ('id', 'kind', 'source', 'target', 'class', 'program', 'exe', 'path', 'name', 'port', 'proto',
            'first', 'last', 'permissive', 'why', 'fix', 'fix_kind', 'user', 'fixed_at')
    out = {k: g.get(k) for k in keep if g.get(k) not in (None, '', 0, False)}
    out['perms'] = ' '.join(g['perms'])
    out['count'] = g['count']
    return out


def se_look_into(out, groups):
    """se_check's part for the findings: the list, the counts, zigmon's local rules."""
    out['look_at'] = time.time()
    out['local'] = se_local_view(se_modules())
    if groups is None:
        out['findings'], out['counts'] = [], {'tool': False, 'fixable': 0, 'notbutton': 0}
        return
    counts = {k: 0 for k in SE_KINDS}
    for g in groups:
        counts[g['kind']] = counts.get(g['kind'], 0) + 1
    counts['fixable'] = sum(counts[k] for k in SE_FIXABLE)
    counts['tool'] = True
    counts['total'] = len(groups)
    shown = [g for g in groups if g['kind'] != 'allowed'][:SE_FIND_MOST]
    out['findings'] = [se_finding_out(g) for g in shown]
    counts['shown'] = len(out['findings'])
    out['counts'] = counts


def se_ids(r, most=64):
    ids = r.get('ids')
    if not isinstance(ids, list) or not 1 <= len(ids) <= most:
        raise SeRefused('one finding id at least, %d at most' % most)
    out = []
    for x in ids:
        if not isinstance(x, str) or not SE_ID_RE.match(x):
            raise SeRefused('a finding id is 12 hex characters - the page sends nothing else')
        if x not in out:
            out.append(x)
    return out


# A request for a fix names finding ids and nothing else: what is put right is worked out here
# from the audit log. A key of any other name - a rule, a path, a command - refuses it whole.
SE_FIX_KEYS = frozenset(('do', 'ids', 'id', 'until', 'by', 'at', 'booleans', 'ports', 'facts'))


def se_only_ids(r):
    extra = sorted(str(k) for k in r if k not in SE_FIX_KEYS)
    if extra:
        raise SeRefused('a request names finding ids only - root works out every fix itself (%s refused)'
                        % ', '.join(re.sub(r'[^A-Za-z0-9_-]', '', k)[:20] for k in extra[:4]))


def se_by(r):
    return re.sub(r'[^A-Za-z0-9 ._@()-]', '', str(r.get('by') or 'the command line'))[:60] or 'the command line'


def se_fix(r):
    """Put right what the ids name - each found again in the audit log, its fix worked out
    again here. An id not found, or one not for a button, refuses the whole request: nothing is
    done then. Works under enforcing too. -> (said, failed, ids done)"""
    se_only_ids(r)
    ids = se_ids(r)
    mode = se_mode()
    if mode not in ('Enforcing', 'Permissive'):
        raise SeRefused('SELinux is %s here - nothing to put right' % (
            'not on this machine' if mode == 'absent' else mode.lower()))
    got = se_run(['ausearch', '-m', 'AVC,USER_AVC,SELINUX_ERR,USER_SELINUX_ERR', '-ts', 'boot'], 300, light=True)
    if got is None:
        raise SeRefused('ausearch is not on this machine (dnf install audit)')
    fixed = se_fixed_read()
    by_id = {g['id']: g for g in se_findings(got.stdout or '', fixed, se_ports())}
    todo = []
    for i in ids:
        g = by_id.get(i)
        if g is None:
            raise SeRefused('finding %s is not in the audit log - look again (nothing was done)' % i)
        if g['kind'] in ('fixed', 'allowed'):
            continue
        if g['kind'] not in SE_FIXABLE:
            raise SeRefused('finding %s is not for a button: %s (nothing was done)' % (i, g['why']))
        todo.append(g)
    said, failed, done = [], [], []
    for g in [x for x in todo if x['kind'] == 'boolean']:
        name = g['boolean']
        if not se_bool_ok(name, g['source']):           # the lists again, at the moment of it
            failed.append('%s: the boolean %s is not one switched on from here' % (g['id'], name))
            continue
        got = se_run(['setsebool', '-P', name, 'on'], 300)
        if got is None or got.returncode != 0:
            failed.append('%s: setsebool -P %s 1: %s' % (g['id'], name, se_said(got)))
            continue
        said.append('%s: the boolean %s on (%s: %s -> %s %s)' % (g['id'], name, g['program'], g['source'],
                                                                g['target'], g['class']))
        done.append(g)
    roots = se_our_paths()
    for g in [x for x in todo if x['kind'] == 'label']:
        target = se_relabel_target(g['path'], roots)
        if not target or target != g.get('relabel'):
            failed.append('%s: %s is not there any more' % (g['id'], g.get('relabel') or g['path']))
            continue
        got = se_run(['restorecon', '-R', '-v', target], 300)
        if got is None or got.returncode != 0:
            failed.append('%s: restorecon -R -v %s: %s' % (g['id'], target, se_said(got)))
            continue
        said.append('%s: %s labelled as the policy says (restorecon)' % (g['id'], target))
        done.append(g)
    for g in [x for x in todo if x['kind'] == 'port']:
        kind = SE_PORT_FIX.get(g['source'])
        if not kind or kind != g.get('port_type'):
            failed.append('%s: no port type of its own for %s' % (g['id'], g['source']))
            continue
        owners = se_port_owners(se_ports(), g['proto'], g['port'])
        if owners:
            failed.append('%s: port %d/%s is %s\'s - never taken from another service' % (
                g['id'], g['port'], g['proto'], ', '.join(owners)))
            continue
        # -a only, never -m: a port of another type is that service's
        got = se_run(['semanage', 'port', '-a', '-t', kind, '-p', g['proto'], str(g['port'])], 300)
        if got is None or got.returncode != 0:
            failed.append('%s: semanage port -a %d/%s: %s' % (g['id'], g['port'], g['proto'], se_said(got)))
            continue
        said.append('%s: port %d/%s labelled %s' % (g['id'], g['port'], g['proto'], kind))
        done.append(g)
    new = [x for x in todo if x['kind'] == 'rule']
    if new:
        rules = se_local_rules()
        before = list(rules)
        added = []
        for g in new:
            if se_danger(g):                             # the lists again
                failed.append('%s: %s' % (g['id'], se_danger(g)))
                continue
            if not any(x['id'] == g['id'] for x in rules):
                rules.append({'id': g['id'], 'source': g['source'], 'target': g['target'], 'class': g['class'],
                              'perms': list(g['perms']), 'why': '%s: %s' % (g['program'], g['why']),
                              'program': g['program'], 'at': time.time(), 'by': se_by(r)})
            added.append(g)
        if added:
            words = ['%s: rule %s' % (g['id'], se_rule_text(g)) for g in added]
            put = []
            try:
                se_local_save(rules)
                se_local_put(rules, put)
                said.extend(words + put)
                done.extend(added)
            except (SeRefused, OSError) as e:
                se_local_back(before)
                failed.append('the local module could not be put in: %s' % str(e)[:300])
    if done:
        now = time.time()
        for g in done:
            fixed[g['id']] = {'at': now, 'kind': g['kind'], 'what': g['fix'][:300],
                              'key': [g['source'], g['target'], g['class'], ' '.join(g['perms'])]}
        se_fixed_write(fixed)
    return said, failed, [g['id'] for g in done]


def se_rule_drop(r):
    """One of zigmon's local rules taken away (the last one: the module taken out)."""
    se_only_ids(r)
    ids = se_ids(r, most=1)
    rules = se_local_rules()
    gone = [x for x in rules if x['id'] == ids[0]]
    if not gone:
        raise SeRefused('zigmon\'s local module has no rule %s' % ids[0])
    keep = [x for x in rules if x['id'] != ids[0]]
    said = ['%s: rule %s taken away' % (ids[0], se_rule_text(gone[0]))]
    se_local_save(keep)
    try:
        se_local_put(keep, said)
    except (SeRefused, OSError):
        se_local_back(rules)
        raise
    fixed = se_fixed_read()
    if fixed.pop(ids[0], None) is not None:
        se_fixed_write(fixed)                    # refused again from now on, it comes back
    return said


def se_restorecon(said):
    paths = [p for p in (SE_RUN, SE_WEB) if os.path.exists(p)]
    if not paths:
        return False
    got = se_run(['restorecon', '-R', '-v'] + paths, 300)
    if got is not None and re.search(r'(?i)relabel', (got.stdout or '') + (got.stderr or '')):
        said.append('zigmon\'s files labelled again')
        return True
    return False


def se_apply(bools, ports, said, mark=True):
    """zigmon's module, the labels of its files, the booleans and the ports - on a machine
    where SELinux is on. `mark`: when anything was changed, what SELinux refused before no
    longer counts (it is what this put right) - never on the way to enforcing."""
    changed = False
    inpol = se_read(SE_CIL + '.in-policy')
    if os.path.exists(SE_CIL) and se_tool('semodule') and (
            se_module_in() is not True or inpol != se_read(SE_CIL)):
        got = se_run(['semodule', '-i', SE_CIL], 300)
        if got is None or got.returncode != 0:
            raise SeRefused('semodule -i %s: %s' % (SE_CIL, se_said(got)))
        said.append('zigmon\'s module (%s) installed' % SE_MODULE)
        changed = True
        try:
            shutil.copyfile(SE_CIL, SE_CIL + '.in-policy')
        except OSError:
            pass
    for b in bools:
        if se_bool(b['name']) is False:
            got = se_run(['setsebool', '-P', b['name'], 'on'], 300)
            if got is None or got.returncode != 0:
                raise SeRefused('setsebool -P %s on: %s' % (b['name'], se_said(got)))
            said.append('%s on' % b['name'])
            changed = True
    known = se_ports() if ports else {}
    for p in ports:
        if known is None:
            raise SeRefused('semanage is not on this machine (dnf install policycoreutils-python-utils)')
        if se_port_has(known, p['type'], p['proto'], p['port']):
            continue
        # -a only, never -m: a port of another type is that service's, and taken from it
        # the service could not bind it at its next start
        got = se_run(['semanage', 'port', '-a', '-t', p['type'], '-p', p['proto'], str(p['port'])], 300)
        if got is not None and got.returncode != 0 and 'already defined' in (got.stderr or '') + (got.stdout or ''):
            raise SeRefused('port %d/%s is another service\'s in the SELinux policy - choose another '
                            'port for it (%s)' % (p['port'], p['proto'], p['why']))
        if got is None or got.returncode != 0:
            raise SeRefused('semanage port -a %d/%s: %s' % (p['port'], p['proto'], se_said(got)))
        said.append('port %d/%s labelled %s' % (p['port'], p['proto'], p['type']))
        changed = True
    if se_restorecon(said):
        changed = True
    if mark and changed:
        own_write(SE_APPLIED, {'at': time.time()})


def se_do(r):
    do = r.get('do')
    if do == 'look':
        do = 'check'                    # a look is the check with the findings (5.55): the same
    left = []
    bools, ports = se_want_checked(r, left)
    said = list(left)
    if do == 'check':
        return se_check(r)
    if do in ('fix', 'rule_drop'):
        # what the page selected, by finding id only - every fix worked out here; works
        # under enforcing too. Looked at again at once.
        if do == 'fix':
            said, failed, ids = se_fix(r)
        else:
            said, failed, ids = se_rule_drop(r), [], []
        out = se_check(r)
        out['said'] = said + ['could not: %s' % x for x in failed]
        out['failed'] = failed
        out['fixed_now'] = ids
        return out
    if do == 'report':
        data = se_report_bytes(r)
        write_here(SE_REPORT_FILE, data)
        return {'report': SE_REPORT_FILE, 'bytes': len(data), 'at': time.time()}
    mode = se_mode()
    if mode == 'absent':
        raise SeRefused('there is no SELinux on this machine')
    if do == 'prepare':
        if mode == 'Enforcing':
            raise SeRefused('SELinux is enforcing already')
        se_config_set('permissive')
        said.append('%s: SELINUX=permissive' % SE_CONFIG)
        if mode == 'Disabled':
            # every file labelled at the next start, before anything runs (minutes); the
            # booleans and the ports go in once it is permissive ("Put in what zigmon needs")
            with open(SE_RELABEL, 'a'):
                pass
            said.append('the files are labelled at the next start of the machine')
            if se_cmdline_off() and se_tool('grubby'):
                got = se_run(['grubby', '--update-kernel', 'ALL', '--remove-args', 'selinux'], 120)
                if got is None or got.returncode != 0:
                    raise SeRefused('grubby: %s' % se_said(got))
                said.append('selinux=0 taken off the kernel\'s command line')
            elif se_cmdline_off():
                said.append('the kernel\'s command line has selinux=0: take it away '
                            '(grubby --update-kernel ALL --remove-args selinux)')
            if os.path.exists(SE_CIL) and se_tool('semodule'):
                got = se_run(['semodule', '-i', SE_CIL], 300)      # into the store; may not work
                if got is not None and got.returncode == 0:        # while disabled
                    said.append('zigmon\'s module (%s) installed' % SE_MODULE)
                    try:
                        shutil.copyfile(SE_CIL, SE_CIL + '.in-policy')
                    except OSError:
                        pass
            said.append('restart the machine - it comes up permissive')
        else:
            se_apply(bools, ports, said)
    elif do == 'enforce':
        if mode != 'Permissive':
            raise SeRefused('SELinux is %s - it goes to enforcing from permissive only' % mode.lower())
        se_apply(bools, ports, said, mark=False)
        c = se_check(r)
        if c['problems']:
            raise SeRefused('not yet: ' + '; '.join(c['problems'][:4]))
        got = se_run(['setenforce', '1'], 60)
        if got is None or got.returncode != 0:
            raise SeRefused('setenforce 1: %s' % se_said(got))
        se_config_set('enforcing')
        said.append('SELinux is enforcing, and stays so after a restart')
    elif do == 'permissive':
        if mode == 'Disabled':
            raise SeRefused('SELinux is disabled - "prepare" makes it permissive')
        if mode == 'Enforcing':
            got = se_run(['setenforce', '0'], 60)
            if got is None or got.returncode != 0:
                raise SeRefused('setenforce 0: %s' % se_said(got))
        se_config_set('permissive')
        said.append('SELinux is permissive, and stays so after a restart')
    else:
        raise SeRefused('check, look, prepare, enforce, permissive, fix, rule_drop or report')
    out = se_check(r)
    out['said'] = said
    return out


def selinux_part():
    ask_part(SELINUX_ASK, SELINUX_FILE, se_do, 16384)


# ---- the report, for whoever writes zigmon's module: nothing is changed to make it ------
SE_REPORT_PATHS = ('/run/zigmon', '/run/zigmon/api-token', '/var/lib/zigmon', '/var/lib/zigmon/root',
                   '/etc/zigmon', '/var/www/zigmon', '/usr/local/lib/zigmon', '/var/log/zigmon',
                   '/etc/nginx/conf.d', '/etc/nginx/certs', '/etc/mosquitto', '/etc/chrony.conf',
                   '/run/php-fpm', '/etc/logrotate.d/zigmon', '/etc/systemd/system/zigmon.service')
SE_REPORT_COMMS = ('python', 'zigmon', 'nginx', 'php-fpm', 'mosquitto', 'chronyd', 'auditd', 'systemd',
                   'zigbee2mqtt', 'node')
SE_REPORT_PORT_TYPES = ('http_port_t', 'http_cache_port_t', 'unreserved_port_t', 'ntp_port_t')
# Audit records that hold a command line or the arguments a program was given - the place a
# secret of another program could be: never in the report, whatever else is.
SE_AUDIT_KEEP = re.compile(r'^(----|time->|type=(AVC|USER_AVC|SELINUX_ERR|USER_SELINUX_ERR|SYSCALL|PATH|'
                           r'CWD|SOCKADDR)\b)')
SE_SECRET_WORDS = re.compile(r'(?i)(pass(word|wd|phrase)?|token|secret|key|pin|psk|auth|cookie|session)'
                             r'([\'"]?\s*[=:]\s*)[^\s,;&\'"]+')


def se_secrets():
    """Every secret of zigmon's this machine holds, to be blotted out of the report wherever it
    turns up: the API token, and each password, key, token and PIN in its configuration."""
    out = set()
    tok = se_read(os.path.join(SE_RUN, 'api-token'))
    if tok and tok.strip():
        out.add(tok.strip())
    try:
        with open(CONFIG_FILE) as f:
            conf = json.load(f)
    except (OSError, ValueError):
        conf = {}

    def walk(v, secret=False):
        if isinstance(v, dict):
            for k, x in v.items():
                # where a file is (token_file: /run/zigmon/api-token) is no secret - what is in it is,
                # and that is read above; a path left out made the report's labels say "(left out)"
                if re.search(r'(?i)_(file|path|dir)$', str(k)) and isinstance(x, str) and x.startswith('/'):
                    continue
                walk(x, secret or bool(re.search(r'(?i)pass|token|secret|key|pin|psk|auth|cookie', str(k))))
        elif isinstance(v, list):
            for x in v:
                walk(x, secret)
        elif secret and isinstance(v, str) and len(v.strip()) >= 4:
            out.add(v.strip())
    walk(conf)
    return sorted(out, key=len, reverse=True)


def se_blot(text, secrets_):
    for s in secrets_:
        text = text.replace(s, '(left out)')
    return SE_SECRET_WORDS.sub(lambda m: m.group(1) + m.group(3) + '(left out)', text)


def se_cut(text):
    b = text.encode('utf-8', 'replace')
    if len(b) <= SE_REPORT_MOST:
        return text
    # the newest kept: the end of the audit log is what came last
    return '(the first %d bytes left out - too long)\n' % (len(b) - SE_REPORT_MOST) + \
        b[-SE_REPORT_MOST:].decode('utf-8', 'replace')


def se_out(cmd, timeout=120, data=None, light=True, tool=True):
    """A command's words for the report - what it said, or why it said nothing."""
    exe = se_tool(cmd[0]) if tool else shutil.which(cmd[0])
    if not exe:
        return '(%s is not on this machine)\n' % cmd[0]
    full = [exe] + list(cmd[1:])
    if light:
        if shutil.which('ionice'):
            full = [shutil.which('ionice'), '-c', '3'] + full
        if shutil.which('nice'):
            full = [shutil.which('nice'), '-n', '19'] + full
    try:
        got = subprocess.run(full, input=data, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as e:
        return '(%s: %s)\n' % (cmd[0], e)
    return se_cut((got.stdout or '') + (('\n--- stderr ---\n' + got.stderr) if (got.stderr or '').strip() else ''))


def se_audit_only(text):
    return '\n'.join(x for x in text.splitlines() if SE_AUDIT_KEEP.match(x) or x.startswith('(')) + '\n'


def se_report_parts(r):
    parts = {}
    parts['check.json'] = json.dumps(se_check(r), indent=1, sort_keys=True)
    facts = r.get('facts') if isinstance(r.get('facts'), dict) else {}
    parts['zigmon.json'] = json.dumps({'facts': facts, 'want': {'booleans': r.get('booleans') or [],
                                                                'ports': r.get('ports') or []}},
                                      indent=1, sort_keys=True, default=str)
    raw = se_audit_only(se_out(['ausearch', '-m', 'AVC,USER_AVC,SELINUX_ERR,USER_SELINUX_ERR', '-ts', 'boot'], 300))
    parts['avc-raw.txt'] = raw
    parts['avc.txt'] = se_audit_only(se_out(['ausearch', '-m', 'AVC,USER_AVC,SELINUX_ERR,USER_SELINUX_ERR',
                                             '-ts', 'boot', '-i'], 300))
    if raw.startswith('('):
        parts['audit2why.txt'] = parts['audit2allow.te'] = raw
    else:
        parts['audit2why.txt'] = se_out(['audit2why'], 300, data=raw)
        parts['audit2allow.te'] = se_out(['audit2allow', '-m', 'zigmon_local'], 300, data=raw)
    sysw = []
    for name, cmd, tool in (('os-release', ['cat', '/etc/os-release'], False),
                            ('kernel', ['uname', '-r'], False), ('started', ['uptime', '-s'], False),
                            ('getenforce', ['getenforce'], True), ('sestatus', ['sestatus', '-v'], True),
                            ('packages', ['rpm', '-q', 'selinux-policy', 'selinux-policy-targeted',
                                          'policycoreutils', 'policycoreutils-python-utils',
                                          'libselinux-utils', 'audit', 'nginx', 'php-fpm', 'mosquitto',
                                          'chrony'], False),
                            ('kernel command line', ['cat', SE_CMDLINE], False),
                            ('selinux config', ['cat', SE_CONFIG], False)):
        sysw.append('==== %s\n%s' % (name, se_out(cmd, 60, light=False, tool=tool)))
    sysw.append('==== auditd\n%s\n' % ('active' if se_auditd() else 'not running'))
    parts['system.txt'] = '\n'.join(sysw)
    lab = []
    for p in SE_REPORT_PATHS:
        if os.path.lexists(p):
            lab.append('%s  %s' % (p, se_label(p) or '?'))
            if os.path.isdir(p):
                try:
                    for n in sorted(os.listdir(p))[:60]:
                        lab.append('    %s  %s' % (n, se_label(os.path.join(p, n)) or '?'))
                except OSError:
                    pass
            lab.append('  policy says: ' + se_out(['matchpathcon', p], 20, light=False).strip())
    parts['labels.txt'] = '\n'.join(lab) + '\n'
    # the domains the programs run in - their names, never their arguments
    # (-o label, not -Z with -o: procps refuses "output modifiers with user-defined output",
    # and the list came out empty - zigmon 5.48.0)
    ps = se_out(['ps', '-eo', 'label,user,pid,comm'], 60, light=False, tool=False)
    kept = [x[:200] for x in ps.splitlines() if x.startswith('LABEL') or any(c in x for c in SE_REPORT_COMMS)]
    parts['processes.txt'] = '\n'.join(kept) + '\n' if kept else \
        '(ps gave no list of processes)\n' + '\n'.join(x[:200] for x in ps.splitlines()[:5]) + '\n'
    ports = se_out(['semanage', 'port', '-l'], 300)
    parts['ports.txt'] = '==== labelled\n' + '\n'.join(
        x for x in ports.splitlines() if x.split()[:1] and x.split()[0] in SE_REPORT_PORT_TYPES) + \
        '\n\n==== listening\n' + se_out(['ss', '-lntuZ'], 60, light=False, tool=False)
    bools = se_out(['getsebool', '-a'], 60, light=False)
    parts['booleans.txt'] = '\n'.join(x for x in bools.splitlines() if re.match(
        r'^(httpd_|daemons_|logging_|domain_can|nis_enabled|use_nfs)', x)) + '\n'
    mods = se_out(['semodule', '-l'], 300)
    parts['modules.txt'] = '==== zigmon\n' + '\n'.join(x for x in mods.splitlines() if 'zigmon' in x.lower()) + \
        '\n\n==== %s\n%s\n==== in the policy\n%s\n' % (SE_CIL, se_read(SE_CIL) or '(not there)',
                                                       se_read(SE_CIL + '.in-policy') or '(none put in yet)')
    local_cil = os.path.join(se_local_dir(), SE_LOCAL + '.cil.in-policy')
    parts['modules.txt'] += '\n==== %s (zigmon\'s local rules, put in from the card)\n%s\n' % (
        SE_LOCAL, se_read(local_cil) or '(no local rule put in)')
    # the whole machine (5.55): every process, boolean, port type and module, what was changed
    # here, every listening socket - for whoever looks after the machine's policy, not zigmon's
    # alone. The names of programs, never their arguments.
    parts['os/processes.txt'] = se_out(['ps', '-eo', 'label,user,pid,ppid,comm'], 60, light=False, tool=False)
    parts['os/booleans.txt'] = bools
    parts['os/ports.txt'] = ports
    full = se_out(['semodule', '-lfull'], 300)
    parts['os/modules.txt'] = full if not full.startswith('(') and 'stderr' not in full[:200] else mods
    local = []
    for what in ('boolean', 'port', 'fcontext', 'login', 'user', 'module', 'permissive'):
        local.append('==== semanage %s -l -C\n%s' % (what, se_out(['semanage', what, '-l', '-C'], 300)))
    parts['os/local-changes.txt'] = '\n'.join(local)
    parts['os/semanage-export.txt'] = se_out(['semanage', 'export'], 300)
    parts['os/listening.txt'] = se_out(['ss', '-lntupZ'], 60, light=False, tool=False)
    parts['README.txt'] = (
        'zigmon - what SELinux says on this machine, for whoever writes zigmon\'s module (%s).\n'
        'Made %s. Nothing was changed to make it.\n\n'
        'check.json      the card: mode, module, labels, booleans, ports, refusals\n'
        'avc*.txt        what SELinux refused since the machine started (raw and readable)\n'
        'audit2why.txt   why; audit2allow.te: what would allow it - a hint, never to be loaded\n'
        'labels.txt      the labels of zigmon\'s files and what the policy says they should be\n'
        'processes.txt   the domains the programs run in; ports.txt, booleans.txt, modules.txt\n'
        'system.txt      the system, the policy and the packages; zigmon.json: what zigmon uses\n'
        'os/             the whole machine: processes.txt (every process, its domain), booleans.txt,\n'
        '                ports.txt, modules.txt, local-changes.txt (semanage ... -l -C),\n'
        '                semanage-export.txt, listening.txt (ss -lntupZ)\n\n'
        'No password, key or token is in it: zigmon\'s own are blotted out wherever they turn up,\n'
        'and the audit records that hold a command line (PROCTITLE, EXECVE) are left out. The\n'
        'refusals still name the programs and files of others on this machine: look through\n'
        'avc*.txt before sending it on.\n' % (SE_MODULE, time.strftime('%Y-%m-%d %H:%M:%S')))
    return parts


def se_report_bytes(r):
    secrets_ = se_secrets()
    top = re.sub(r'[^A-Za-z0-9._-]', '', hostname())[:60] or 'zigmon'
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as tf:
        for name, text in se_report_parts(r).items():
            data = se_blot(text, secrets_).encode('utf-8', 'replace')
            info = tarfile.TarInfo('zigmon-selinux-%s/%s' % (top, name))
            info.size, info.mtime, info.mode = len(data), int(time.time()), 0o600
            tf.addfile(info, io.BytesIO(data))
    return buf.getvalue()


def se_words(c):
    """zigmon --selinux-check: what se_check found, for a person."""
    lines = ['SELinux: %s (config: %s%s)' % (c['mode'], c.get('config') or '?',
                                            ', %s' % c['policy'] if c.get('policy') else '')]
    if c['mode'] == 'absent':
        lines.append('  no SELinux on this machine - nothing to do')
        return '\n'.join(lines)
    if c.get('relabel_pending'):
        lines.append('  every file is labelled at the next start of the machine')
    if c.get('cmdline_off'):
        lines.append('  the kernel\'s command line has selinux=0')
    if c['mode'] == 'Disabled':
        lines.append('  disabled - zigmon runs as always; zigmon --selinux prepare (or "Make it ready" in '
                     'Settings - SELinux) makes it permissive at the next start')
        return '\n'.join(lines)
    lines.append('  module %s: %s' % (SE_MODULE, {True: 'installed', False: 'NOT installed', None: '?'}[c['module']]))
    for x in c['labels']:
        lines.append('  %s %s: %s%s' % ('ok  ' if x['ok'] else 'FAIL', x['path'], x['label'] or '?',
                                        '' if x['ok'] else ' (want %s)' % x['want']))
    for x in c['booleans']:
        lines.append('  %s boolean %s: %s - %s' % ('ok  ' if x['on'] else 'FAIL', x['name'],
                                                   'on' if x['on'] else 'off', x['why']))
    for x in c['ports']:
        lines.append('  %s port %d/%s %s - %s' % ('ok  ' if x['labelled'] else 'FAIL', x['port'], x['proto'],
                                                 x['type'], x['why']))
    for x in c.get('left_out') or []:
        lines.append('  note: %s' % x)
    d = c['denials']
    lines.append('  refused since %s: %s' % ('zigmon\'s needs were put in' if d.get('since') else 'the start',
                                             d['total'] if d['tool'] else '? (ausearch is not there)'))
    if d.get('settled'):
        lines.append('  refused before, allowed now (not counted): %d' % d['settled'])
    for g in d['groups'][:15]:
        lines.append('    %4dx %s -> %s %s { %s } %s' % (g['count'], g['source'], g['target'], g['class'],
                                                         g['perms'], g['what']))
    n = c.get('counts') or {}
    if n.get('tool'):
        lines.append('  findings: %d can be put right, %d not for a button, %d not zigmon\'s (zigmon --selinux-look)'
                     % (n.get('fixable', 0), n.get('notbutton', 0), n.get('other', 0)))
    for f in c.get('findings') or []:
        if f.get('kind') in SE_FIXABLE:
            lines.append('    %s %-8s %s' % (f['id'], f['kind'], f.get('fix') or ''))
    if (c.get('local') or {}).get('rules'):
        lines.append('  zigmon\'s local rules (%s): %d' % (SE_LOCAL, len(c['local']['rules'])))
    if c.get('auditd') is False:
        lines.append('  FAIL auditd does not run')
    if c.get('ready'):
        lines.append('ready for enforcing')
    elif c['mode'] == 'Enforcing' and not c['problems']:
        lines.append('enforcing - and everything zigmon needs is there')
    elif c['problems']:
        lines.append('not ready: ' + '; '.join(c['problems'][:6]))
    return '\n'.join(lines)


def se_cli(argv):
    """zigmon_root.py --selinux-check [--json] | --selinux-do STEP [--json] |
    --selinux-report FILE: as root, from the zigmon command - what this configuration needs
    given on stdin (JSON), checked here as a request from the dashboard is."""
    want = {}
    if not sys.stdin.isatty():
        try:
            want = json.loads(sys.stdin.read(65536) or '{}')
        except ValueError:
            want = {}
    if not isinstance(want, dict):
        want = {}
    if argv[0] == '--selinux-report':
        if len(argv) < 2:
            print('--selinux-report FILE', file=sys.stderr)
            return 2
        data = se_report_bytes(want)
        path = os.path.abspath(argv[1])
        fd, tmp = tempfile.mkstemp(prefix='.zigmon-selinux-', dir=os.path.dirname(path))
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(data)
                os.fchmod(f.fileno(), 0o600)
            os.replace(tmp, path)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise
        print(json.dumps({'report': path, 'bytes': len(data)}) if '--json' in argv else
              '%s (%d kB)' % (path, len(data) >> 10))
        return 0
    step = 'check' if argv[0] == '--selinux-check' else (argv[1] if len(argv) > 1 else '')
    ask = {}
    if argv[0] in ('--selinux-fix', '--selinux-rule-drop'):
        # finding ids only, as from the page: root finds each again and works out its fix
        step = 'fix' if argv[0] == '--selinux-fix' else 'rule_drop'
        ask = {'ids': [a for a in argv[1:] if not a.startswith('--')], 'by': 'root on the command line'}
    try:
        c = se_do(dict(want, do=step, **ask))
    except Refused as e:
        print(json.dumps({'ok': False, 'said': str(e)}) if '--json' in argv else 'refused: %s' % e,
              file=sys.stdout if '--json' in argv else sys.stderr)
        return 1
    if '--json' in argv:
        print(json.dumps(dict(c, ok=True), indent=1, sort_keys=True))
    else:
        for x in c.get('said') or []:
            print('  ' + x)
        print(se_words(c))
    if step == 'check':
        return 0 if c['mode'] in ('absent', 'Disabled') or not c['problems'] else 1
    return 1 if c.get('failed') else 0


# ---- the requests ---------------------------------------------------------------
def status_read():
    try:
        got = json.loads(read_req('status.json').decode('utf-8'))
    except (OSError, ValueError, Refused):
        return {}
    return got if isinstance(got, dict) else {}


def look(write=True):
    out = {'at': time.time(), 'tls': tls_now(), 'access': access_now(), 'fw': fw_look(),
           'acme': acme_look(),
           'full': full_list(), 'full_dir': FULL_DIR, 'host': hostname(),
           'version': installed_version()}
    if write:
        write_here('look.json', json.dumps(out))
    return out


def handle(raw):
    """One request, by its kind: (state fields, words)."""
    kind = str(raw.get('kind') or 'apply')
    if kind == 'apply':
        r = checked(raw)
        last = status_read().get('dh_last') or {}
        said_n, _ = nginx_part(r, {'dh': last.get('dh')} if isinstance(last, dict) else {})
        said_f, fw = fw_part(r['fw'])
        fields = {'fw': fw, 'hash': r['hash']}
        if r['tls']:
            fields['dh_last'] = {'dh': r['tls']['dh']}
        return fields, said_n + said_f
    if kind == 'full_make':
        keep = raw.get('keep')
        try:
            keep = max(1, min(365, int(keep)))
        except (TypeError, ValueError):
            keep = 7
        db = raw.get('db')
        made = full_make(str(raw.get('why') or 'by hand'), str(db) if db else None, keep)
        return {'made': made}, ['a backup of the whole installation: %s (%d MB)' % (
            made['file'], made['bytes'] // 1048576)]
    if kind == 'full_get':
        path = full_path(raw.get('file'))
        pw = str(raw.get('passphrase') or '')
        out_fd = child_fd(root_fd(), 'out', make=True)
        for n in os.listdir(out_fd):                    # one hand-over at a time
            if EXPORT_FILE.match(n):
                continue            # a certificate waiting to be downloaded is not a backup's (5.37.1)
            try:
                os.unlink(n, dir_fd=out_fd)
            except OSError:
                pass
        name = os.path.basename(path) + ('.enc' if pw else '')
        with tempfile.TemporaryDirectory(prefix='zigmon-get-') as t:
            src = path
            if pw:
                if len(pw) < 8:
                    raise Refused('a password for the copy is eight characters or more')
                src = os.path.join(t, 'enc')
                encrypt(path, src, pw)
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640,
                         dir_fd=out_fd)
            with os.fdopen(fd, 'wb') as out, open(src, 'rb') as fh:
                shutil.copyfileobj(fh, out, 1 << 20)
                os.fchown(out.fileno(), 0, service_gid())
        return {'out': name, 'out_bytes': os.stat(name, dir_fd=out_fd).st_size}, \
            ['handed over for a download: %s%s' % (name, ' (with a password)' if pw else '')]
    if kind == 'tls_export':
        return tls_export(raw)
    if kind == 'tls_chain':
        return tls_chain(raw)
    if kind == 'tls_proxy':
        return tls_proxy(raw)
    if kind == 'tls_proxy_ntfy':
        return tls_proxy(raw, which='ntfy')
    if kind == 'full_put':
        name = os.path.basename(str(raw.get('file') or ''))
        if not re.match(r'^upload-[A-Za-z0-9]{1,32}\.bin$', name):
            raise Refused('the request names no uploaded file')
        in_fd = child_fd(root_fd(), 'in', make=True)
        os.makedirs(FULL_DIR, mode=0o700, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='zigmon-put-', dir=FULL_DIR) as t:
            copy = os.path.join(t, 'copy')
            with open_plain(in_fd, name, MOST_FULL) as src, open(copy, 'xb') as out:
                shutil.copyfileobj(src, out, 1 << 20)
            try:
                os.unlink(name, dir_fd=in_fd)
            except OSError:
                pass
            with open(copy, 'rb') as fh:
                magic = fh.read(8)
            pw = str(raw.get('passphrase') or '')
            if magic == b'Salted__':
                if not pw:
                    raise Refused('this copy is locked with a password: give it')
                plain_copy = os.path.join(t, 'plain')
                decrypt(copy, plain_copy, pw)
                copy = plain_copy
            info = full_inspect(copy)
            base = re.sub(r'\.tar\.gz$', '', info['top']) + '-uploaded'
            target = os.path.join(FULL_DIR, base + '.tar.gz')
            n = 1
            while os.path.exists(target):
                n += 1
                target = os.path.join(FULL_DIR, '%s-%d.tar.gz' % (base, n))
            shutil.copyfile(copy, target)
            os.chmod(target, 0o600)
        info['file'] = os.path.basename(target)
        info.pop('files', None)
        return {'inspected': info}, ['taken in: %s%s' % (info['file'], '' if info['trusted'] else
                                                          ' (made somewhere else)')]
    if kind == 'full_inspect':
        info = full_inspect(full_path(raw.get('file')))
        info['file'] = os.path.basename(full_path(raw.get('file')))
        info.pop('files', None)
        return {'inspected': info}, []
    if kind == 'full_restore':
        parts = raw.get('parts') or []
        if not isinstance(parts, list):
            raise Refused('the parts are a list')
        said = full_restore(full_path(raw.get('file')), [str(p) for p in parts][:10], from_page=True)
        return {'restored': os.path.basename(str(raw.get('file'))), 'parts': parts}, said
    if kind == 'full_delete':
        path = full_path(raw.get('file'))
        os.unlink(path)
        return {}, ['deleted: %s' % os.path.basename(path)]
    raise Refused('nothing is done for a request of the kind %r' % kind[:40])


TAKEN_LEFT_SAID = ("root's helper stopped before it had finished this - killed, out of time or the "
                   'power went - and how far it got is not known: look at what is in place before '
                   'asking for it again')


def taken_left(d):
    """(5.44.1) A request.taken that no run holds is one a run took and never
    finished: killed, stopped by systemd at its 30 minutes, or the power went
    in the middle. It was left as it was - so the daemon said root was busy
    with it for half an hour, nothing could be asked meanwhile, and whoever
    waited for the answer was never given one. Said as failed, and taken
    away. True when there was one."""
    try:
        fd = os.open('request.taken', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=d)
    except OSError:
        return False
    try:
        st = os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or time.time() - st.st_mtime < 5:
            return False                        # not a request, or one a run has only just taken
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return False                        # a run is working on it now
        try:
            raw = json.loads(os.read(fd, 65536).decode('utf-8'))
        except (OSError, ValueError):
            raw = {}
    finally:
        os.close(fd)
    if not isinstance(raw, dict):
        raw = {}
    last = status_read()
    out = {'at': time.time(), 'state': 'failed', 'said': [TAKEN_LEFT_SAID],
           'id': re.sub(r'[^A-Za-z0-9]', '', str(raw.get('id') or ''))[:32],
           'kind': re.sub(r'[^a-z_]', '', str(raw.get('kind') or 'apply'))[:20],
           'asked_hash': re.sub(r'[^0-9a-f]', '', str(raw.get('hash') or ''))[:64]}
    if isinstance(last.get('dh_last'), dict):
        out['dh_last'] = last['dh_last']
    for k in ('applied_hash', 'failed_hash'):
        if isinstance(last.get(k), str):
            out[k] = last[k]
    if out['kind'] == 'apply':
        # not asked again by itself: a request that took the helper down
        # once would take it down every half minute
        out['failed_hash'] = out['asked_hash']
    for name in ('request.taken', 'progress.json'):
        try:
            os.unlink(name, dir_fd=d)
        except OSError:
            pass
    write_here('status.json', json.dumps(out))
    if out['kind'].startswith('full_'):
        write_here('status-full.json', json.dumps(out))
    print('zigmon_root.py: %s (%s %s)' % (TAKEN_LEFT_SAID, out['kind'], out['id']), file=sys.stderr)
    return True


def serve():
    d = root_fd()
    # the network, the clock and switching off first, and the updates of the
    # system, each answered on its own: none of them waits behind a backup
    # laid down in request.json
    for part in (net_part, ntp_part, osup_part, osroots_part, selinux_part):
        try:
            part()
        except Exception as e:                          # noqa: BLE001
            print('%s: %s' % (part.__name__, e), file=sys.stderr)
    asked_look = False
    try:
        os.unlink('look.ask', dir_fd=d)
        asked_look = True
    except FileNotFoundError:
        pass
    except OSError:
        asked_look = True
    left = taken_left(d)
    try:
        os.replace('request.json', 'request.taken', src_dir_fd=d, dst_dir_fd=d)
    except FileNotFoundError:
        if asked_look or left:
            look()
        return 0
    # held for as long as this run works on it: what taken_left looks for
    held = None
    try:
        held = os.open('request.taken', os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=d)
        fcntl.flock(held, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        pass
    last = status_read()
    out = {'at': time.time()}
    if isinstance(last.get('dh_last'), dict):
        out['dh_last'] = last['dh_last']
    for k in ('applied_hash', 'failed_hash'):
        if isinstance(last.get(k), str):
            out[k] = last[k]
    try:
        try:
            raw = json.loads(read_req('request.taken').decode('utf-8'))
        except ValueError as e:
            raise Refused('the request does not read: %s' % e)
        if not isinstance(raw, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(raw.get('id') or ''))[:32]
        out['kind'] = re.sub(r'[^a-z_]', '', str(raw.get('kind') or 'apply'))[:20]
        # what was asked for, so a request refused is not asked for again by itself
        out['asked_hash'] = re.sub(r'[^0-9a-f]', '', str(raw.get('hash') or ''))[:64]
        PROGRESS['id'] = out['id']
        progress('checking what was asked', 1)
        fields, said = handle(raw)
        out.update(fields)
        if out['kind'] == 'apply':
            out['applied_hash'] = fields.get('hash', '')
        out.update(state='done', said=[s for s in said if s])
    except Refused as e:
        out.update(state='failed', said=[str(e)])
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out.update(state='failed', said=['it broke: %s' % e])
    finally:
        for name in ('request.taken', 'progress.json'):
            try:
                os.unlink(name, dir_fd=d)
            except OSError:
                pass
        if held is not None:
            os.close(held)
    if out.get('kind') == 'apply':
        # the last apply refused, kept across the requests of other kinds, so
        # the daemon does not ask for it again by itself
        out['failed_hash'] = out.get('asked_hash', '') if out.get('state') == 'failed' else ''
    write_here('status.json', json.dumps(out))
    if str(out.get('kind') or '').startswith('full_'):
        # kept apart too: the next apply must not hide how a restore ended
        write_here('status-full.json', json.dumps(out))
    try:
        look()
    except Exception as e:                              # noqa: BLE001
        print('zigmon_root.py: looking at what is in place: %s' % e, file=sys.stderr)
    return 0


def passphrase_from(argv):
    if '--passphrase-file' in argv:
        with open(argv[argv.index('--passphrase-file') + 1]) as f:
            return f.read().strip()
    return ''


def opened(path, argv, work):
    """The backup itself, decrypted into `work` first when it is locked."""
    with open(path, 'rb') as fh:
        magic = fh.read(8)
    if magic != b'Salted__':
        return path
    pw = passphrase_from(argv)
    if not pw:
        raise Refused('this copy is locked with a password: --passphrase-file FILE')
    out = os.path.join(work, 'plain.tar.gz')
    decrypt(path, out, pw)
    return out


def main(argv):
    if argv[:1] == ['--look']:
        print(json.dumps(look(write=False), indent=1))
        return 0
    if os.geteuid() != 0:
        print('zigmon_root.py: root only', file=sys.stderr)
        return 2
    try:
        if argv[:1] == ['--backup']:
            why = argv[argv.index('--why') + 1] if '--why' in argv else 'the command line'
            made = full_make(why)
            print('%s/%s (%d MB): %s' % (FULL_DIR, made['file'], made['bytes'] // 1048576,
                                         ', '.join(made['parts'])))
            return 0
        if argv[:1] == ['--inspect'] and len(argv) >= 2:
            with tempfile.TemporaryDirectory(prefix='zigmon-look-') as t:
                info = full_inspect(opened(argv[1], argv, t))
            info.pop('files', None)
            print(json.dumps(info, indent=1))
            return 0
        if argv[:1] == ['--restore'] and len(argv) >= 2:
            with tempfile.TemporaryDirectory(prefix='zigmon-cli-') as t:
                path = opened(os.path.abspath(argv[1]), argv, t)
                info = full_inspect(path)
                parts = argv[argv.index('--parts') + 1].split(',') if '--parts' in argv else \
                    [p['part'] for p in info['parts']]
                print('%s, made on %s by zigmon %s%s' % (
                    info['top'], info['host'], info['version'] or '?',
                    '' if info['trusted'] else ' (on another machine)'))
                for p in info['parts']:
                    print('  %-9s %s %s' % (p['part'], '*' if p['part'] in parts else ' ', p['words']))
                if '--yes' not in argv:
                    answer = input('Put back the parts marked * ? [y/N] ').strip().lower()
                    if answer not in ('y', 'yes'):
                        print('nothing done')
                        return 1
                full_restore(path, parts, from_page=False, say=print)
            return 0
        if argv[:1] in (['--selinux-check'], ['--selinux-do'], ['--selinux-report'], ['--selinux-fix'],
                        ['--selinux-rule-drop']):
            # SELinux, from the zigmon command as root: what the
            # configuration needs on stdin, checked here as the dashboard's is
            return se_cli(argv)
        if argv[:1] == ['--os-job'] and len(argv) >= 3 and argv[2] in OSUP_KINDS:
            # started by osup_launch, never by the dashboard's words
            if not OSUP_JOB_RE.match(argv[1]):
                return 2
            return osup_job(argv[1], argv[2], argv[3:4] == ['security'])
        if not argv:
            return serve()
    except Refused as e:
        print('refused: %s' % e, file=sys.stderr)
        return 1
    print(__doc__)
    return 2


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
